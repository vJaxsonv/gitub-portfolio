﻿Public Class frmAdminAddAttendants
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        ' variables for new player data and select and insert statements
        Dim strSelect As String
        Dim strInsertAttendant As String
        Dim strInsertEmployee As String
        Dim strFirstName As String
        Dim strLastName As String
        Dim strEmployeeID As String
        Dim dtmDateOfHire As Date
        Dim dtmDateOfTermination As Date
        Dim dtmDateOfLicense As Date
        Dim strUsername As String
        Dim strPassword As String
        Dim blnvalidated As Boolean = True

        Dim cmdSelect As OleDb.OleDbCommand
        Dim cmdInsert As New OleDb.OleDbCommand
        Dim cmdInsert2 As New OleDb.OleDbCommand
        Dim cmdSelectRoleID As New OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader '
        Dim cmdUpdate As New OleDb.OleDbCommand

        Dim intNextEmployeeKey As Integer
        Dim intNextPrimaryKey As Integer
        Dim intRowsAffected As Integer
        Dim intRowsAffected2 As Integer

        Call Get_Validate_Input(strFirstName, strLastName, strEmployeeID, blnvalidated)
        If blnvalidated = True Then
            Try
                ' validate data is entered
                ' put values into strings
                strFirstName = txtFirstName.Text
                strLastName = txtLastName.Text
                strEmployeeID = txtID.Text
                dtmDateOfHire = strDateofHire.Value
                dtmDateOfTermination = strDateofTermination.Value
                dtmDateOfLicense = strDateofLicense.Value

                strUsername = txtPilotUserName.Text
                strPassword = txtPilotPassword.Text

                ' Open database connection
                If Not OpenDatabaseConnectionSQLServer() Then
                    MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Close()
                    Exit Sub
                End If

                ' First SELECT statement to get the next primary key for Pilots
                strSelect = "SELECT MAX(IntAttendantID) + 1 AS intNextPrimaryKey FROM TAttendants"

                ' Execute the first SELECT command
                cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
                drSourceTable = cmdSelect.ExecuteReader

                ' Read result to get the next primary key
                drSourceTable.Read()

                ' Check if the table is empty
                If drSourceTable.IsDBNull(0) Then
                    ' If yes, start numbering at 1
                    intNextPrimaryKey = 1
                Else
                    ' If no, get the next highest ID
                    intNextPrimaryKey = CInt(drSourceTable("intNextPrimaryKey"))
                End If


                strSelect = "SELECT MAX(intEmployeeID) + 1 AS intNextEmployeeKey FROM TEmployees"

                ' Execute the first SELECT command
                cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
                drSourceTable = cmdSelect.ExecuteReader

                ' Read result to get the next primary key
                drSourceTable.Read()

                ' Check if the table is empty
                If drSourceTable.IsDBNull(0) Then
                    ' If yes, start numbering at 1
                    intNextEmployeeKey = 1
                Else
                    ' If no, get the next highest ID
                    intNextEmployeeKey = CInt(drSourceTable("intNextEmployeeKey"))
                End If


                ' Close the first data reader
                drSourceTable.Close()



                ' Build the INSERT statement
                strInsertAttendant = "INSERT INTO TAttendants (intAttendantID, strFirstName, strLastName, strEmployeeID, dtmDateofHire, dtmDateofTermination, intEmployeeID, intRoleID)" &
                            " VALUES (" & intNextPrimaryKey & ", '" & strFirstName & "','" & strLastName & "','" & strEmployeeID & "','" & dtmDateOfHire & "','" & dtmDateOfTermination & "','" & intNextEmployeeKey & "','" & 3 & "')"

                strInsertEmployee = "INSERT INTO TEmployees (intEmployeeID, strEmployeeLoginID, strEmployeePassword, intRoleID)" &
                         " VALUES (" & intNextEmployeeKey & ", '" & strUsername & "','" & strPassword & "','" & 3 & "')"

                MessageBox.Show(strInsertAttendant & strInsertEmployee)


                cmdInsert = New OleDb.OleDbCommand(strInsertAttendant, m_conAdministrator)
                cmdInsert2 = New OleDb.OleDbCommand(strInsertEmployee, m_conAdministrator)

                intRowsAffected = cmdInsert.ExecuteNonQuery()
                intRowsAffected2 = cmdInsert2.ExecuteNonQuery()

                If intRowsAffected > 0 Then
                    MessageBox.Show("Pilot has been added")    ' let user know success
                    ' close new player form
                End If
                If intRowsAffected2 > 0 Then
                    MessageBox.Show("Employee has been added")    ' let user know success
                    ' close new player form
                End If

                ' Close database connection
                CloseDatabaseConnection()

            Catch ex As Exception
                MessageBox.Show("An error occurred: " & ex.Message)
            End Try
        End If

    End Sub
    Private Sub Get_Validate_Input(ByRef strfirstname As String, strlastname As String, ByRef strEmployeeID As String, ByRef blnvalidated As Boolean)
        Call Get_Validate_FirstName_and_LastName(strfirstname, strlastname, blnvalidated)
        If blnvalidated = True Then
            Call ValidateID(strEmployeeID, blnvalidated)
        End If
    End Sub
    'Validating Names
    Private Sub Get_Validate_FirstName_and_LastName(ByRef strfirstname As String, ByRef strlastname As String, blnvalidate As Boolean)
        If txtFirstName.Text = String.Empty Then
            MessageBox.Show("First Name is Required")
            txtFirstName.Focus()
            Exit Sub
        End If

        If txtLastName.Text = "" Then
            MessageBox.Show("Last Name is Required")
            txtLastName.Focus()
            Exit Sub
        End If
    End Sub
    Private Sub ValidateID(ByRef strEmployeeID As String, ByRef blnvalidated As Boolean)
        If txtID.Text = String.Empty Then
            MessageBox.Show("ID is Required")
            txtID.Focus()
            Exit Sub
        End If
    End Sub


    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class