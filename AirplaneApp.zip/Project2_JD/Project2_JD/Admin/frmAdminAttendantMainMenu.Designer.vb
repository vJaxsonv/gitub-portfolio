﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmAdminAttendantMainMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnAddAttendanttoFlights = New System.Windows.Forms.Button()
        Me.btnDeleteAttendant = New System.Windows.Forms.Button()
        Me.btnAddAttendant = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(213, 117)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(145, 43)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnAddAttendanttoFlights
        '
        Me.btnAddAttendanttoFlights.Location = New System.Drawing.Point(36, 117)
        Me.btnAddAttendanttoFlights.Name = "btnAddAttendanttoFlights"
        Me.btnAddAttendanttoFlights.Size = New System.Drawing.Size(145, 43)
        Me.btnAddAttendanttoFlights.TabIndex = 6
        Me.btnAddAttendanttoFlights.Text = "Add Attendants To Flights"
        Me.btnAddAttendanttoFlights.UseVisualStyleBackColor = True
        '
        'btnDeleteAttendant
        '
        Me.btnDeleteAttendant.Location = New System.Drawing.Point(213, 54)
        Me.btnDeleteAttendant.Name = "btnDeleteAttendant"
        Me.btnDeleteAttendant.Size = New System.Drawing.Size(145, 43)
        Me.btnDeleteAttendant.TabIndex = 5
        Me.btnDeleteAttendant.Text = "Delete Attendants"
        Me.btnDeleteAttendant.UseVisualStyleBackColor = True
        '
        'btnAddAttendant
        '
        Me.btnAddAttendant.Location = New System.Drawing.Point(36, 54)
        Me.btnAddAttendant.Name = "btnAddAttendant"
        Me.btnAddAttendant.Size = New System.Drawing.Size(145, 43)
        Me.btnAddAttendant.TabIndex = 4
        Me.btnAddAttendant.Text = "Add Attendants"
        Me.btnAddAttendant.UseVisualStyleBackColor = True
        '
        'frmAdminAttendantMainMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(395, 178)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnAddAttendanttoFlights)
        Me.Controls.Add(Me.btnDeleteAttendant)
        Me.Controls.Add(Me.btnAddAttendant)
        Me.Name = "frmAdminAttendantMainMenu"
        Me.Text = "Admin Attendants Main Menu"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents btnAddAttendanttoFlights As Button
    Friend WithEvents btnDeleteAttendant As Button
    Friend WithEvents btnAddAttendant As Button
End Class
