﻿Public Class frmAdminAttendantMainMenu
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnAddAttendant.Click
        Dim frmAdminAddAttendants As New frmAdminAddAttendants
        frmAdminAddAttendants.ShowDialog()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnDeleteAttendant.Click
        Dim frmAdminAttendantDelete As New frmAdminAttendantDelete
        frmAdminAttendantDelete.ShowDialog()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnAddAttendanttoFlights.Click
        Dim frmAdminAttendantSelection As New frmAdminAttendantSelection
        frmAdminAttendantSelection.ShowDialog()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class