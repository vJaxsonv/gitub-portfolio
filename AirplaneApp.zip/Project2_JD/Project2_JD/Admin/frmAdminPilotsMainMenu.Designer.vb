﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAdminPilotsMainMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnAddPilots = New System.Windows.Forms.Button()
        Me.btnDeletePilots = New System.Windows.Forms.Button()
        Me.btnAddPilotsToFlights = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnAddPilots
        '
        Me.btnAddPilots.Location = New System.Drawing.Point(13, 33)
        Me.btnAddPilots.Name = "btnAddPilots"
        Me.btnAddPilots.Size = New System.Drawing.Size(145, 43)
        Me.btnAddPilots.TabIndex = 0
        Me.btnAddPilots.Text = "Add Pilots"
        Me.btnAddPilots.UseVisualStyleBackColor = True
        '
        'btnDeletePilots
        '
        Me.btnDeletePilots.Location = New System.Drawing.Point(190, 33)
        Me.btnDeletePilots.Name = "btnDeletePilots"
        Me.btnDeletePilots.Size = New System.Drawing.Size(145, 43)
        Me.btnDeletePilots.TabIndex = 1
        Me.btnDeletePilots.Text = "Delete Pilots"
        Me.btnDeletePilots.UseVisualStyleBackColor = True
        '
        'btnAddPilotsToFlights
        '
        Me.btnAddPilotsToFlights.Location = New System.Drawing.Point(13, 102)
        Me.btnAddPilotsToFlights.Name = "btnAddPilotsToFlights"
        Me.btnAddPilotsToFlights.Size = New System.Drawing.Size(145, 43)
        Me.btnAddPilotsToFlights.TabIndex = 2
        Me.btnAddPilotsToFlights.Text = "Add Pilots To Flights"
        Me.btnAddPilotsToFlights.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(190, 102)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(145, 43)
        Me.btnExit.TabIndex = 3
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmAdminPilotsMainMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(358, 178)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnAddPilotsToFlights)
        Me.Controls.Add(Me.btnDeletePilots)
        Me.Controls.Add(Me.btnAddPilots)
        Me.Name = "frmAdminPilotsMainMenu"
        Me.Text = "Admin Pilots Main Menu"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnAddPilots As Button
    Friend WithEvents btnDeletePilots As Button
    Friend WithEvents btnAddPilotsToFlights As Button
    Friend WithEvents btnExit As Button
End Class
