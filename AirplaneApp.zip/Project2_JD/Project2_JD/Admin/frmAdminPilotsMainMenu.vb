﻿Public Class frmAdminPilotsMainMenu
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnAddPilots.Click
        Dim frmAddPilots As New frmAddPilots
        frmAddPilots.ShowDialog()

    End Sub

    Private Sub frmAdminSelection_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnDeletePilots.Click
        Dim frmDeletePilots As New frmDeletePilots
        frmDeletePilots.ShowDialog()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnAddPilotsToFlights.Click
        Dim frmSelectPilot As New frmSelectPilot
        frmSelectPilot.ShowDialog()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class