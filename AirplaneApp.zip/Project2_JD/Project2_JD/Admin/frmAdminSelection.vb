﻿Public Class frmAdminSelection
    Private Sub btnPilots_Click(sender As Object, e As EventArgs) Handles btnPilots.Click
        Dim frmAdminPilotsMainMenu As New frmAdminPilotsMainMenu
        frmAdminPilotsMainMenu.ShowDialog()
    End Sub

    Private Sub btnAttendants_Click(sender As Object, e As EventArgs) Handles btnAttendants.Click
        Dim frmAdminAttendantMainMenu As New frmAdminAttendantMainMenu
        frmAdminAttendantMainMenu.showDialog
    End Sub

    Private Sub btnStatistics_Click(sender As Object, e As EventArgs) Handles btnStatistics.Click
        Dim frmAdimStatistics As New frmAdminStatistics
        frmAdminStatistics.ShowDialog()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

    Private Sub frmAdminSelection_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnFutureFlights_Click(sender As Object, e As EventArgs) Handles btnFutureFlights.Click
        Dim frmFutureFlights As New frmFutureFlights
        frmFutureFlights.ShowDialog()
    End Sub
End Class