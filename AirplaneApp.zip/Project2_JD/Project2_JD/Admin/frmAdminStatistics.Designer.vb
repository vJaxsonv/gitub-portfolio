﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAdminStatistics
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblNumberofCustomers = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblTotalFlightsForAllCustomers = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblAverageMilesFlownforAllCustomers = New System.Windows.Forms.Label()
        Me.lstEachPilottotalMilesflown = New System.Windows.Forms.ListBox()
        Me.lstEachAttendanttotalFlown = New System.Windows.Forms.ListBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblNumberofCustomers
        '
        Me.lblNumberofCustomers.AutoSize = True
        Me.lblNumberofCustomers.Location = New System.Drawing.Point(211, 32)
        Me.lblNumberofCustomers.Name = "lblNumberofCustomers"
        Me.lblNumberofCustomers.Size = New System.Drawing.Size(0, 13)
        Me.lblNumberofCustomers.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 32)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(111, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Number of Customers:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 66)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(180, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Total Flights Taken by all Customers:"
        '
        'lblTotalFlightsForAllCustomers
        '
        Me.lblTotalFlightsForAllCustomers.AutoSize = True
        Me.lblTotalFlightsForAllCustomers.Location = New System.Drawing.Point(211, 66)
        Me.lblTotalFlightsForAllCustomers.Name = "lblTotalFlightsForAllCustomers"
        Me.lblTotalFlightsForAllCustomers.Size = New System.Drawing.Size(0, 13)
        Me.lblTotalFlightsForAllCustomers.TabIndex = 2
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 99)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(189, 13)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Average Miles Flown for All Customers:"
        '
        'lblAverageMilesFlownforAllCustomers
        '
        Me.lblAverageMilesFlownforAllCustomers.AutoSize = True
        Me.lblAverageMilesFlownforAllCustomers.Location = New System.Drawing.Point(211, 99)
        Me.lblAverageMilesFlownforAllCustomers.Name = "lblAverageMilesFlownforAllCustomers"
        Me.lblAverageMilesFlownforAllCustomers.Size = New System.Drawing.Size(0, 13)
        Me.lblAverageMilesFlownforAllCustomers.TabIndex = 4
        '
        'lstEachPilottotalMilesflown
        '
        Me.lstEachPilottotalMilesflown.FormattingEnabled = True
        Me.lstEachPilottotalMilesflown.Location = New System.Drawing.Point(28, 134)
        Me.lstEachPilottotalMilesflown.Name = "lstEachPilottotalMilesflown"
        Me.lstEachPilottotalMilesflown.Size = New System.Drawing.Size(293, 238)
        Me.lstEachPilottotalMilesflown.TabIndex = 6
        '
        'lstEachAttendanttotalFlown
        '
        Me.lstEachAttendanttotalFlown.FormattingEnabled = True
        Me.lstEachAttendanttotalFlown.Location = New System.Drawing.Point(28, 388)
        Me.lstEachAttendanttotalFlown.Name = "lstEachAttendanttotalFlown"
        Me.lstEachAttendanttotalFlown.Size = New System.Drawing.Size(293, 238)
        Me.lstEachAttendanttotalFlown.TabIndex = 7
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(108, 647)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(115, 32)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "Exit"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'frmAdminStatistics
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(340, 691)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.lstEachAttendanttotalFlown)
        Me.Controls.Add(Me.lstEachPilottotalMilesflown)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lblAverageMilesFlownforAllCustomers)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblTotalFlightsForAllCustomers)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblNumberofCustomers)
        Me.Name = "frmAdminStatistics"
        Me.Text = "Statistics"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblNumberofCustomers As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblTotalFlightsForAllCustomers As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblAverageMilesFlownforAllCustomers As Label
    Friend WithEvents lstEachPilottotalMilesflown As ListBox
    Friend WithEvents lstEachAttendanttotalFlown As ListBox
    Friend WithEvents Button1 As Button
End Class
