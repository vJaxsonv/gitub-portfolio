﻿Public Class frmAdminStatistics
    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub frmAdminStatistics_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Dim strSelect As String = ""
            Dim cmdSelect As OleDb.OleDbCommand            ' this will be used for our Select statement
            Dim drSourceTable As OleDb.OleDbDataReader     ' this will be where our result set will 
            Dim dt As DataTable = New DataTable            ' this is the table we will load from our reader


            ' open the DB
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If


            '''''''''''''''''''''''''''


            'MessageBox.Show(strSelect)

            cmdSelect = New OleDb.OleDbCommand("uspCountTotalPassengers", m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            ' Read result( highest ID )
            drSourceTable.Read()

            ' Null? (empty table)
            If drSourceTable.IsDBNull(0) = True Then

                ' Yes, start numbering at 1
                lblNumberofCustomers.Text = 0

            Else

                ' No, get the next highest ID
                lblNumberofCustomers.Text = CInt(drSourceTable("TotalPassengers"))

            End If



            ''''''''''''''''''''''''''




            cmdSelect = New OleDb.OleDbCommand("uspCountTotalFlightsTaken", m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            drSourceTable.Read()


            If drSourceTable.IsDBNull(0) = True Then


                lblTotalFlightsForAllCustomers.Text = 0

            Else


                lblTotalFlightsForAllCustomers.Text = CInt(drSourceTable("TotalFlightsTaken"))

            End If



            '''''''''''''''''''''''''''''''''''''''''




            cmdSelect = New OleDb.OleDbCommand("uspAverageMilesFlown", m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            drSourceTable.Read()


            If drSourceTable.IsDBNull(0) = True Then

                lblAverageMilesFlownforAllCustomers.Text = 0

            Else

                lblAverageMilesFlownforAllCustomers.Text = CInt(drSourceTable("AverageMilesFlown"))

            End If




            ''''''''''''''''''''''''''''''''''''''''''''

            cmdSelect = New OleDb.OleDbCommand("uspSumofMilesPerPilot", m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader



            lstEachPilottotalMilesflown.Items.Add("Total Miles Flown for each Pilot")
            lstEachPilottotalMilesflown.Items.Add("  ")
            lstEachPilottotalMilesflown.Items.Add("=======================================")

            While drSourceTable.Read()

                lstEachPilottotalMilesflown.Items.Add("  ")

                lstEachPilottotalMilesflown.Items.Add("Name: " & vbTab & drSourceTable("PilotName"))
                lstEachPilottotalMilesflown.Items.Add("Has Taken : " & vbTab & drSourceTable("TotalMilesFlown"))

                lstEachPilottotalMilesflown.Items.Add("  ")
                lstEachPilottotalMilesflown.Items.Add("=======================================")

            End While



            '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''









            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand("uspSumofMilesPerAttendant", m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            'loop through result set and display in Listbox

            lstEachAttendanttotalFlown.Items.Add("Total Miles Flown for each Attendant")
            lstEachAttendanttotalFlown.Items.Add("  ")
            lstEachAttendanttotalFlown.Items.Add("=======================================")

            While drSourceTable.Read()

                lstEachAttendanttotalFlown.Items.Add("  ")

                lstEachAttendanttotalFlown.Items.Add("First Name: " & vbTab & drSourceTable("AttendantName"))
                lstEachAttendanttotalFlown.Items.Add("Has Taken : " & vbTab & drSourceTable("TotalMilesFlown"))


                lstEachAttendanttotalFlown.Items.Add("  ")
                lstEachAttendanttotalFlown.Items.Add("=======================================")

            End While


            ' Clean up
            drSourceTable.Close()

            ' close the database connection
            CloseDatabaseConnection()

        Catch ex As Exception

            ' Log and display error message
            MessageBox.Show(ex.Message)

        End Try



    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Close()
    End Sub
End Class