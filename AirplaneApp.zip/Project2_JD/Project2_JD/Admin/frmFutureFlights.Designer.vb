﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFutureFlights
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cboFlightNumber = New System.Windows.Forms.ComboBox()
        Me.cboTimeofDeparture = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cboTimeofLanding = New System.Windows.Forms.ComboBox()
        Me.dtpFlightDate = New System.Windows.Forms.DateTimePicker()
        Me.cboFromAirport = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cboToAirport = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtMilesFLown = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cboPlane = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.btnCreateFlight = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(59, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(58, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Flight Date"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(50, 54)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Flight Number"
        '
        'cboFlightNumber
        '
        Me.cboFlightNumber.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFlightNumber.FormattingEnabled = True
        Me.cboFlightNumber.Items.AddRange(New Object() {"111", "222", "333", "444", "555", "666", "777", "888", "999", "000"})
        Me.cboFlightNumber.Location = New System.Drawing.Point(135, 51)
        Me.cboFlightNumber.Name = "cboFlightNumber"
        Me.cboFlightNumber.Size = New System.Drawing.Size(121, 21)
        Me.cboFlightNumber.TabIndex = 3
        '
        'cboTimeofDeparture
        '
        Me.cboTimeofDeparture.AutoCompleteCustomSource.AddRange(New String() {"1:00:00", "2:00:00", "3:00:00", "4:00:00", "5:00:00", "6:00:00", "7:00:00", "8:00:00", "9:00:00", "10:00:00", "12:00:00", "13:00:00", "14:00:00", "15:00:00", "16:00:00", "17:00:00", "18:00:00", "19:00:00", "20:00:00", "21:00:00", "22:00:00", "23:00:00"})
        Me.cboTimeofDeparture.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTimeofDeparture.FormattingEnabled = True
        Me.cboTimeofDeparture.Items.AddRange(New Object() {"1:00:00", "2:00:00", "3:00:00", "4:00:00", "5:00:00", "6:00:00", "7:00:00", "8:00:00", "9:00:00", "10:00:00", "12:00:00", "13:00:00", "14:00:00", "15:00:00", "16:00:00", "17:00:00", "18:00:00", "19:00:00", "20:00:00", "21:00:00", "22:00:00", "23:00:00"})
        Me.cboTimeofDeparture.Location = New System.Drawing.Point(135, 81)
        Me.cboTimeofDeparture.Name = "cboTimeofDeparture"
        Me.cboTimeofDeparture.Size = New System.Drawing.Size(121, 21)
        Me.cboTimeofDeparture.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(40, 84)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(82, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Flight Departure"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(40, 115)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(83, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Time of Landing"
        '
        'cboTimeofLanding
        '
        Me.cboTimeofLanding.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTimeofLanding.FormattingEnabled = True
        Me.cboTimeofLanding.Items.AddRange(New Object() {"1:00:00", "2:00:00", "3:00:00", "4:00:00", "5:00:00", "6:00:00", "7:00:00", "8:00:00", "9:00:00", "10:00:00", "12:00:00", "13:00:00", "14:00:00", "15:00:00", "16:00:00", "17:00:00", "18:00:00", "19:00:00", "20:00:00", "21:00:00", "22:00:00", "23:00:00", ""})
        Me.cboTimeofLanding.Location = New System.Drawing.Point(135, 111)
        Me.cboTimeofLanding.Name = "cboTimeofLanding"
        Me.cboTimeofLanding.Size = New System.Drawing.Size(121, 21)
        Me.cboTimeofLanding.TabIndex = 7
        '
        'dtpFlightDate
        '
        Me.dtpFlightDate.Location = New System.Drawing.Point(135, 22)
        Me.dtpFlightDate.Name = "dtpFlightDate"
        Me.dtpFlightDate.Size = New System.Drawing.Size(200, 20)
        Me.dtpFlightDate.TabIndex = 8
        '
        'cboFromAirport
        '
        Me.cboFromAirport.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFromAirport.FormattingEnabled = True
        Me.cboFromAirport.Items.AddRange(New Object() {"1:00:00", "2:00:00", "3:00:00", "4:00:00", "5:00:00", "6:00:00", "7:00:00", "8:00:00", "9:00:00", "10:00:00", "12:00:00", "13:00:00", "14:00:00", "15:00:00", "16:00:00", "17:00:00", "18:00:00", "19:00:00", "20:00:00", "21:00:00", "22:00:00", "23:00:00", ""})
        Me.cboFromAirport.Location = New System.Drawing.Point(135, 141)
        Me.cboFromAirport.Name = "cboFromAirport"
        Me.cboFromAirport.Size = New System.Drawing.Size(121, 21)
        Me.cboFromAirport.TabIndex = 10
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(59, 148)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(63, 13)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "From Airport"
        '
        'cboToAirport
        '
        Me.cboToAirport.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboToAirport.FormattingEnabled = True
        Me.cboToAirport.Items.AddRange(New Object() {"1:00:00", "2:00:00", "3:00:00", "4:00:00", "5:00:00", "6:00:00", "7:00:00", "8:00:00", "9:00:00", "10:00:00", "12:00:00", "13:00:00", "14:00:00", "15:00:00", "16:00:00", "17:00:00", "18:00:00", "19:00:00", "20:00:00", "21:00:00", "22:00:00", "23:00:00", ""})
        Me.cboToAirport.Location = New System.Drawing.Point(135, 171)
        Me.cboToAirport.Name = "cboToAirport"
        Me.cboToAirport.Size = New System.Drawing.Size(121, 21)
        Me.cboToAirport.TabIndex = 12
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(69, 178)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 13)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "To Airport"
        '
        'txtMilesFLown
        '
        Me.txtMilesFLown.Location = New System.Drawing.Point(135, 205)
        Me.txtMilesFLown.Name = "txtMilesFLown"
        Me.txtMilesFLown.Size = New System.Drawing.Size(100, 20)
        Me.txtMilesFLown.TabIndex = 13
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(91, 208)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(31, 13)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Miles"
        '
        'cboPlane
        '
        Me.cboPlane.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPlane.FormattingEnabled = True
        Me.cboPlane.Location = New System.Drawing.Point(135, 239)
        Me.cboPlane.Name = "cboPlane"
        Me.cboPlane.Size = New System.Drawing.Size(121, 21)
        Me.cboPlane.TabIndex = 15
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(91, 242)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(34, 13)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "Plane"
        '
        'btnCreateFlight
        '
        Me.btnCreateFlight.Location = New System.Drawing.Point(43, 284)
        Me.btnCreateFlight.Name = "btnCreateFlight"
        Me.btnCreateFlight.Size = New System.Drawing.Size(94, 35)
        Me.btnCreateFlight.TabIndex = 17
        Me.btnCreateFlight.Text = "Create Flight"
        Me.btnCreateFlight.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(212, 284)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(94, 35)
        Me.btnExit.TabIndex = 18
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmFutureFlights
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(347, 346)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCreateFlight)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.cboPlane)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtMilesFLown)
        Me.Controls.Add(Me.cboToAirport)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.cboFromAirport)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.dtpFlightDate)
        Me.Controls.Add(Me.cboTimeofLanding)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cboTimeofDeparture)
        Me.Controls.Add(Me.cboFlightNumber)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmFutureFlights"
        Me.Text = "frmFutureFlights"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents cboFlightNumber As ComboBox
    Friend WithEvents cboTimeofDeparture As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents cboTimeofLanding As ComboBox
    Friend WithEvents dtpFlightDate As DateTimePicker
    Friend WithEvents cboFromAirport As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents cboToAirport As ComboBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtMilesFLown As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents cboPlane As ComboBox
    Friend WithEvents Label8 As Label
    Friend WithEvents btnCreateFlight As Button
    Friend WithEvents btnExit As Button
End Class
