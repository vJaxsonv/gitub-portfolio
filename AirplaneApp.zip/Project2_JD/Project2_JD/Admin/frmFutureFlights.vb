﻿Public Class frmFutureFlights
    Private Sub cboFlightDate_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub frmFutureFlights_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSelect As String = ""
        Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
        Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
        Dim drSourceTable2 As OleDb.OleDbDataReader

        Dim drSourceTable3 As OleDb.OleDbDataReader
        Dim dt3 As DataTable = New DataTable

        Dim dt2 As DataTable = New DataTable
        Dim dt As DataTable = New DataTable ' this is the table we will load from our reader
        Try
            ' open the DB this is in module
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                "The application will now close.",
                                Me.Text + " Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If


            ' Build the select statement
            strSelect = "SELECT intAirportID, strAirportCity  FROM TAirports"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            ' load table from data reader
            dt.Load(drSourceTable)

            ' Add the item to the combo box. We need the player ID associated with the name so 
            ' when we click on the name we can then use the ID to pull the rest of the players data.
            ' We are binding the column name to the combo box display and value members. 
            cboFromAirport.ValueMember = "intAirportID"
            cboFromAirport.DisplayMember = "strAirportCity"
            cboFromAirport.DataSource = dt

            ' Select the first item in the list by default
            If cboFromAirport.Items.Count > 0 Then cboFromAirport.SelectedIndex = 0

            ' Clean up
            drSourceTable.Close()



            strSelect = "SELECT intAirportID, strAirportCity  FROM TAirports"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable2 = cmdSelect.ExecuteReader

            ' load table from data reader
            dt2.Load(drSourceTable2)

            ' Add the item to the combo box. We need the player ID associated with the name so 
            ' when we click on the name we can then use the ID to pull the rest of the players data.
            ' We are binding the column name to the combo box display and value members. 
            cboToAirport.ValueMember = "intAirportID"
            cboToAirport.DisplayMember = "strAirportCity"
            cboToAirport.DataSource = dt2

            ' Select the first item in the list by default
            If cboFromAirport.Items.Count > 0 Then cboFromAirport.SelectedIndex = 0

            ' Clean up
            drSourceTable2.Close()




            strSelect = "SELECT intPlaneID, strPlaneNumber  FROM TPlanes"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable3 = cmdSelect.ExecuteReader

            ' load table from data reader
            dt3.Load(drSourceTable3)

            ' Add the item to the combo box. We need the player ID associated with the name so 
            ' when we click on the name we can then use the ID to pull the rest of the players data.
            ' We are binding the column name to the combo box display and value members. 
            cboPlane.ValueMember = "intPlane"
            cboPlane.DisplayMember = "strPlaneNumber"
            cboPlane.DataSource = dt3

            ' Select the first item in the list by default
            If cboFromAirport.Items.Count > 0 Then cboFromAirport.SelectedIndex = 0

            ' Clean up
            drSourceTable3.Close()





            ' close the database connection
            CloseDatabaseConnection()

        Catch excError As Exception

            ' Log and display error message
            MessageBox.Show(excError.Message)

        End Try
    End Sub

    Private Sub btnCreateFlight_Click(sender As Object, e As EventArgs) Handles btnCreateFlight.Click
        Dim dtmFlightDate As Date
        Dim strFlightNumber As String
        Dim dtmDateofDeparture As String
        Dim dtmTimeofLanding As String
        Dim strFromAirport As String
        Dim strToAirport As String
        Dim intFromAirport As Integer
        Dim intToAirport As Integer
        Dim strMiles As String
        Dim strPlane As String
        Dim strSelect As String
        Dim strInsert As String
        Dim result As String
        Dim intPlaneID As Integer
        Dim cmdSelect As OleDb.OleDbCommand ' select command object
        Dim cmdInsert As OleDb.OleDbCommand ' insert command object
        Dim drSourceTable As OleDb.OleDbDataReader ' data reader for pulling info
        Dim intNextPrimaryKey As Integer ' holds next highest PK value
        Dim intRowsAffected As Integer  ' how many rows were affected when sql executed

        Try


            ' validate data is entered


            ' put values into strings
            dtmFlightDate = Convert.ToDateTime(dtpFlightDate.Value)
            strFlightNumber = cboFlightNumber.SelectedItem.ToString
            dtmDateofDeparture = cboTimeofDeparture.SelectedItem.ToString
            dtmTimeofLanding = cboTimeofLanding.SelectedItem.ToString
            strFromAirport = cboFromAirport.SelectedItem("strAirportCity").ToString
            strToAirport = cboToAirport.SelectedItem("strAirportCity").ToString
            strMiles = txtMilesFLown.Text
            strPlane = cboPlane.SelectedItem("strPlaneNumber").ToString()

            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                        "The application will now close.",
                                        Me.Text + " Error",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If
            result = MessageBox.Show("Are you sure you want to Add the Pilot?", "Confirm Deletion", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)

            ' this will figure out which button was selected. Cancel and No does nothing, Yes will allow deletion
            Select Case result
                Case DialogResult.Cancel
                    MessageBox.Show("Action Canceled")
                Case DialogResult.No
                    MessageBox.Show("Action Canceled")
                Case DialogResult.Yes

                    strSelect = "SELECT MAX(intFlightID) + 1 AS intNextFlightPrimaryKey " &
                       "FROM TFlights"

                    ' Execute command
                    cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
                    drSourceTable = cmdSelect.ExecuteReader

                    ' Read result( highest ID )
                    drSourceTable.Read()

                    ' Null? (empty table)
                    If drSourceTable.IsDBNull(0) = True Then

                        ' Yes, start numbering at 1
                        intNextPrimaryKey = 1

                    Else

                        ' No, get the next highest ID
                        intNextPrimaryKey = CInt(drSourceTable("intNextFlightPrimaryKey"))

                    End If

                    'Checking what city
                    If strFromAirport = "Cincinnati" Then
                        intFromAirport = 1
                    ElseIf strFromAirport = "Miami" Then
                        intFromAirport = 2
                    ElseIf strFromAirport = "Ft. Meyer" Then
                        intFromAirport = 3
                    ElseIf strFromAirport = "Louisville" Then
                        intFromAirport = 4
                    ElseIf strFromAirport = "Denver" Then
                        intFromAirport = 5
                    ElseIf strFromAirport = "Orlando" Then
                        intFromAirport = 6
                    End If

                    'Checking what city
                    If strToAirport = "Cincinnati" Then
                        intToAirport = 1
                    ElseIf strToAirport = "Miami" Then
                        intToAirport = 2
                    ElseIf strToAirport = "Ft. Meyer" Then
                        intToAirport = 3
                    ElseIf strToAirport = "Louisville" Then
                        intToAirport = 4
                    ElseIf strToAirport = "Denver" Then
                        intToAirport = 5
                    ElseIf strToAirport = "Orlando" Then
                        intToAirport = 6
                    End If

                    'Checking which plane
                    If strPlane = "4X887G" Then
                        intPlaneID = 1
                    ElseIf strPlane = "5HT78F" Then
                        intPlaneID = 2
                    ElseIf strPlane = "5TYY65" Then
                        intPlaneID = 3
                    ElseIf strPlane = "4UR522" Then
                        intPlaneID = 4
                    ElseIf strPlane = "6OP3PK" Then
                        intPlaneID = 5
                    ElseIf strPlane = "67TYHH" Then
                        intPlaneID = 6
                    End If



                    strInsert = "INSERT INTO TFlights (intFlightID, dtmFlightDate, strFlightNumber, dtmTimeofDeparture, dtmTimeOfLanding, intFromAirportID, intToAirportID, intMilesFlown, intPlaneID) " &
                                "VALUES (" & intNextPrimaryKey & ", '" & dtmFlightDate.ToString("yyyy-MM-dd") & "', '" & strFlightNumber & "', '" & dtmDateofDeparture & "', '" & dtmTimeofLanding & "', " & intFromAirport & ", " & intToAirport & ", " & strMiles & ", " & intPlaneID & ")"


                    MessageBox.Show(strInsert)

                    ' use insert command with sql string and connection object
                    cmdInsert = New OleDb.OleDbCommand(strInsert, m_conAdministrator)

                    ' execute query to insert data
                    intRowsAffected = cmdInsert.ExecuteNonQuery()

                    ' If not 0 insert successful
                    If intRowsAffected > 0 Then
                        MessageBox.Show("Flights" & " has been added ")
                        ' close new player form
                    End If

            End Select
            CloseDatabaseConnection()       ' close connection if insert didn't work
            Close()



        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try




















    End Sub
End Class