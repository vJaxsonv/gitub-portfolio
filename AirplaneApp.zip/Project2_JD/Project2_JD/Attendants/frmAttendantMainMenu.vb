﻿Public Class frmAttendantMainMenu
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim frmUpdateAttendant As New frmAttendantUpdate
        ' Pass the strCustomer value to frmUpdateCustomer

        frmAttendantUpdate.ShowDialog()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnPastFlights.Click
        Dim frmAttendantPastFlights As New frmAttendantPastFlights
        frmAttendantPastFlights.ShowDialog()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles btnFutureFlights.Click
        Dim frmAttendantFutureFlights As New frmAttendantFutureFlights
        frmAttendantFutureFlights.ShowDialog()
    End Sub

    Private Sub frmAttendantMainMenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class