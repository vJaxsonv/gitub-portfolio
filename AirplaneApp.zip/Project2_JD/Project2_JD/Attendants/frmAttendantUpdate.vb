﻿Public Class frmAttendantUpdate
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click

        Dim strFirstName As String
        Dim strLastName As String
        Dim strID As String
        Dim strDateofHire As String
        Dim strDateofTermination As String

        Dim blnvalidated As Boolean = True
        Dim strAttendantUsername As String
        Dim strAttedantPassword As String

        Dim intRowsAffected As Integer = 0
        Dim cmdUpdate As New OleDb.OleDbCommand
        Dim cmdUpdate2 As New OleDb.OleDbCommand
        Dim intRowsAffected2 As Integer = 0
        ' Validate input
        Call Get_Validate_Input(strFirstName, strLastName, strID, blnvalidated)

        If blnvalidated = True Then
            Try
                ' Open database connection
                If Not OpenDatabaseConnectionSQLServer() Then
                    MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                            "The application will now close.",
                                            Me.Text + " Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Close()
                    Return
                End If

                strFirstName = txtFirstName.Text.Trim()
                strLastName = txtLastName.Text.Trim()
                strID = txtID.Text.Trim()
                strDateofHire = dtmDateofHire.Value.ToString("yyyy-MM-dd")
                strDateofTermination = dtmDateofTermination.Value.ToString("yyyy-MM-dd")

                strAttendantUsername = txtPilotsUserName.Text.Trim()
                strAttedantPassword = txtPilotsPassword.Text.Trim()


                cmdUpdate = New OleDb.OleDbCommand("uspUpdateAttendants", m_conAdministrator)
                cmdUpdate.CommandType = CommandType.StoredProcedure

                cmdUpdate.Parameters.AddWithValue("@AttendantID", strAttendant)
                cmdUpdate.Parameters.AddWithValue("@FirstName", strFirstName)
                cmdUpdate.Parameters.AddWithValue("@LastName", strLastName)
                cmdUpdate.Parameters.AddWithValue("@ID", strID)
                cmdUpdate.Parameters.AddWithValue("@DateOfHire", strDateofHire)
                cmdUpdate.Parameters.AddWithValue("@DateOfTermination", strDateofTermination)



                intRowsAffected = cmdUpdate.ExecuteNonQuery()

                If intRowsAffected > 0 Then
                    MessageBox.Show("Attendant update successful")
                Else
                    MessageBox.Show("Attendant update failed")
                End If


                cmdUpdate2 = New OleDb.OleDbCommand("uspUpdateEmployeeUsernameandPassword", m_conAdministrator)
                cmdUpdate2.CommandType = CommandType.StoredProcedure

                cmdUpdate2.Parameters.AddWithValue("@Username", strAttendantUsername)
                cmdUpdate2.Parameters.AddWithValue("@Password", strAttedantPassword)
                cmdUpdate2.Parameters.AddWithValue("@EmployeeID", strEmployee)
                cmdUpdate2.Parameters.AddWithValue("@Role", 1)


                intRowsAffected2 = cmdUpdate2.ExecuteNonQuery()

                If intRowsAffected2 > 0 Then
                    MessageBox.Show("Employee username and password update successful")
                Else
                    MessageBox.Show("Employee username and password update failed")
                End If
            Catch ex As Exception
                MessageBox.Show("An error occurred: " & ex.Message)
            Finally
                ' Ensure the database connection is closed
                CloseDatabaseConnection()
            End Try
        End If
    End Sub



    Private Sub Get_Validate_Input(ByRef strfirstname As String, strlastname As String, ByRef strID As Double, ByRef blnvalidated As Boolean)
        Call Get_Validate_FirstName_and_LastName(strfirstname, strlastname, blnvalidated)
        If blnvalidated = True Then
            Call Get_Validate_ID(strID, blnvalidated)
        End If





    End Sub
    'Validating Names
    Private Sub Get_Validate_FirstName_and_LastName(ByRef strfirstname As String, ByRef strlastname As String, blnvalidate As Boolean)
        If txtFirstName.Text = String.Empty Then
            MessageBox.Show("First Name is Required")
            txtFirstName.Focus()
            Exit Sub
        End If

        If txtLastName.Text = "" Then
            MessageBox.Show("Last Name is Required")
            txtLastName.Focus()
            Exit Sub
        End If
    End Sub
    'Validating Hours Worked
    Private Sub Get_Validate_ID(ByRef strID As String, ByRef blnvalidated As Boolean)
        If txtID.Text = String.Empty Then
            MessageBox.Show("ID is Required")
            txtID.Focus()
            Exit Sub
        End If
    End Sub





    Private Sub frmUpdatePilot_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSelect As String
        Dim strSelectEmployee As String
        Dim cmdSelect As OleDb.OleDbCommand
        Dim cmdSelect2 As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim drSourceTable2 As OleDb.OleDbDataReader
        Try
            ' Open database connection
            If Not OpenDatabaseConnectionSQLServer() Then
                MessageBox.Show(Me, "Database connection error." & vbNewLine & "The application will now close.",
                        Me.Text + " Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Close()
                Exit Sub
            End If


            strSelect = "SELECT strFirstName, strLastName, strEmployeeID, dtmDateofHire, dtmDateofTermination, " &
                "intEmployeeID FROM TAttendants as TA " &
                "WHERE TA.intAttendantID = " & strAttendant

            strSelectEmployee = "SELECT strEmployeeLoginID, strEmployeePassword, intRoleID FROM TEmployees as TE " &
                    "WHERE TE.intEmployeeID = " & strEmployee


            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            cmdSelect2 = New OleDb.OleDbCommand(strSelectEmployee, m_conAdministrator)

            drSourceTable = cmdSelect.ExecuteReader()
            drSourceTable2 = cmdSelect2.ExecuteReader()

            If drSourceTable.Read() Then

                txtFirstName.Text = (drSourceTable("strFirstName")).ToString
                txtLastName.Text = (drSourceTable("strLastName")).ToString
                txtID.Text = (drSourceTable("strEmployeeID")).ToString
                dtmDateofHire.Value = Convert.ToDateTime(drSourceTable("dtmDateofHire"))
                dtmDateofTermination.Value = Convert.ToDateTime(drSourceTable("dtmDateofTermination"))
            End If
            If drSourceTable2.Read() Then
                txtPilotsUserName.Text = (drSourceTable2("strEmployeeLoginID"))
                txtPilotsPassword.Text = (drSourceTable2("strEmployeePassword"))
            End If
        Catch ex As Exception
            MessageBox.Show("An error occurred: " & ex.Message)
        Finally


            CloseDatabaseConnection()
        End Try
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

End Class