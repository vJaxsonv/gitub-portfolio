﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAddFlight
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnAddFlight = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.cboFlights = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.radReserved = New System.Windows.Forms.RadioButton()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.lblReservedCost = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cboSeat = New System.Windows.Forms.ComboBox()
        Me.lblDesignated = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnAddFlight
        '
        Me.btnAddFlight.Location = New System.Drawing.Point(25, 211)
        Me.btnAddFlight.Name = "btnAddFlight"
        Me.btnAddFlight.Size = New System.Drawing.Size(75, 23)
        Me.btnAddFlight.TabIndex = 0
        Me.btnAddFlight.Text = "Add Flight"
        Me.btnAddFlight.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(211, 211)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 1
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'cboFlights
        '
        Me.cboFlights.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFlights.FormattingEnabled = True
        Me.cboFlights.Location = New System.Drawing.Point(70, 61)
        Me.cboFlights.Name = "cboFlights"
        Me.cboFlights.Size = New System.Drawing.Size(240, 21)
        Me.cboFlights.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 64)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Flight"
        '
        'radReserved
        '
        Me.radReserved.AutoSize = True
        Me.radReserved.Location = New System.Drawing.Point(25, 140)
        Me.radReserved.Name = "radReserved"
        Me.radReserved.Size = New System.Drawing.Size(96, 17)
        Me.radReserved.TabIndex = 4
        Me.radReserved.TabStop = True
        Me.radReserved.Text = "Reserved Seat"
        Me.radReserved.UseVisualStyleBackColor = True
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(25, 179)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(104, 17)
        Me.RadioButton2.TabIndex = 5
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "Designated Seat"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'lblReservedCost
        '
        Me.lblReservedCost.Location = New System.Drawing.Point(186, 140)
        Me.lblReservedCost.Name = "lblReservedCost"
        Me.lblReservedCost.Size = New System.Drawing.Size(100, 17)
        Me.lblReservedCost.TabIndex = 6
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 95)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Seat:"
        '
        'cboSeat
        '
        Me.cboSeat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSeat.FormattingEnabled = True
        Me.cboSeat.Location = New System.Drawing.Point(70, 92)
        Me.cboSeat.Name = "cboSeat"
        Me.cboSeat.Size = New System.Drawing.Size(152, 21)
        Me.cboSeat.TabIndex = 7
        '
        'lblDesignated
        '
        Me.lblDesignated.Location = New System.Drawing.Point(186, 178)
        Me.lblDesignated.Name = "lblDesignated"
        Me.lblDesignated.Size = New System.Drawing.Size(90, 18)
        Me.lblDesignated.TabIndex = 9
        '
        'frmAddFlight
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(336, 261)
        Me.Controls.Add(Me.lblDesignated)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cboSeat)
        Me.Controls.Add(Me.lblReservedCost)
        Me.Controls.Add(Me.RadioButton2)
        Me.Controls.Add(Me.radReserved)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cboFlights)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnAddFlight)
        Me.Name = "frmAddFlight"
        Me.Text = "Book Flight:"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnAddFlight As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents cboFlights As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents radReserved As RadioButton
    Friend WithEvents RadioButton2 As RadioButton
    Friend WithEvents lblReservedCost As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents cboSeat As ComboBox
    Friend WithEvents lblDesignated As Label
End Class
