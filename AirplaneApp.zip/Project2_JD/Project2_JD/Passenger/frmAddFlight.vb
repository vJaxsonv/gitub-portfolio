﻿Public Class frmAddFlight
    Private Sub btnAddFlight_Click(sender As Object, e As EventArgs) Handles btnAddFlight.Click
        ' variables for new player data and select and insert statements
        Dim strSelect As String
        Dim strInsert As String
        Dim intPassenger As Integer
        Dim intFlight As Integer
        Dim strseat As String
        Dim cmdSelect As OleDb.OleDbCommand ' select command object
        Dim cmdInsert As OleDb.OleDbCommand ' insert command object
        Dim drSourceTable As OleDb.OleDbDataReader ' data reader for pulling info
        Dim intNextPrimaryKey As Integer ' holds next highest PK value
        Dim intRowsAffected As Integer  ' how many rows were affected when sql executed
        Dim dblreservedcost As Double

        Try


            ' validate data is entered


            ' put values into strings

            intFlight = cboFlights.SelectedValue
            intPassenger = strPassenger
            strseat = cboSeat.SelectedItem("strSeat").ToString()

            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                        "The application will now close.",
                                        Me.Text + " Error",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            strSelect = "SELECT MAX(intFlightPassengerID) + 1 AS intNextPassengerPrimaryKey " &
                            " FROM TFlightPassengers"

            ' Execute command
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            ' Read result( highest ID )
            drSourceTable.Read()

            ' Null? (empty table)
            If drSourceTable.IsDBNull(0) = True Then

                ' Yes, start numbering at 1
                intNextPrimaryKey = 1

            Else

                ' No, get the next highest ID
                intNextPrimaryKey = CInt(drSourceTable("intNextPassengerPrimaryKey"))

            End If

            If radReserved.Checked Then
                dblreservedcost = lblReservedCost.Text
            Else
                dblreservedcost = lblDesignated.Text
            End If
            ' build insert statement (columns must match DB columns in name and the # of columns)
            strInsert = "INSERT INTO TFlightPassengers (intFlightPassengerID, intFlightID, intPassengerID, strSeat, dlbFlightCost)" &
            " VALUES (" & intNextPrimaryKey & "," & intFlight & "," & intPassenger & ",'" & strseat.ToString() & "','" & dblreservedcost & "')"


            MessageBox.Show(strInsert)

            ' use insert command with sql string and connection object
            cmdInsert = New OleDb.OleDbCommand(strInsert, m_conAdministrator)

            ' execute query to insert data
            intRowsAffected = cmdInsert.ExecuteNonQuery()

            ' If not 0 insert successful
            If intRowsAffected > 0 Then
                MessageBox.Show(cboSeat.Text & " has been added to " & cboFlights.Text)    ' let user know success
                ' close new player form
            End If


            CloseDatabaseConnection()       ' close connection if insert didn't work
            Close()



        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub


    Private Sub frmAddFlight_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        '
        '  On the event Form Load, we are going to populate the comboboxes of City, State, and Race from 
        '  the database
        '

        Try

            Dim strSelect As String = ""
            Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
            Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
            Dim dtc As DataTable = New DataTable ' this is the table we will load from our reader for City
            Dim dts As DataTable = New DataTable ' this is the table we will load from our reader for State
            Dim dtr As DataTable = New DataTable ' this is the table we will load from our reader for Race
            Dim dtPassengers As DataTable = New DataTable
            Dim dtFlights As DataTable = New DataTable
            Dim dtFlights1 As DataTable = New DataTable


            ' open the DB
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If


            ' Build the select statement


            strSelect = "SELECT TF.intFlightID, TPF.strPlaneType, TF.strFlightNumber, TF.dtmFlightDate, TF.dtmTimeofDeparture, TF.dtmTimeOfLanding, TAF.strAirportCode, " &
                               "TF.intFlightID + TPF.intPlaneTypeID + TAF.intAirportID AS FlightIDPlaneType, " &
                               "TPF.strPlaneType + ' ' + TF.strFlightNumber + CONVERT(VARCHAR, TF.dtmFlightDate, 120) + ' ' + CONVERT(VARCHAR, TF.dtmTimeofDeparture, 108) + ' - ' + CONVERT(VARCHAR, TF.dtmTimeOfLanding, 108) + TAF.strAirportCity AS FlightDisplay " &
                               "FROM TFlights TF " &
                               "JOIN TAirports TAF ON TF.intToAirportID = TAF.intAirportID " &
                               "JOIN TPlanes TP ON TP.intPlaneID = TF.intPlaneID " &
                               "JOIN TPlaneTypes TPF ON TP.intPlaneTypeID = TPF.intPlaneTypeID " &
                               "WHERE TF.dtmFlightDate >= GETDATE()"

            ' Create and execute the command
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            ' Load table from data reader
            dtFlights.Load(drSourceTable)



            ' Add the item to the combo box
            cboFlights.ValueMember = "FlightIDPlaneType"
            cboFlights.DisplayMember = "FlightDisplay"
            cboFlights.DataSource = dtFlights

            ' Check if the necessary columns are present in dtFlights

            drSourceTable.Close()



            strSelect = "SELECT intFlightPassengerID, strSeat FROM TFlightPassengers"


            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            ' load table from data reader
            dtPassengers.Load(drSourceTable)

            ' Add the item to the combo box. We need the player ID associated with the name so 
            ' when we click on the name we can then use the ID to pull the rest of the players data.
            ' We are binding the column name to the combo box display and value members. 
            cboSeat.ValueMember = "intFlightPassengerID"
            cboSeat.DisplayMember = "strSeat"
            cboSeat.DataSource = dtPassengers

            ' Clean up
            drSourceTable.Close()

            ' close the database connection
            CloseDatabaseConnection()

        Catch ex As Exception

            ' Log and display error message
            MessageBox.Show(ex.Message)

        End Try
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles radReserved.CheckedChanged
        Dim strSelect As String = ""


        Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement

        Dim dblreservedcost As Decimal

        Dim strplane As String
        Dim strAirportCode As String

        Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
        Dim dtc As DataTable = New DataTable ' this is the table we will load from our reader for City
        Dim dts As DataTable = New DataTable ' this is the table we will load from our reader for State
        Dim dtr As DataTable = New DataTable ' this is the table we will load from our reader for Race
        Dim dtPassengers As DataTable = New DataTable
        Dim dtFlights As DataTable = New DataTable

        Dim intPassengerID As Integer


        Dim intPreviousFlights As Integer

        Dim intCountPassengers As String
        Dim dbltotalMiles As Double

        Dim strpassengerDateOfBirth1 As DateTime
        Dim intage As Integer
        Dim GETDATE As DateTime = DateTime.Today
        Dim intflightID As Integer
        Try
            ' Open the database connection
            If OpenDatabaseConnectionSQLServer() = False Then
                ' Warn the user if the database connection fails
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                            "The application will now close.",
                            Me.Text + " Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error)
                ' Close the form/application
                Me.Close()
            End If


            dblreservedcost += 250 + 125


            strAirportCode = cboFlights.SelectedItem("strAirportCode").ToString()






            strSelect = "SELECT strPassengerDateofBirth " & " FROM TPassengers Where intPassengerID = '" & strPassenger & "'"

            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            drSourceTable.Read()
            strpassengerDateOfBirth1 = Convert.ToDateTime(drSourceTable("strPassengerDateofBirth"))

            intage = Today.Year - strpassengerDateOfBirth1.Year

            If intage >= 65 Then
                dblreservedcost = dblreservedcost * 0.2
            Else
                If intage <= 5 Then
                    dblreservedcost = dblreservedcost * 0.65
                End If
            End If


            strSelect = "SELECT intPassengerID " & " FROM TPassengers Where intPassengerID = '" & strPassenger & "'"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            drSourceTable.Read()

            intPassengerID = (drSourceTable("intPassengerID"))







            'Getting Plane Type


            strplane = cboFlights.SelectedItem("strPlaneType").ToString()



            If strplane = "Airbus A350" Then
                dblreservedcost += 35
            Else
                If strplane = "Boeing 747-8" Then
                    dblreservedcost -= 25
                End If
            End If

            intflightID = cboFlights.SelectedItem("intFlightID")


            'Getting COUNT PASSENGERS
            cmdSelect = New OleDb.OleDbCommand("uspCountPassengersforEachFLight", m_conAdministrator)
            cmdSelect.CommandType = CommandType.StoredProcedure


            cmdSelect.Parameters.AddWithValue("@intFlightID", intflightID)
            drSourceTable = cmdSelect.ExecuteReader()

            drSourceTable.Read()

            intCountPassengers = (drSourceTable("PassengerCount"))


            If intCountPassengers > 8 Then
                dblreservedcost += 100
            Else
                If intCountPassengers < 4 Then
                    dblreservedcost -= 50
                End If
            End If


            'GETTING PREVIOUSFLIGHTS

            'Getting Previous Flights
            cmdSelect = New OleDb.OleDbCommand("uspCountPassengerPastFlights", m_conAdministrator)
            cmdSelect.CommandType = CommandType.StoredProcedure


            cmdSelect.Parameters.AddWithValue("@intPassengerID", strPassenger)
            drSourceTable = cmdSelect.ExecuteReader()


            If drSourceTable.Read() Then
                If Not drSourceTable.IsDBNull(0) Then
                    intPreviousFlights = (drSourceTable("PastFlightCount"))

                    If intPreviousFlights >= 5 Then
                        dblreservedcost -= dblreservedcost * 0.01
                    End If
                    If intPreviousFlights = 10 Then
                        dblreservedcost -= dblreservedcost * 0.02
                    End If
                Else
                    ' Handle the case where the value is DBNull by setting a default value of 0
                    intPreviousFlights = 0
                End If
            Else

                intPreviousFlights = 0
            End If




            cmdSelect = New OleDb.OleDbCommand("uspTotalMilesFlownforPassenger", m_conAdministrator)
            cmdSelect.CommandType = CommandType.StoredProcedure


            cmdSelect.Parameters.AddWithValue("@intPassengerID", strPassenger)

            drSourceTable = cmdSelect.ExecuteReader()

            If drSourceTable.Read() Then
                If Not drSourceTable.IsDBNull(0) Then
                    dbltotalMiles = drSourceTable("TotalMilesFlown")

                    If dbltotalMiles > 750 Then
                        dblreservedcost += 50
                    End If
                Else
                    dbltotalMiles = 0
                End If
            Else
                dbltotalMiles = 0

            End If


            strAirportCode = cboFlights.SelectedItem("strAirportCode").ToString()

            If strAirportCode = "MIA" Then
                dblreservedcost += 15
            End If



            lblReservedCost.Text = dblreservedcost


        Catch ex As Exception
            MessageBox.Show("An error occurred: " & ex.Message)
        Finally
            CloseDatabaseConnection()
        End Try

    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        Dim strSelect As String = ""


        Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
        Dim cmdSelect2 As OleDb.OleDbCommand ' this will be used for our Select statement
        Dim dbldesignatedcost As Decimal
        Dim strplane As String
        Dim strAirportCode As String
        Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
        Dim dtc As DataTable = New DataTable ' this is the table we will load from our reader for City
        Dim dts As DataTable = New DataTable ' this is the table we will load from our reader for State
        Dim dtr As DataTable = New DataTable ' this is the table we will load from our reader for Race
        Dim dtPassengers As DataTable = New DataTable
        Dim dtFlights As DataTable = New DataTable
        Dim intPassengerID As Integer
        Dim intPreviousFlights As Integer
        Dim intCountPassengers As String
        Dim dbltotalMiles As Double
        Dim strpassengerDateOfBirth1 As DateTime
        Dim intage As Integer
        Dim GETDATE As DateTime = DateTime.Today
        Dim intflightID As Integer
        Try
            ' Open the database connection
            If OpenDatabaseConnectionSQLServer() = False Then
                ' Warn the user if the database connection fails
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                            "The application will now close.",
                            Me.Text + " Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error)
                ' Close the form/application
                Me.Close()
            End If


            dbldesignatedcost += 250


            strAirportCode = cboFlights.SelectedItem("strAirportCode").ToString()


            strSelect = "SELECT strPassengerDateofBirth " & " FROM TPassengers Where intPassengerID = '" & strPassenger & "'"

            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            drSourceTable.Read()
            strpassengerDateOfBirth1 = Convert.ToDateTime(drSourceTable("strPassengerDateofBirth"))

            intage = Today.Year - strpassengerDateOfBirth1.Year

            If intage >= 65 Then
                dbldesignatedcost = dbldesignatedcost * 0.8
            Else
                If intage <= 5 Then
                    dbldesignatedcost = dbldesignatedcost * 0.35
                End If
            End If


            strSelect = "SELECT intPassengerID " & " FROM TPassengers Where intPassengerID = '" & strPassenger & "'"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            drSourceTable.Read()

            intPassengerID = (drSourceTable("intPassengerID"))





            'Getting Plane Type


            strplane = cboFlights.SelectedItem("strPlaneType").ToString()



            If strplane = "Airbus A350" Then
                dbldesignatedcost += 35
            Else
                If strplane = "Boeing 747-8" Then
                    dbldesignatedcost -= 25
                End If
            End If

            intflightID = cboFlights.SelectedItem("intFlightID")





            'Getting COUNT PASSENGERS
            cmdSelect = New OleDb.OleDbCommand("uspCountPassengersforEachFLight", m_conAdministrator)
            cmdSelect.CommandType = CommandType.StoredProcedure


            cmdSelect.Parameters.AddWithValue("@intFlightID", intflightID)
            drSourceTable = cmdSelect.ExecuteReader()

            drSourceTable.Read()

            intCountPassengers = (drSourceTable("PassengerCount"))


            If intCountPassengers > 8 Then
                dbldesignatedcost += 100
            Else
                If intCountPassengers < 4 Then
                    dbldesignatedcost -= 50
                End If
            End If





            'GETTING PREVIOUSFLIGHTS

            'Getting Previous Flights
            cmdSelect = New OleDb.OleDbCommand("uspCountPassengerPastFlights", m_conAdministrator)
            cmdSelect.CommandType = CommandType.StoredProcedure


            cmdSelect.Parameters.AddWithValue("@intPassengerID", strPassenger)
            drSourceTable = cmdSelect.ExecuteReader()


            If drSourceTable.Read() Then
                If Not drSourceTable.IsDBNull(0) Then
                    intPreviousFlights = (drSourceTable("PastFlightCount"))

                    If intPreviousFlights >= 5 Then
                        dbldesignatedcost -= dbldesignatedcost * 0.01
                    End If
                    If intPreviousFlights = 10 Then
                        dbldesignatedcost -= dbldesignatedcost * 0.02
                    End If
                Else
                    ' Handle the case where the value is DBNull by setting a default value of 0
                    intPreviousFlights = 0
                End If
            Else

                intPreviousFlights = 0
            End If




            cmdSelect = New OleDb.OleDbCommand("uspTotalMilesFlownforPassenger", m_conAdministrator)
            cmdSelect.CommandType = CommandType.StoredProcedure


            cmdSelect.Parameters.AddWithValue("@intPassengerID", strPassenger)

            drSourceTable = cmdSelect.ExecuteReader()

            If drSourceTable.Read() Then
                If Not drSourceTable.IsDBNull(0) Then
                    dbltotalMiles = drSourceTable("TotalMilesFlown")

                    If dbltotalMiles > 750 Then
                        dbldesignatedcost += 50
                    End If
                Else
                    dbltotalMiles = 0
                End If
            Else
                dbltotalMiles = 0

            End If


            strAirportCode = cboFlights.SelectedItem("strAirportCode").ToString()

            If strAirportCode = "MIA" Then
                dbldesignatedcost += 15
            End If



            lblDesignated.Text = dbldesignatedcost


        Catch ex As Exception
            MessageBox.Show("An error occurred: " & ex.Message)
        Finally
            CloseDatabaseConnection()
        End Try


    End Sub

End Class