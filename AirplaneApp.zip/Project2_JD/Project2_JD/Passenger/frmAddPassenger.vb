﻿Public Class frmAddPassenger
    Private Sub btnAddPassenger_Click(sender As Object, e As EventArgs) Handles btnAddPassenger.Click

        ' variables for new player data and select and insert statements
        Dim strSelect As String
        Dim strInsert As String
        Dim strFirstName As String
        Dim strLastName As String
        Dim strAddress As String
        Dim StrCity As String
        Dim intState As Integer
        Dim dtmDateofBirth As Date
        Dim strZip As String
        Dim strEmail As String
        Dim strPassengerUsername As String
        Dim strPassengerPassword As String
        Dim strPhoneNumber As String
        Dim blnvalidated As Boolean = True

        Dim cmdSelect As OleDb.OleDbCommand ' select command object
        Dim cmdInsert As OleDb.OleDbCommand ' insert command object
        Dim drSourceTable As OleDb.OleDbDataReader ' data reader for pulling info
        Dim intNextPrimaryKey As Integer
        Dim intRowsAffected As Integer


        Call Get_Validate_Input(strFirstName, strLastName, strAddress, strZip, strEmail, strPhoneNumber, blnvalidated)
        If blnvalidated = True Then
            Try


                ' validate data is entered


                ' put values into strings
                strFirstName = txtFirstName.Text
                strLastName = txtLastName.Text
                strAddress = txtAddress.Text
                StrCity = txtCity.Text
                intState = cboStates.SelectedValue
                strZip = txtZip.Text
                strEmail = txtEmail.Text
                strPhoneNumber = txtPhoneNumber.Text
                strPassengerUsername = txtPassengerUserName.Text
                strPassengerPassword = txtPassengerPassword.Text
                dtmDateofBirth = DTPPassengerDateofBirth.Value


                If OpenDatabaseConnectionSQLServer() = False Then

                    ' No, warn the user ...
                    MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                            "The application will now close.",
                                            Me.Text + " Error",
                                            MessageBoxButtons.OK, MessageBoxIcon.Error)

                    ' and close the form/application
                    Me.Close()

                End If


                strSelect = "SELECT MAX(intPassengerID) + 1 AS intNextPrimaryKey " &
                                " FROM TPassengers"

                ' Execute command
                cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
                drSourceTable = cmdSelect.ExecuteReader

                ' Read result( highest ID )
                drSourceTable.Read()

                ' Null? (empty table)
                If drSourceTable.IsDBNull(0) = True Then

                    ' Yes, start numbering at 1
                    intNextPrimaryKey = 1

                Else

                    ' No, get the next highest ID
                    intNextPrimaryKey = CInt(drSourceTable("intNextPrimaryKey"))

                End If
                ' build insert statement (columns must match DB columns in name and the # of columns)

                strInsert = "INSERT INTO TPassengers (intPassengerID, strFirstName, strLastName, strAddress, strCity, intStateID, strZip, strPhoneNumber, strEmail, strPassengerUsername, strPassengerPassword, strPassengerDateofBirth) " &
                            "VALUES (" & intNextPrimaryKey & ", '" & strFirstName & "', '" & strLastName & "', '" & strAddress & "', '" & StrCity & "', " & intState & ", '" & strZip & "', '" & strPhoneNumber & "', '" & strEmail & "', '" & strPassengerUsername & "', '" & strPassengerPassword & "', '" & dtmDateofBirth & "')"

                MessageBox.Show(strInsert)

                ' use insert command with sql string and connection object
                cmdInsert = New OleDb.OleDbCommand(strInsert, m_conAdministrator)

                ' execute query to insert data
                intRowsAffected = cmdInsert.ExecuteNonQuery()

                ' If not 0 insert successful
                If intRowsAffected > 0 Then
                    MessageBox.Show("Passengers has been added")    ' let user know success
                    ' close new player form
                End If


                CloseDatabaseConnection()       ' close connection if insert didn't work
                Close()


            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub
    Private Sub Get_Validate_Input(ByRef strfirstname As String, strlastname As String, ByRef straddress As Double, ByRef strZip As String, ByRef strEmail As String, ByRef strPhoneNumber As String, ByRef blnvalidated As Boolean)
        Call Get_Validate_FirstName_and_LastName(strfirstname, strlastname, blnvalidated)
        If blnvalidated = True Then
            Call Get_Validate_Address(straddress, blnvalidated)
        End If
        If blnvalidated = True Then
            Call Get_Validate_Zip(strZip, blnvalidated)
        End If
        If blnvalidated = True Then
            Call Get_Validate_City(blnvalidated)
        End If
        If blnvalidated = True Then
            Call Get_Validate_State(blnvalidated)
        End If
        If blnvalidated = True Then
            Call Get_Validate_PhoneNumber(strPhoneNumber, blnvalidated)
        End If
        If blnvalidated = True Then
            Call Get_Validate_Email(strEmail, blnvalidated)
        End If



    End Sub
    'Validating Names
    Private Sub Get_Validate_FirstName_and_LastName(ByRef strfirstname As String, ByRef strlastname As String, blnvalidate As Boolean)
        If txtFirstName.Text = String.Empty Then
            MessageBox.Show("First Name is Required")
            txtFirstName.Focus()
            Exit Sub
        End If

        If txtLastName.Text = "" Then
            MessageBox.Show("Last Name is Required")
            txtLastName.Focus()
            Exit Sub
        End If
    End Sub
    'Validating Hours Worked
    Private Sub Get_Validate_Address(ByRef straddress As Integer, ByRef blnvalidated As Boolean)
        If txtAddress.Text = String.Empty Then
            MessageBox.Show("Address is Required")
            txtAddress.Focus()
            Exit Sub
        End If
    End Sub

    Private Sub Get_Validate_Zip(ByRef strZip As Double, ByRef blnvalidated As Boolean)
        If txtZip.Text = String.Empty Then
            MessageBox.Show("Zip Code is Required")
            txtZip.Focus()
            Exit Sub
        End If
    End Sub
    Private Sub Get_Validate_City(ByRef blnvalidated As Boolean)
        If txtCity.Text = String.Empty Then
            MessageBox.Show("City selection is required")
            txtCity.Focus()
            Exit Sub
        End If
    End Sub
    Private Sub Get_Validate_State(ByRef blnvalidated As Boolean)
        If txtZip.Text = String.Empty Then
            MessageBox.Show("State is Required")
            cboStates.Focus()
            Exit Sub
        End If
    End Sub
    Private Sub Get_Validate_PhoneNumber(ByRef strPhoneNumber As Double, ByRef blnvalidated As Boolean)
        If txtPhoneNumber.Text = String.Empty Then
            MessageBox.Show("Phone Number is Required")
            txtPhoneNumber.Focus()
            Exit Sub
        End If
    End Sub
    Private Sub Get_Validate_Email(ByRef strEmail As Double, ByRef blnvalidated As Boolean)
        If txtEmail.Text = String.Empty Then
            MessageBox.Show("Email is Required")
            txtEmail.Focus()
            Exit Sub
        End If
        If txtEmail.Text.IndexOf("@") = -1 Then
            MessageBox.Show("Email address is invalid. It must contain '@'.")
            txtEmail.Focus()
            Exit Sub
        End If
    End Sub
    Private Sub frmAddPassenger_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try

            Dim strSelect As String = ""
            Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
            Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
            Dim dtc As DataTable = New DataTable ' this is the table we will load from our reader for City
            Dim dts As DataTable = New DataTable ' this is the table we will load from our reader for State
            Dim dtr As DataTable = New DataTable ' this is the table we will load from our reader for Race

            ' open the DB
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If


            ' Build the select statement
            strSelect = "SELECT intStateID, strState FROM TStates"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            dts.Load(drSourceTable)


            'load the State result set into the combobox.  For VB, we do this by binding the data to the combobox


            cboStates.ValueMember = "intStateID"
            cboStates.DisplayMember = "strState"
            cboStates.DataSource = dts


            ' Clean up
            drSourceTable.Close()

            ' close the database connection
            CloseDatabaseConnection()

        Catch ex As Exception

            ' Log and display error message
            MessageBox.Show(ex.Message)

        End Try
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

End Class