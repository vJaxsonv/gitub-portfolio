﻿Public Class frmPassengerMainMenu
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim frmUpdatePassengerr As New frmUpdatePassenger

        frmUpdatePassenger.ShowDialog()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim frmPassengerPastFlights As New frmPassengerPastFlights
        frmPassengerPastFlights.ShowDialog()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim FrmPassengerFutureFlight As New frmPassengerFutureFlight
        FrmPassengerFutureFlight.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim frmAddFlight As New frmAddFlight
        frmAddFlight.ShowDialog()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class