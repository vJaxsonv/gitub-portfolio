﻿Public Class frmPassengerPastFlights
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

    Private Sub frmPassengerPastFlights_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try

            Dim strSelect As String = ""
            Dim objParam As OleDb.OleDbParameter
            Dim cmdSelect As OleDb.OleDbCommand            ' this will be used for our Select statement
            Dim drSourceTable As OleDb.OleDbDataReader     ' this will be where our result set will 
            Dim dt As DataTable = New DataTable            ' this is the table we will load from our reader


            ' open the DB
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If


            'MessageBox.Show(strSelect)
            cmdSelect = New OleDb.OleDbCommand("uspCountPassengerTotalMilesFlown", m_conAdministrator)
            cmdSelect.CommandType = CommandType.StoredProcedure  ' Specify that the command is a stored procedure

            ' Create and configure the parameter
            objParam = cmdSelect.Parameters.Add("@intPassengerID", OleDb.OleDbType.Integer)
            objParam.Direction = ParameterDirection.Input
            objParam.Value = strPassenger
            drSourceTable = cmdSelect.ExecuteReader



            ' Read result( highest ID )
            drSourceTable.Read()

            ' Null? (empty table)
            If drSourceTable.IsDBNull(0) = True Then

                ' Yes, start numbering at 1
                lblMilesFlown.Text = 0

            Else

                ' No, get the next highest ID
                lblMilesFlown.Text = CInt(drSourceTable("TotalMilesflown"))

            End If
            ' Build the select statement


            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand("uspGetPassengerPastflights", m_conAdministrator)
            cmdSelect.CommandType = CommandType.StoredProcedure

            objParam = cmdSelect.Parameters.Add("@intPassengerID", OleDb.OleDbType.Integer)
            objParam.Direction = ParameterDirection.Input
            objParam.Value = strPassenger
            'loop through result set and display in Listbox
            drSourceTable = cmdSelect.ExecuteReader

            lstResultSet.Items.Add("Flights")
            lstResultSet.Items.Add("  ")
            lstResultSet.Items.Add("=======================================")

            While drSourceTable.Read()

                lstResultSet.Items.Add("  ")
                lstResultSet.Items.Add("  ")
                lstResultSet.Items.Add("Flight Information:")
                lstResultSet.Items.Add("Flight Number: " & vbTab & drSourceTable("strFlightNumber"))
                lstResultSet.Items.Add("Departure Time: " & vbTab & drSourceTable("dtmTimeofDeparture"))
                lstResultSet.Items.Add("Arrival Time: " & vbTab & drSourceTable("dtmTimeofLanding"))
                lstResultSet.Items.Add("Flight Date: " & vbTab & drSourceTable("dtmFlightDate"))
                lstResultSet.Items.Add("  ")
                lstResultSet.Items.Add("============================================================================")
            End While

            ' Clean up
            drSourceTable.Close()

            ' close the database connection
            CloseDatabaseConnection()

        Catch ex As Exception

            ' Log and display error message
            MessageBox.Show(ex.Message)

        End Try
    End Sub
End Class