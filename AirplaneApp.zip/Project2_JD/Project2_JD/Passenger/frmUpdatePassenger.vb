﻿Public Class frmUpdatePassenger
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim strFirstName As String
        Dim strLastName As String
        Dim strAddress As String
        Dim strCity As String
        Dim intState As Integer
        Dim blnvalidated As Boolean = True
        Dim strZip As String
        Dim dtmDateofBirth As DateTime
        Dim strEmail As String
        Dim strPassengerUsername
        Dim strPassengerPassword
        Dim strPhoneNumber As String
        Dim intRowsAffected As Integer
        Dim cmdUpdate As New OleDb.OleDbCommand

        Try
            ' Open database connection
            If OpenDatabaseConnectionSQLServer() = False Then
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                        "The application will now close.",
                                        Me.Text + " Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Close()
                Return
            End If

            ' Retrieve values from UI
            strFirstName = txtFirstName.Text.Trim()
            strLastName = txtLastName.Text.Trim()
            strAddress = txtAddress.Text.Trim()
            strCity = txtCity.Text.Trim()
            intState = cboStates.SelectedValue
            strZip = txtZip.Text.Trim()
            strPhoneNumber = txtPhoneNumber.Text.Trim()
            strEmail = txtEmail.Text.Trim()
            strPassengerPassword = txtPassengerPassword.Text.Trim
            strPassengerUsername = txtPassengerUserName.Text.Trim
            dtmDateofBirth = DTPPassengerDateofBirth.Value

            ' Validate input
            Call Get_Validate_Input(strFirstName, strLastName, strAddress, strCity, strZip, strEmail, strPhoneNumber, blnvalidated)

            If blnvalidated Then
                cmdUpdate.CommandText = "EXECUTE uspUpdatePassenger '" & strPassenger & "','" & strFirstName & "','" & strLastName & "','" & strAddress & "','" & strCity & "','" & intState & "','" & strZip & "','" & strPhoneNumber & "','" & strEmail & "','" & strPassengerUsername & "','" & strPassengerPassword & "','" & dtmDateofBirth & "'"
                cmdUpdate.CommandType = CommandType.StoredProcedure
                cmdUpdate = New OleDb.OleDbCommand(cmdUpdate.CommandText, m_conAdministrator)

                intRowsAffected = cmdUpdate.ExecuteNonQuery()


                If intRowsAffected = 1 Then
                    MessageBox.Show("Update successful")
                Else
                    MessageBox.Show("Update failed")
                End If
            Else
                MessageBox.Show("Validation failed. Update aborted.")
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            ' Ensure the database connection is closed
            CloseDatabaseConnection()
        End Try


    End Sub



    Private Sub Get_Validate_Input(ByRef strfirstname As String, strlastname As String, ByRef straddress As String, ByRef strCity As String, ByRef strZip As String, ByRef strEmail As String, ByRef strPhoneNumber As String, ByRef blnvalidated As Boolean)
        Call Get_Validate_FirstName_and_LastName(strfirstname, strlastname, blnvalidated)
        If blnvalidated = True Then
            Call Get_Validate_Address(straddress, blnvalidated)
        End If
        If blnvalidated = True Then
            Call Get_Validate_Zip(strZip, blnvalidated)
        End If
        If blnvalidated = True Then
            Call Get_Validate_City(strCity, blnvalidated)
        End If

        If blnvalidated = True Then
            Call Get_Validate_PhoneNumber(strPhoneNumber, blnvalidated)
        End If
        If blnvalidated = True Then
            Call Get_Validate_Email(strEmail, blnvalidated)
        End If



    End Sub
    'Validating Names
    Private Sub Get_Validate_FirstName_and_LastName(ByRef strfirstname As String, ByRef strlastname As String, blnvalidated As Boolean)
        If txtFirstName.Text = String.Empty Then
            MessageBox.Show("First Name is Required")
            txtFirstName.Focus()
            blnvalidated = False
            Exit Sub
        End If

        If txtLastName.Text = "" Then
            MessageBox.Show("Last Name is Required")
            txtLastName.Focus()
            blnvalidated = False
            Exit Sub
        End If
    End Sub
    'Validating Hours Worked
    Private Sub Get_Validate_Address(ByRef straddress As String, ByRef blnvalidated As Boolean)
        If txtAddress.Text = String.Empty Then
            MessageBox.Show("Address is Required")
            txtAddress.Focus()
            blnvalidated = False
            Exit Sub
        End If
    End Sub


    Private Sub Get_Validate_City(ByRef strCity As String, ByRef blnvalidated As Boolean)
        If txtCity.Text = String.Empty Then
            MessageBox.Show("Cities is required")
            txtCity.Focus()
            blnvalidated = False
            Exit Sub
        End If
    End Sub
    Private Sub Get_Validate_Zip(ByRef strZip As String, ByRef blnvalidated As Boolean)
        If txtZip.Text = String.Empty Then
            MessageBox.Show("State is Required")
            cboStates.Focus()
            blnvalidated = False
            Exit Sub
        End If
    End Sub
    Private Sub Get_Validate_PhoneNumber(ByRef strPhoneNumber As String, ByRef blnvalidated As Boolean)
        If txtPhoneNumber.Text = String.Empty Then
            MessageBox.Show("Phone Number is Required")
            txtPhoneNumber.Focus()
            blnvalidated = False
            Exit Sub
        End If
    End Sub
    Private Sub Get_Validate_Email(ByRef strEmail As String, ByRef blnvalidated As Boolean)
        If txtEmail.Text = String.Empty Then
            MessageBox.Show("Email is Required")
            txtEmail.Focus()
            blnvalidated = False
            Exit Sub
        End If
    End Sub

    Private Sub frmUpdatePassenger_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim strselect As String = ""
        Dim objParam As OleDb.OleDbParameter
        Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
        Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
        Dim dt As DataTable = New DataTable ' this is the table we will load from our reader
        Dim dtc As DataTable = New DataTable ' this is the table we will load from our reader for City
        Dim dts As DataTable = New DataTable ' this is the table we will load from our reader for State
        Dim dtr As DataTable = New DataTable ' this is the table we will load from our reader for Race

        Try
            ' loop through the textboxes and clear them in case they have data in them after a delete
            For Each cntrl As Control In Controls
                If TypeOf cntrl Is TextBox Then
                    cntrl.Text = String.Empty
                End If
            Next

            ' open the DB this is in module
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                "The application will now close.",
                                Me.Text + " Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If


            ' Build the select statement
            cmdSelect = New OleDb.OleDbCommand("uspGetStates", m_conAdministrator)
            cmdSelect.CommandType = CommandType.StoredProcedure
            drSourceTable = cmdSelect.ExecuteReader
            dts.Load(drSourceTable)


            'load the State result set into the combobox.  For VB, we do this by binding the data to the combobox

            cboStates.ValueMember = "intStateID"
            cboStates.DisplayMember = "strState"
            cboStates.DataSource = dts


            ' Build the select statement
            cmdSelect = New OleDb.OleDbCommand("uspGetPassengerByID", m_conAdministrator)
            cmdSelect.CommandType = CommandType.StoredProcedure

            objParam = cmdSelect.Parameters.Add("@PassengerID", OleDb.OleDbType.Integer)
            objParam.Direction = ParameterDirection.Input
            objParam.Value = strPassenger

            ' load table from data reader
            dt.Load(drSourceTable)

            strselect = "SELECT strFirstName, strLastName, strAddress, strCity, intStateID, strZip, strPhoneNumber, strEmail, strPassengerUsername, strPassengerPassword, strPassengerDateofBirth " &
                        " FROM TPassengers Where intPassengerID = " & strPassenger

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strselect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            drSourceTable.Read()


            ' populate the text boxes with the data
            txtFirstName.Text = drSourceTable("strFirstName")
            txtLastName.Text = drSourceTable("strLastName")
            txtAddress.Text = drSourceTable("strAddress")
            txtCity.Text = drSourceTable("strCity")
            cboStates.SelectedValue = drSourceTable("intStateID")
            txtZip.Text = drSourceTable("strZip")
            txtPhoneNumber.Text = drSourceTable("strPhoneNumber")
            txtEmail.Text = drSourceTable("strEmail")
            txtPassengerUserName.Text = drSourceTable("strPassengerUsername")
            txtPassengerPassword.Text = drSourceTable("strPassengerPassword")
            DTPPassengerDateofBirth.Value = drSourceTable("strPassengerDateofBirth")

            ' Clean up
            drSourceTable.Close()


            ' close the database connection
            CloseDatabaseConnection()

        Catch excError As Exception

            ' Log and display error message
            MessageBox.Show(excError.Message)
        End Try
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
End Class