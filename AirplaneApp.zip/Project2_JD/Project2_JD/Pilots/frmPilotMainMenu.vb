﻿Public Class frmPilotMainMenu
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim frrmUpdatePilot As New frmUpdatePilot
        ' Pass the strCustomer value to frmUpdateCustomer

        frmUpdatePilot.ShowDialog()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnPastFlights.Click
        Dim frmPilotPastFlights As New frmPilotPastFlighs
        frmPilotPastFlights.ShowDialog()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles btnFutureFlights.Click
        Dim frmPilotFutureFlight As New frmPilotFutureFlight
        frmPilotFutureFlight.ShowDialog()
    End Sub

    Private Sub frmPilotMainMenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class