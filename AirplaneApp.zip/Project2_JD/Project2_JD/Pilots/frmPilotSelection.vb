﻿Public Class frmPilotSelection
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

    Private Sub frmPilotrSelection_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSelect As String = ""
        Dim cmdSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim dt As DataTable = New DataTable

        Try
            If OpenDatabaseConnectionSQLServer() = False Then
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                            "The application will now close.",
                            Me.Text + " Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Close()
            End If

            strSelect = "SELECT intPilotID, strFirstName + ' ' + strLastName as PilotName FROM TPilots"
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            dt.Load(drSourceTable)


            cboPilotName.ValueMember = "intPilotID"
            cboPilotName.DisplayMember = "PilotName"
            cboPilotName.DataSource = dt

            If cboPilotName.Items.Count > 0 Then cboPilotName.SelectedIndex = 0

            drSourceTable.Close()
            CloseDatabaseConnection()

        Catch excError As Exception
            MessageBox.Show(excError.Message)
        End Try
    End Sub


    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim frmPilotMainMenu As New frmPilotMainMenu
        strName = cboPilotName.DisplayMember
        strPilot = cboPilotName.SelectedValue
        frmPilotMainMenu.ShowDialog()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub cboPilotName_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboPilotName.SelectedIndexChanged

    End Sub
End Class