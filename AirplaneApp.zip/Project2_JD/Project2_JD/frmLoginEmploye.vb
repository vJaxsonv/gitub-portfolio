﻿Public Class frmLoginEmploye
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

    Private Sub LoginEmploye_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim strUsername As String
        Dim strPassword As String
        Dim introleID As String

        Dim cmdSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader

        Try
            ' Open the database connection
            If OpenDatabaseConnectionSQLServer() = False Then
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                        "The application will now close.",
                        Me.Text + " Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Close()
            End If


            strUsername = txtEmployeeID.Text
            strPassword = txtEmployeePassword.Text


            cmdSelect = New OleDb.OleDbCommand("uspCheckEmployeeLogin", m_conAdministrator)
            cmdSelect.CommandType = CommandType.StoredProcedure


            cmdSelect.Parameters.AddWithValue("@Username", strUsername)
            cmdSelect.Parameters.AddWithValue("@Password", strPassword)


            drSourceTable = cmdSelect.ExecuteReader()

            If drSourceTable.HasRows Then
                drSourceTable.Read()

                introleID = (drSourceTable("intRoleID"))

                ' using a case to see if its a pilot, admin, or attendant
                Select Case introleID
                    Case 1
                        strEmployee = drSourceTable("intEmployeeID").ToString()
                        strPilot = drSourceTable("intPilotID").ToString()
                        Dim frmPilotMainMenu As New frmPilotMainMenu
                        frmPilotMainMenu.ShowDialog()

                    Case 2
                        strAdmin = drSourceTable("intEmployeeID").ToString()
                        Dim frmAdminMainMenu As New frmAdminSelection
                        frmAdminMainMenu.ShowDialog()

                    Case 3
                        strEmployee = drSourceTable("intEmployeeID").ToString()
                        strAttendant = drSourceTable("intAttendantID").ToString()
                        Dim frmAttendantMainMenu As New frmAttendantMainMenu
                        frmAttendantMainMenu.ShowDialog()
                End Select
            Else
                MessageBox.Show("Invalid username or password. Please try again.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
            drSourceTable.Close()



            CloseDatabaseConnection()

        Catch excError As Exception
            ' Display any errors that occur
            MessageBox.Show(excError.Message)
        End Try
    End Sub
End Class