﻿Public Class frmPassengerLogin
    Private Sub btnPassengerLogin_Click(sender As Object, e As EventArgs) Handles btnPassengerLogin.Click


        Dim strUsername As String
        Dim strPassword As String

        Dim cmdSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader

        Try
            ' Open the database connection
            If OpenDatabaseConnectionSQLServer() = False Then
                ' Connection failed, display an error message and close the application
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                        "The application will now close.",
                        Me.Text + " Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Close()
            End If


            strUsername = txtPassengerID.Text
            strPassword = txtPassengerPassword.Text


            cmdSelect = New OleDb.OleDbCommand("uspCheckPassengerLogin", m_conAdministrator)
            cmdSelect.CommandType = CommandType.StoredProcedure
            cmdSelect.Parameters.AddWithValue("@Username", strUsername)
            cmdSelect.Parameters.AddWithValue("@Password", strPassword)


            drSourceTable = cmdSelect.ExecuteReader()


            If drSourceTable.HasRows Then
                drSourceTable.Read()
                strPassenger = drSourceTable("intPassengerID").ToString()
                Dim frmPassengerMainMenu As New frmPassengerMainMenu
                frmPassengerMainMenu.ShowDialog()
            Else
                MessageBox.Show("Invalid username or password. Please try again.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If


            drSourceTable.Close()
            CloseDatabaseConnection()

        Catch excError As Exception
            MessageBox.Show(excError.Message)
        End Try
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

    Private Sub btnSignUp_Click(sender As Object, e As EventArgs) Handles btnSignUp.Click
        Dim frmAddPassenger As New frmAddPassenger
        frmAddPassenger.ShowDialog()
    End Sub

    Private Sub frmPassengerLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class