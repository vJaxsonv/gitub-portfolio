﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTypeofUser
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnEmployee = New System.Windows.Forms.Button()
        Me.btnPassenger = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnEmployee
        '
        Me.btnEmployee.Location = New System.Drawing.Point(12, 52)
        Me.btnEmployee.Name = "btnEmployee"
        Me.btnEmployee.Size = New System.Drawing.Size(123, 43)
        Me.btnEmployee.TabIndex = 4
        Me.btnEmployee.Text = "Employee"
        Me.btnEmployee.UseVisualStyleBackColor = True
        '
        'btnPassenger
        '
        Me.btnPassenger.Location = New System.Drawing.Point(194, 52)
        Me.btnPassenger.Name = "btnPassenger"
        Me.btnPassenger.Size = New System.Drawing.Size(123, 43)
        Me.btnPassenger.TabIndex = 5
        Me.btnPassenger.Text = "Passenger"
        Me.btnPassenger.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(99, 115)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(123, 43)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmTypeofUser
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(331, 177)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnPassenger)
        Me.Controls.Add(Me.btnEmployee)
        Me.Name = "frmTypeofUser"
        Me.Text = "Type of User"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnEmployee As Button
    Friend WithEvents btnPassenger As Button
    Friend WithEvents btnExit As Button
End Class
