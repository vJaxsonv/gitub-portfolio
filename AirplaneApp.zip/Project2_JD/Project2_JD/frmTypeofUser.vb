﻿Public Class frmTypeofUser



    Private Sub btnExit_Click(sender As Object, e As EventArgs)
        Close()
    End Sub


    Private Sub btnEmployee_Click(sender As Object, e As EventArgs) Handles btnEmployee.Click
        Dim frmEmployeeLogin As New frmLoginEmploye
        frmLoginEmploye.ShowDialog()
    End Sub

    Private Sub btnPassenger_Click(sender As Object, e As EventArgs) Handles btnPassenger.Click
        Dim frmPassengerLogin As New frmPassengerLogin
        frmPassengerLogin.ShowDialog()
    End Sub

    Private Sub btnExit_Click_1(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class
