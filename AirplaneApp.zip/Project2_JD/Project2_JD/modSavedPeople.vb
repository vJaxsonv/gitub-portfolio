﻿Module modSavedPeople
    Public strPassenger As String
    Public strPilot As String
    Public strAttendant As String
    Public strAdminPilot As String
    Public strName As String
    Public strAdmin As String
    Public strEmployee As String
    Public intEmployeeID As String
End Module
