// --------------------------------------------------------------------------------
// Name: Jaxson DeHaven
// Class: SET-151-400 
// Abstract: Final Project
// --------------------------------------------------------------------------------

// --------------------------------------------------------------------------------
// Includes
// --------------------------------------------------------------------------------
#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

// --------------------------------------------------------------------------------
// Constants
// --------------------------------------------------------------------------------
const int intARRAY_SIZE = 100;

//---------------------------------------------------------------------------------
// User Defined Types (UDTs)
//---------------------------------------------------------------------------------
typedef struct
{
    char strState[50];
    char strCounty[50];
    char strDate[50];
    char strRace[50];
    int intNumberinHousehold;
    double dblYearlyIncome;
} udtAddressType;

// --------------------------------------------------------------------------------
// Prototypes
// --------------------------------------------------------------------------------
void InitializeAddressList(udtAddressType audtAddressList[]);
void InitializeAddress(udtAddressType* pudtAddress);
void StringCopy(char strDestination[], char strSource[]);

void PopulateAddressList(udtAddressType audtAddressList[], int* pintRecordCount);
int OpenInputFile(char strFileName[], FILE** ppfilInput);
void AddAddressToArray(char strAddress[], udtAddressType audtAddressList[], int* pintRecordCount);
void GetNextField(char strNextField[], char strSource[], char chrComma);
int StringLength(char strSource[]);
void AppendString(char strDestination[], char strSource[]);
void Trim(char strSource[]);
int IsWhiteSpace(char chrLetterToCheck);

void DisplayMenu(udtAddressType audtAddressList[], int intRecordCount);
void AddCensusRecord();
int StringsAreEqual(char* strAddressString, char* strString);
void AverageIncomeByCounty(udtAddressType audtAddressList[], int intRecordCount);
void TotalHouseholdsSurveyed(int intRecordCount);
void AverageHouseHoldIncome(udtAddressType audtAddressList[], int intRecordCount);
void TotalHouseholdsPerCounty(udtAddressType audtAddressList[], int intRecordCount);
void TotalHouseholdsPerRace(udtAddressType* pudtAddress, int intRecordCount);
void PercentageBelowByCountyAndState(udtAddressType* pudtAddress, int intRecordCount);
void PercentageBelowPoverty(udtAddressType* pudtAddress, int intRecordCount);
void PercentageBelowPovertyPerRace(udtAddressType* pudtAddress, int intRecordCount);
void AverageHouseholdIncomeRace(udtAddressType audtAddressList[], int intRecordCount);

// --------------------------------------------------------------------------------
// Name: main
// Abstract: This is where the program starts.
// --------------------------------------------------------------------------------
int main()
{
    int intChoice = 0;
    int intRecordCount = 0; // Initialize record count
    udtAddressType audtAddressList[150];

    do {
        // Display menu
        printf("\nCensus Bureau Application\n");
        printf("1. Write Mode\n");
        printf("2. Display Mode\n");
        printf("3. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &intChoice);

        if (intChoice == 1)
        {
            AddCensusRecord();
        }
        else if (intChoice == 2)
        {
            InitializeAddressList(audtAddressList);
            PopulateAddressList(audtAddressList, &intRecordCount);
            DisplayMenu(audtAddressList, intRecordCount);
        }
        else if (intChoice == 3)
        {
            printf("Exiting the application. Goodbye!\n");
        }
        else
        {
            printf("Invalid choice. Please try again.\n");
        }
    } while (intChoice != 3); // Loop until the user chooses to exit

    return 0;
}


// --------------------------------------------------------------------------------
// Name: Initialize Address
// Abstract: Copy Source to the destination
// --------------------------------------------------------------------------------
void InitializeAddressList(udtAddressType audtAddressList[])
{
    int intIndex = 0;

    for (intIndex = 0; intIndex < intARRAY_SIZE; intIndex += 1)
    {
        InitializeAddress(&audtAddressList[intIndex]);
    }
}
// --------------------------------------------------------------------------------
// Name: Initialize Address
// Abstract: Copy Source to the destination
// --------------------------------------------------------------------------------
void InitializeAddress(udtAddressType* pudtAddress)
{
    
    StringCopy(pudtAddress->strDate, "");
    StringCopy(pudtAddress->strState, "");
    StringCopy(pudtAddress->strCounty, "");
    StringCopy(pudtAddress->strRace, "");
    pudtAddress->intNumberinHousehold = 0;
    pudtAddress->dblYearlyIncome = 0;
}

// --------------------------------------------------------------------------------
// Name: PopulateAddressList
// Abstract: Reads data from a file and populates the array
// --------------------------------------------------------------------------------
void PopulateAddressList(udtAddressType audtAddressList[], int* pintRecordCount)
{
    // Declare a file pointer
    FILE* pfilInput = 0;
    int intResultFlag = 0;
    char strBuffer[250] = "";
    char chrLetter = 0;
    int intIndex = 0;

    // Try to open the file for reading (notice you have to double up the backslashes)
    intResultFlag = OpenInputFile("c:\\CensusData.csv", &pfilInput);


    intResultFlag = OpenInputFile("c:\\CensusData.csv", &pfilInput);

    if (OpenInputFile("c:\\CensusData.csv", &pfilInput)) 
    {
        while (fgets(strBuffer, sizeof(strBuffer), pfilInput) != NULL) 
        {
            if (strlen(strBuffer) > 1) 
            { 
                AddAddressToArray(strBuffer, audtAddressList, pintRecordCount);
            }
        }
        fclose(pfilInput);
    }
    
}


// --------------------------------------------------------------------------------
// Name: OpenInputFile
// Abstract: Open the file for reading.
// --------------------------------------------------------------------------------
int OpenInputFile(char strFileName[], FILE** ppfilInput)
{

    int intResultFlag = 0;

    // Open the file for reading
    *ppfilInput = fopen(strFileName, "rb");

    // Success?
    if (*ppfilInput != 0)
    {
        // Yes
        intResultFlag = 1;
    }
    else
    {
        // No
        printf("Error opening %s for reading!!!\n", strFileName);
    }

    return intResultFlag;
}

// --------------------------------------------------------------------------------
// Name: AddAddressToArray
// Abstract: Add address to the array by using th get next field
// and using string copy
// --------------------------------------------------------------------------------
void AddAddressToArray(char strAddress[], udtAddressType audtAddressList[], int* pintRecordCount) {
    char strNextField[50] = "";

    AppendString(strAddress, ",");

    udtAddressType* pudtAddress = &audtAddressList[*pintRecordCount];

    // Date
    GetNextField(strNextField, strAddress, ',');
    Trim(strNextField);
    StringCopy(pudtAddress->strDate, strNextField);

    // State
    GetNextField(strNextField, strAddress, ',');
    Trim(strNextField);
    StringCopy(pudtAddress->strState, strNextField);

 
    GetNextField(strNextField, strAddress, ',');
    Trim(strNextField);
    StringCopy(pudtAddress->strCounty, strNextField);

   
    GetNextField(strNextField, strAddress, ',');
    Trim(strNextField);
    StringCopy(pudtAddress->strRace, strNextField);

 
    GetNextField(strNextField, strAddress, ',');
    Trim(strNextField);
    pudtAddress->intNumberinHousehold = atoi(strNextField);

    GetNextField(strNextField, strAddress, ',');
    Trim(strNextField);
    pudtAddress->dblYearlyIncome = atof(strNextField);


    (*pintRecordCount)+=1;
}



// --------------------------------------------------------------------------------
// Name: String Copy
// Abstract: Copy Source to the destination
// --------------------------------------------------------------------------------
void StringCopy(char strDestination[], char strSource[])
{
    int intIndex = 0;

    //copy each character
    while (strSource[intIndex] != 0)
    {
        strDestination[intIndex] = strSource[intIndex];
        intIndex += 1;
    }

    strDestination[intIndex] = 0;
}



// --------------------------------------------------------------------------------
// Name: GetNextField
// Abstract: Add address to the array
// --------------------------------------------------------------------------------
void GetNextField(char strNextField[], char strSource[], char chrComma)
{
    
        int intSourceIndex = 0;
        int intFieldIndex = 0;

        // Loop through the source string to find the next field
        while (strSource[intSourceIndex] != 0 && strSource[intSourceIndex] != chrComma)
        {
            strNextField[intFieldIndex] = strSource[intSourceIndex];
            intFieldIndex += 1;
            intSourceIndex += 1;
        }

        // Properly null-terminate the extracted field
        strNextField[intFieldIndex] = 0;

        // Skip the delimiter (if present)
        if (strSource[intSourceIndex] == chrComma)
        {
            intSourceIndex += 1;
        }

        

        // Update the source string with the remaining part
        StringCopy(strSource, &strSource[intSourceIndex]);   
  
}

// --------------------------------------------------------------------------------
// Name: StringLength
// Abstract: Return the string length
// --------------------------------------------------------------------------------
int StringLength(char strSource[])
{
    int intIndex = 0;
    int intLength = 0;

    // Pre-test because string may be empty
    while (strSource[intIndex] != 0)
    {
        intIndex += 1;
    }

    intLength = intIndex;

    return intLength;
}



// --------------------------------------------------------------------------------
// Name: Trim
// Abstract: Remove leading and trailing whitespace (space, tab or newline)
// --------------------------------------------------------------------------------
void Trim(char strSource[])
{

    int intIndex = 0;
    int intFirstNonWhitespaceIndex = -1;
    int intLastNonWhitespaceIndex = 0;
    int intSourceIndex = 0;
    int intDestinationIndex = 0;

    // Default first non-whitespace character index to end of string in case string is all whitespace
    // Bug fix.  Not in video.
    intFirstNonWhitespaceIndex = StringLength(strSource);

    // Find first non-whitespace character
    while (strSource[intIndex] != 0)
    {
        // Non-whitespace character?
        if (IsWhiteSpace(strSource[intIndex]) == 0)
        {
            // Yes, save the index
            intFirstNonWhitespaceIndex = intIndex;

            // Stop searching!
            break;
        }

        // Next character
        intIndex += 1;
    }

    // Find the last non-whitespace character
    while (strSource[intIndex] != 0)
    {
        // Non-whitespace character?
        if (IsWhiteSpace(strSource[intIndex]) == 0)
        {
            // Yes, save the index
            intLastNonWhitespaceIndex = intIndex;
        }

        // Next character
        intIndex += 1;
    }

    // Any non-whitepsace characters?
    if (intFirstNonWhitespaceIndex >= 0)
    {
        // Yes, copy everything in between
        for (intSourceIndex = intFirstNonWhitespaceIndex; intSourceIndex <= intLastNonWhitespaceIndex; intSourceIndex += 1)
        {
            // Copy next character
            strSource[intDestinationIndex] = strSource[intSourceIndex];

            intDestinationIndex += 1;
        }
    }

    // Terminate 
    strSource[intDestinationIndex] = 0;
}



// --------------------------------------------------------------------------------
// Name: IsWhiteSpace
// Abstract: Return true if letter is a space, tab, newline or carriage return
// --------------------------------------------------------------------------------
int IsWhiteSpace(char chrLetterToCheck)
{
    int blnIsWhiteSpace = 0;

    // Space
    if (chrLetterToCheck == ' ') blnIsWhiteSpace = 1;

    // Tab
    if (chrLetterToCheck == '\t') blnIsWhiteSpace = 1;

    // Carriarge return
    if (chrLetterToCheck == '\r') blnIsWhiteSpace = 1;

    // Line feed
    if (chrLetterToCheck == '\n') blnIsWhiteSpace = 1;

    return blnIsWhiteSpace;
}



// --------------------------------------------------------------------------------
// Name: AppendString
// Abstract: Append the source to the end of the destinatoin.
// --------------------------------------------------------------------------------
void AppendString(char strDestination[], char strSource[])
{
    int intDestinationLength = 0;
    int intIndex = 0;

    // Find the length
    intDestinationLength = StringLength(strDestination);

    // Copy each character
    while (strSource[intIndex] != 0)
    {
        strDestination[intDestinationLength + intIndex] = strSource[intIndex];

        intIndex += 1;
    }

    // Terminate
    strDestination[intDestinationLength + intIndex] = 0;

}



// --------------------------------------------------------------------------------
// Name: AddCensusRecord
// Abstract: Gathers the data for the census and writes it to a file
// --------------------------------------------------------------------------------
void AddCensusRecord()
{
    udtAddressType udtRecord;
    int intraceChoice = 0;
    int intstateChoice = 0;
    int countyChoice = 0;

    FILE* fp = fopen("c:\\CensusData.csv", "a+");
    if (!fp)
    {
        printf("Can't open file\n");
        return;
    }

    printf("\nEnter Census Data:\n");

    printf("Enter date (MM/DD/YYYY): ");
    scanf("%10s", udtRecord.strDate);

    printf("Enter state:\n 1 = Ohio\n 2 = Kentucky\n");
    scanf("%d", &intstateChoice);


    if (intstateChoice == 1)
    {
        StringCopy(udtRecord.strState, "Ohio");

        printf("Enter county:\n 1 = Hamilton\n 2 = Butler\n");
        scanf("%d", &countyChoice);

        if (countyChoice == 1)
        {
            StringCopy(udtRecord.strCounty, "Hamilton");
        }
        else if (countyChoice == 2)
        {
            StringCopy(udtRecord.strCounty, "Butler");
        }
        else
        {
            printf("Invalid county choice for Ohio.\n");
            return;
        }
    }
    else if (intstateChoice == 2)
    {
        StringCopy(udtRecord.strState, "Kentucky");

        printf("Enter county:\n 3 = Boone\n 4 = Kenton\n");
        scanf("%d", &countyChoice);

        if (countyChoice == 3)
        {
            StringCopy(udtRecord.strCounty, "Boone");
        }
        else if (countyChoice == 4)
        {
            StringCopy(udtRecord.strCounty, "Kenton");
        }
        else
        {
            printf("Invalid county choice for Kentucky.\n");
            return;
        }
    }
    else
    {
        printf("Invalid state choice.\n");
        return;
    }


    printf("Enter race: 1 = Caucasian\n 2 = African American\n 3 = Hispanic\n 4 = Asian\n 5 = Other\n");
    scanf("%d", &intraceChoice);


    if (intraceChoice == 1) StringCopy(udtRecord.strRace, "Caucasian");
    else if (intraceChoice == 2) StringCopy(udtRecord.strRace, "African American");
    else if (intraceChoice == 3) StringCopy(udtRecord.strRace, "Hispanic");
    else if (intraceChoice == 4) StringCopy(udtRecord.strRace, "Asian");
    else if (intraceChoice == 5) StringCopy(udtRecord.strRace, "Other");
    else 
    {
        printf("Invalid race choice.\n");
        return;
    }

    printf("Enter household size (> 0): ");
    scanf("%d", &udtRecord.intNumberinHousehold);
    if (udtRecord.intNumberinHousehold <= 0) {
        printf("Invalid household size.\n");
        return;
    }

    printf("Enter yearly income (> 0): ");
    scanf("%lf", &udtRecord.dblYearlyIncome);
    if (udtRecord.dblYearlyIncome <= 0) {
        printf("Invalid income.\n");
        return;
    }

    fprintf(fp, "%s,%s,%s,%s,%d,%.2f\n",
        udtRecord.strDate,
        udtRecord.strState,
        udtRecord.strCounty,
        udtRecord.strRace,
        udtRecord.intNumberinHousehold,
        udtRecord.dblYearlyIncome);

    printf("Record added successfully.\n");
    fclose(fp);
}



// --------------------------------------------------------------------------------
// Name: DisplayMenu
// Abstract: Displays menu and calls functions based on user input
// --------------------------------------------------------------------------------
void DisplayMenu(udtAddressType audtAddressList[], int intRecordCount)
{
    char chrChoice;

    {
     
        do {
            printf("\nDisplay Mode Options:\n");
            printf("A: Total Households Surveyed\n");
            printf("B: Total Households Surveyed per County\n");
            printf("C: Total Households Surveyed per Race\n");
            printf("D: Average Households Income\n");
            printf("E: Average Income by County and State\n");
            printf("F: Average Income per Race\n");
            printf("G: Percentage Below Poverty\n");
            printf("H: Percentage Below Poverty by County and State\n");
            printf("I: Percentage Below Poverty per Race\n");
            printf("Q: Quit\n");
            printf("Enter your choice: ");
            scanf(" %c", &chrChoice);

            switch (chrChoice)
            {
            case 'A':
                TotalHouseholdsSurveyed(intRecordCount);
                break;
            case 'B':
                TotalHouseholdsPerCounty(audtAddressList, intRecordCount);
                break;
            case 'C':
                TotalHouseholdsPerRace(audtAddressList, intRecordCount);
                break;
            case 'D':
                AverageHouseHoldIncome(audtAddressList, intRecordCount);
                break;
            case 'E':
                AverageIncomeByCounty(audtAddressList, intRecordCount);
                break;
            case 'F':
                AverageHouseholdIncomeRace(audtAddressList, intRecordCount);
                break;
            case 'G':
                PercentageBelowPoverty(audtAddressList, intRecordCount);
                break;
            case 'H':
                PercentageBelowByCountyAndState(audtAddressList, intRecordCount);
                break;
            case 'I':
                PercentageBelowPovertyPerRace(audtAddressList, intRecordCount);
                break;
        
            case 'Q':
                printf("Exiting Display Mode.\n");
                break;
            default:
                printf("Invalid choice. Try again.\n");
            }
        } while (chrChoice != 'Q');
    }
}



// --------------------------------------------------------------------------------
// Name: AverageHouseholdIncomeRace
// Abstract: loops through the records and checks if the strings are equal
// then adds the income from the race to the variable then calculates the average
// --------------------------------------------------------------------------------
void AverageHouseholdIncomeRace(udtAddressType audtAddressList[], int intRecordCount)
{
    double dblTotalIncomeCaucasian = 0;
    double dblTotalIncomeAfricanAmerican = 0;
    double dblTotalIncomeHispanic = 0;
    double dblTotalIncomeAsian = 0;
    double dblTotalIncomeOther = 0;


    double dblAverageCaucasian = 0;
    double dblAverageAfricanAmerican = 0;
    double dblAverageAsian = 0;
    double dblAverageHispanic = 0;
    double dblAverageOther = 0;



    int intCountCaucasian = 0;
    int intCountAfricanAmerican = 0;

    int intCountHispanic = 0;
    int intCountAsian = 0;
    int intCountOther = 0;
    int intIndex = 0;

    // Loop through records to calculate total income and counts by race
    for (intIndex = 0; intIndex < intRecordCount; intIndex += 1)
    {
        if (StringsAreEqual(audtAddressList[intIndex].strRace, "Caucasian"))
        {
            dblTotalIncomeCaucasian += audtAddressList[intIndex].dblYearlyIncome;
            intCountCaucasian += 1;
        }
        else if (StringsAreEqual(audtAddressList[intIndex].strRace, "African American"))
        {
            dblTotalIncomeAfricanAmerican += audtAddressList[intIndex].dblYearlyIncome;
            intCountAfricanAmerican += 1;
        }
        else if (StringsAreEqual(audtAddressList[intIndex].strRace, "Hispanic"))
        {
            dblTotalIncomeHispanic += audtAddressList[intIndex].dblYearlyIncome;
            intCountHispanic += 1;
        }
        else if (StringsAreEqual(audtAddressList[intIndex].strRace, "Asian"))
        {
            dblTotalIncomeAsian += audtAddressList[intIndex].dblYearlyIncome;
            intCountAsian += 1;
        }
        else  
        {
            dblTotalIncomeOther += audtAddressList[intIndex].dblYearlyIncome;
            intCountOther += 1;
        }
    }
    dblAverageCaucasian = (intCountCaucasian != 0) ? dblTotalIncomeCaucasian / intCountCaucasian : 0.0;
    dblAverageAfricanAmerican = (intCountAfricanAmerican != 0) ? dblTotalIncomeAfricanAmerican / intCountAfricanAmerican : 0.0;
    dblAverageAsian = (intCountAsian != 0) ? dblTotalIncomeAsian / intCountAsian : 0.0;
    dblAverageHispanic = (intCountHispanic != 0) ? dblTotalIncomeHispanic / intCountHispanic : 0.0;
    dblAverageOther = (intCountOther != 0) ? dblTotalIncomeOther / intCountOther : 0.0;

    printf("\nAverage Income per Race:\n");
    // Display the average income for each race
    if (dblAverageCaucasian > 0)
    {
        printf("Caucasian: $%.2f\n", dblAverageCaucasian);
    }

    if (dblAverageAfricanAmerican > 0)
    {
        printf("African American: $%.2f\n", dblAverageAfricanAmerican);
  
    }
    if (dblAverageAsian > 0)
    {
        printf("Asian: $%.2f\n", dblAverageAsian);

    }
    if (dblAverageHispanic > 0)
    {
        printf("Hispanic: $%.2f\n", dblAverageHispanic);
    }
    if (dblAverageOther > 0)
    {
        printf("Other: $%.2f\n", dblAverageOther);
    }
    
}



// --------------------------------------------------------------------------------
// Name: AverageHouseholdIncome
// Abstract: calculates the average by using a for loop 
// --------------------------------------------------------------------------------
void AverageHouseHoldIncome(udtAddressType audtAddressList[], int intRecordCount)
{

    float sngAverage = 0;
    float sngTotal = 0;

    int intIndex = 0;
  

    for (intIndex = 0; intIndex < intRecordCount; intIndex += 1)
    {

        sngTotal += audtAddressList[intIndex].dblYearlyIncome;

    }

    sngAverage = sngTotal / intIndex;
    printf("\nAverage Household Income: %.2f", sngAverage);

   
}



// --------------------------------------------------------------------------------
// Name: AverageIncomeByCounty
// Abstract: uses a for loop to calculate the average income by county
// and then prints the data
// --------------------------------------------------------------------------------
void AverageIncomeByCounty(udtAddressType audtAddressList[], int intRecordCount)
{
  
	int intOhioCount = 0;
	int	intOhioHamiltonCount = 0;
	int	intOhioButlerCount = 0;
	float sngOhioSum = 0;
	float sngOhioHamiltonSum = 0;
	float sngOhioButlerSum = 0;
	int intIndex = 0;
	int intKentuckyCount = 0;
	int intKyBooneCount = 0;
	int intKyKentonCount = 0;
	float sngKentuckySum = 0;
	float sngKyBooneSum = 0;
	float sngKyKentonSum = 0;

	for ( intIndex = 0; intIndex < intRecordCount; intIndex +=1) 
	{
      
            if (StringsAreEqual(audtAddressList[intIndex].strCounty, "Hamilton"))
			{
				sngOhioHamiltonSum += audtAddressList[intIndex].dblYearlyIncome;
                sngOhioSum += audtAddressList[intIndex].dblYearlyIncome;
				intOhioHamiltonCount+=1;
                intOhioCount += 1;

			}
			else  if (StringsAreEqual(audtAddressList[intIndex].strCounty, "Butler"))
			{
				sngOhioButlerSum += audtAddressList[intIndex].dblYearlyIncome;
                sngOhioSum += audtAddressList[intIndex].dblYearlyIncome;
				intOhioButlerCount+=1;
                intOhioCount += 1;
			}
            else  if (StringsAreEqual(audtAddressList[intIndex].strCounty, "Boone"))
			{
				sngKyBooneSum += audtAddressList[intIndex].dblYearlyIncome;
				intKyBooneCount+=1;
                intKentuckyCount += 1;
                sngKentuckySum += audtAddressList[intIndex].dblYearlyIncome;
			}
			else  if (StringsAreEqual(audtAddressList[intIndex].strCounty, "Kenton"))
			{
				sngKyKentonSum += audtAddressList[intIndex].dblYearlyIncome;
				intKyKentonCount+=1;
                intKentuckyCount += 1;
                sngKentuckySum += audtAddressList[intIndex].dblYearlyIncome;
			}
		
	}

	printf("\nAverage Household Income Per County and State:\n");

    if (intOhioCount > 0)
    {
        printf("Ohio: $%.2f\n", sngOhioSum);
        if (intOhioHamiltonCount > 0)
        {
            printf("   Hamilton: $%.2f\n", sngOhioHamiltonSum / intOhioHamiltonCount);

        }

        else
        {
            printf("   Hamilton: $0.00\n");
        }


        if (intOhioButlerCount >= 0)
        {
            printf("   Butler: $%.2f\n", sngOhioButlerSum / intOhioButlerCount);
        }
        else
        {
            printf("   Butler: $0.00\n");
        }

    }

	if (intKentuckyCount > 0) 
	{
		printf("Kentucky: $%.2f\n", sngKentuckySum);

		if (intKyBooneCount > 0)
		{
			printf("   Boone: $%.2f\n", sngKyBooneSum / intKyBooneCount);
		}
        else
        {
            printf("   Boone: $0.00\n");
        }
		if (intKyKentonCount > 0)
		{
			printf("   Kenton: $%.2f\n", sngKyKentonSum / intKyKentonCount);
		}
        else
        {
            printf("   Kenton: $0.00\n");
        }
	}
}



// --------------------------------------------------------------------------------
// Name: TotalHouseholdsSurveyed
// Abstract: prints total households
// --------------------------------------------------------------------------------
void TotalHouseholdsSurveyed(int intRecordCount)
{
	printf("\nTotal Households Surveyed: %d\n",intRecordCount);
}



// --------------------------------------------------------------------------------
// Name: TotalHouseholdsPerCounty
// Abstract: calculates the total households by using a for loop and checking
// if the record is in their respected state and county and adds to their totals
// --------------------------------------------------------------------------------
void TotalHouseholdsPerCounty(udtAddressType audtAddressList[], int intRecordCount)
{
    int intohioHamilton = 0;
    int intohioButler = 0;
    int intkyBoone = 0;
    int intkyKenton = 0;
    int intIndex = 0;
    int intOhioCount = 0;
    int intKentuckyCount = 0;
    for (intIndex = 0; intIndex < intRecordCount; intIndex+=1) 
    {
        if (StringsAreEqual(audtAddressList[intIndex].strState, "Ohio"))
        {
            if (StringsAreEqual(audtAddressList[intIndex].strCounty, "Hamilton")) 
            {
                intOhioCount += 1;
                intohioHamilton+=1;
            }
            else if (StringsAreEqual(audtAddressList[intIndex].strCounty, "Butler")) 
            {
                intOhioCount += 1;
                intohioButler+=1;
            }
        }
        else if (StringsAreEqual(audtAddressList[intIndex].strState, "Kentucky")) 
        {
            if (StringsAreEqual(audtAddressList[intIndex].strCounty, "Boone")) 
            {
                intKentuckyCount += 1;
                intkyBoone+=1;
            }
            else if (StringsAreEqual(audtAddressList[intIndex].strCounty, "Kenton")) 
            {
                intKentuckyCount += 1;
                intkyKenton+=1;
            }
        }
    }

    printf("\Total Household by County:\n");

    if (intOhioCount >= 0)
    {
        printf("Ohio: %d\n", intOhioCount);
        if (intohioHamilton >= 0)
        {
            printf("   Hamilton: %d\n", intohioHamilton);
        }
        else
        {
            printf("   Hamilton: $0.00\n");
        }

        if (intohioButler >= 0)
        {
            printf("   Butler: %d\n", intohioButler);
        }
        else
        {
            printf("   Butler: $0.00\n");
        }
    }

    if (intKentuckyCount >= 0)
    {
        printf("Kentucky: %d\n", intKentuckyCount);

        if (intkyBoone >= 0)
        {
            printf("    Boone: %d\n", intkyBoone);
        }
        else
        {
            printf("   Boone: $0.00\n");
        }
        if (intkyKenton >= 0)
        {
            printf("    Kenton: %d\n", intkyKenton);
        }
        else
        {
            printf("   Kenton: $0.00\n");
        }
    }
}



// --------------------------------------------------------------------------------
// Name: TotalHouseholdsPerRace
// Abstract: using stringsareequal function to compare the two strings and if they
// match then add one to the counter
// --------------------------------------------------------------------------------
void TotalHouseholdsPerRace(udtAddressType *pudtAddress, int intRecordCount)
{
    int intcaucasian = 0;
    int intafricanAmerican = 0;
    int inthispanic = 0;
    int intasian = 0;
    int intother = 0;
    int intIndex = 0;

    for (intIndex = 0; intIndex < intRecordCount; intIndex+=1) 
    {
        if (StringsAreEqual(pudtAddress[intIndex].strRace, "Caucasian"))
        {
            intcaucasian+=1;
        }
        if (StringsAreEqual(pudtAddress[intIndex].strRace, "African American"))
        {
            intafricanAmerican+=1;
        }
        if (StringsAreEqual(pudtAddress[intIndex].strRace, "Hispanic"))
        {
            inthispanic+=1;
        }
        if (StringsAreEqual(pudtAddress[intIndex].strRace, "Asian"))
        {
            intasian+=1;
        }
        if (StringsAreEqual(pudtAddress[intIndex].strRace, "Other"))
        {
            intother+=1;
        }
    }

	printf("\nTotal Households Surveyed per Race:\n");
	printf("Caucasian: %d\n", intcaucasian);
	printf("African American: %d\n", intafricanAmerican);
	printf("Hispanic: %d\n", inthispanic);
	printf("Asian: %d\n", intasian);
	printf("Other: %d\n", intother);
}


// --------------------------------------------------------------------------------
// Name: PercentageBelowByCountyAndState
// Abstract: Calculating use a for loop to determine if the household meets the
// threshold or not
// --------------------------------------------------------------------------------
void PercentageBelowByCountyAndState(udtAddressType* pudtAddress, int intRecordCount)
{

    //declare variabvles
    int intBelowPovertyOhio = 0;
    int intBelowPovertyKentucky = 0;
    int intBelowPovertyHamilton = 0;
    int intBelowPovertyButler = 0;
    int intBelowPovertyKenton = 0;
    int intBelowPovertyBoone = 0;
    double dblPovertyThreshold = 0.0;
    int intTotalOhio = 0;
    int intTotalKentucky = 0;
    int intTotalHamilton = 0;
    int intTotalKenton = 0;
    int intTotalBoone = 0;
    int intTotalButler = 0;
    double dblPovertyOhio = 0;
    double dblPovertyBoone = 0;
    double dblPovertyButler = 0;
    double dblPovertyHamilton = 0;
    double dblPovertyKenton = 0;
    double dblPovertyKentucky = 0;
    int intIndex = 0;


    for (intIndex = 0; intIndex < intRecordCount; intIndex += 1)
    {

        // Checking poverty threshold based on household size
        if (pudtAddress[intIndex].intNumberinHousehold == 1)
        {
            dblPovertyThreshold = 12000.0;
        }
        else if (pudtAddress[intIndex].intNumberinHousehold == 2)
        {
            dblPovertyThreshold = 18000.0;
        }
        else if (pudtAddress[intIndex].intNumberinHousehold == 3)
        {
            dblPovertyThreshold = 25000.0;
        }
        else if (pudtAddress[intIndex].intNumberinHousehold == 4)
        {
            dblPovertyThreshold = 30000.0;
        }
        else if (pudtAddress[intIndex].intNumberinHousehold >= 5)
        {
            dblPovertyThreshold = 40000.0;
        }


        if (StringsAreEqual(pudtAddress[intIndex].strCounty, "Hamilton"))
        {
            intTotalOhio += 1;
            intTotalHamilton += 1;
            if (pudtAddress[intIndex].dblYearlyIncome < dblPovertyThreshold)
            {
                intBelowPovertyHamilton += 1;
                intBelowPovertyOhio += 1;
            }
        }
        else if (StringsAreEqual(pudtAddress[intIndex].strCounty, "Butler"))
        {
            intTotalOhio += 1;
            intTotalButler += 1;
            if (pudtAddress[intIndex].dblYearlyIncome < dblPovertyThreshold)
            {
                intBelowPovertyButler += 1;
                intBelowPovertyOhio += 1;
            }
        }
        else if (StringsAreEqual(pudtAddress[intIndex].strCounty, "Kenton"))
        {
            intTotalKentucky += 1;
            intTotalKenton += 1;
            if (pudtAddress[intIndex].dblYearlyIncome < dblPovertyThreshold)
            {
                intBelowPovertyKenton += 1;
                intBelowPovertyKentucky += 1;
            }
        }
        else if (StringsAreEqual(pudtAddress[intIndex].strCounty, "Boone"))
        {
            intTotalKentucky += 1;
            intTotalBoone += 1;
            if (pudtAddress[intIndex].dblYearlyIncome < dblPovertyThreshold)
            {
                intBelowPovertyBoone += 1;
                intBelowPovertyKentucky += 1;
            }
        }
    }


    dblPovertyOhio = (intTotalOhio > 0) ? (100.0 * intBelowPovertyOhio / intTotalOhio) : 0.0;
    dblPovertyHamilton = (intTotalHamilton > 0) ? (100.0 * intBelowPovertyHamilton / intTotalHamilton) : 0.0;
    dblPovertyButler = (intTotalButler > 0) ? (100.0 * intBelowPovertyButler / intTotalButler) : 0.0;
    dblPovertyKentucky = (intTotalKentucky > 0) ? (100.0 * intBelowPovertyKentucky / intTotalKentucky) : 0.0;
    dblPovertyKenton = (intTotalKenton > 0) ? (100.0 * intBelowPovertyKenton / intTotalKenton) : 0.0;
    dblPovertyBoone = (intTotalBoone > 0) ? (100.0 * intBelowPovertyBoone / intTotalBoone) : 0.0;

    // Display results


    printf("\nPercentage of Households Below Poverty per County and State:\n");
    printf("Ohio: %.2f%%\n", dblPovertyOhio);
    printf("    Hamilton: %.2f%%\n", dblPovertyHamilton);
    printf("    Butler: %.2f%%\n", dblPovertyButler);
    printf("Kentucky: %.2f%%\n", dblPovertyKentucky);
    printf("    Boone: %.2f%%\n", dblPovertyBoone);
    printf("    Kenton: %.2f%%\n", dblPovertyKenton);
}


// --------------------------------------------------------------------------------
// Name: PercentageBelowPoverty
// Abstract: Calculating use a for loop to determine if the household meets the
// threshold or not 
// --------------------------------------------------------------------------------
void PercentageBelowPoverty(udtAddressType* pudtAddress, int intRecordCount)
{
    int intBelowPoverty = 0;
    int intTotal = 0;
    int intIndex = 0;
    double dblPovertyThreshold = 0;
    double dblPercentageBelowPoverty = 0;

    for (int intIndex = 0; intIndex < intRecordCount; intIndex += 1)
    {

        if (pudtAddress[intIndex].intNumberinHousehold == 1)
        {
            dblPovertyThreshold = 12000.0;
        }
        else if (pudtAddress[intIndex].intNumberinHousehold == 2)
        {
            dblPovertyThreshold = 18000.0;
        }
        else if (pudtAddress[intIndex].intNumberinHousehold == 3)
        {
            dblPovertyThreshold = 25000.0;
        }
        else if (pudtAddress[intIndex].intNumberinHousehold == 4)
        {
            dblPovertyThreshold = 30000.0;
        }
        else if (pudtAddress[intIndex].intNumberinHousehold >= 5)
        {
            dblPovertyThreshold = 40000.0;
        }

        intTotal += 1;

        // Check if the household is below the poverty threshold
        if (pudtAddress[intIndex].dblYearlyIncome < dblPovertyThreshold)
        {
            intBelowPoverty += 1;
        }
    }


    dblPercentageBelowPoverty = 100.0 * ((double)intBelowPoverty / intTotal);

    // Display the result
    printf("\nPercentage of  Households Below Poverty:\n");
    printf("%.2f%%\n", dblPercentageBelowPoverty);
}



// --------------------------------------------------------------------------------
// Name: PercentageBelowPovertyPerRace
// Abstract: Calculating use a for loop to determine if the household meets the
// threshold or not and then checks if the races income is less than the threshold
// --------------------------------------------------------------------------------
void PercentageBelowPovertyPerRace(udtAddressType* pudtAddress, int intRecordCount)
{

    //declare variabvles
    int intBelowPovertyCaucasian = 0;
    int intBelowPovertyAfricanAmerican = 0;
    int intBelowPovertyHispanic = 0;
    int intBelowPovertyAsian = 0;
    int intBelowPovertyOther = 0;
    double dblPovertyThreshold = 0.0;
    int intTotalCaucasian = 0;
    int intTotalAfricanAmerican = 0;
    int intTotalHispanic = 0;
    int intTotalAsian = 0;
    int intTotalOther = 0;
    double dblPovertyCaucasian = 0;
    double dblPovertyAfricanAmerican = 0;
    double dblPovertyAsian = 0;
    double dblPovertyHispanic = 0;
    double dblPovertyOther = 0;
    int intIndex = 0;


    for (intIndex = 0; intIndex < intRecordCount; intIndex += 1)
    {

        // Checking poverty threshold based on household size
        if (pudtAddress[intIndex].intNumberinHousehold == 1)
        {
            dblPovertyThreshold = 12000.0;
        }
        else if (pudtAddress[intIndex].intNumberinHousehold == 2)
        {
            dblPovertyThreshold = 18000.0;
        }
        else if (pudtAddress[intIndex].intNumberinHousehold == 3)
        {
            dblPovertyThreshold = 25000.0;
        }
        else if (pudtAddress[intIndex].intNumberinHousehold == 4)
        {
            dblPovertyThreshold = 30000.0;
        }
        else if (pudtAddress[intIndex].intNumberinHousehold >= 5)
        {
            dblPovertyThreshold = 40000.0;
        }

        // Checking a if the household is below the poverty threshold
        if (StringsAreEqual(pudtAddress[intIndex].strRace, "Caucasian"))
        {
            intTotalCaucasian += 1;

            if (pudtAddress[intIndex].dblYearlyIncome < dblPovertyThreshold)
            {
                intBelowPovertyCaucasian += 1;
            }
        }
        if (StringsAreEqual(pudtAddress[intIndex].strRace, "African American"))
        {
            intTotalAfricanAmerican += 1;

            if (pudtAddress[intIndex].dblYearlyIncome < dblPovertyThreshold)
            {
                intBelowPovertyAfricanAmerican += 1;
            }
        }
        if (StringsAreEqual(pudtAddress[intIndex].strRace, "Hispanic"))
        {
            intTotalHispanic += 1;

            if (pudtAddress[intIndex].dblYearlyIncome < dblPovertyThreshold)
            {
                intBelowPovertyHispanic += 1;
            }
        }
        if (StringsAreEqual(pudtAddress[intIndex].strRace, "Asian"))
        {
            intTotalAsian += 1;

            if (pudtAddress[intIndex].dblYearlyIncome < dblPovertyThreshold)
            {
                intBelowPovertyAsian += 1;
            }
        }
        if (StringsAreEqual(pudtAddress[intIndex].strRace, "Other"))
        {
            intTotalOther += 1;

            if (pudtAddress[intIndex].dblYearlyIncome < dblPovertyThreshold) {
                intBelowPovertyOther += 1;

            }
        }
    }

    dblPovertyCaucasian = (intTotalCaucasian != 0) ? 100.0 * intBelowPovertyCaucasian / intTotalCaucasian : 0.0;
    dblPovertyAfricanAmerican = (intTotalAfricanAmerican != 0) ? 100.0 * intBelowPovertyAfricanAmerican / intTotalAfricanAmerican : 0.0;
    dblPovertyAsian = (intTotalAsian != 0) ? 100.0 * intBelowPovertyAsian / intTotalAsian : 0.0;
    dblPovertyHispanic = (intTotalHispanic != 0) ? 100.0 * intBelowPovertyHispanic / intTotalHispanic : 0.0;
    dblPovertyOther = (intTotalOther != 0) ? 100.0 * intBelowPovertyOther / intTotalOther : 0.0;



    printf("\nPercentage of Households Below Poverty per Race:\n");
    printf("Caucasian: %.2f%%\n", dblPovertyCaucasian);
    printf("African American: %.2f%%\n", dblPovertyAfricanAmerican);
    printf("Hispanic: %.2f%%\n", dblPovertyHispanic);
    printf("Asian: %.2f%%\n", dblPovertyAsian);
    printf("Other: %.2f%%\n", dblPovertyOther);
}



// --------------------------------------------------------------------------------
// Name: StringsAreEqual
// Abstract: Comparing Strings
// --------------------------------------------------------------------------------
int StringsAreEqual(char* strAddressString, char* strString)
{
    // Compare each character of both strings
    while (*strAddressString != '\0' && *strString != '\0')
    {
        if (*strAddressString != *strString) 
        {
            return 0;
        }
        strAddressString+=1;
        strString +=1;
    }
    if (*strAddressString == '\0' && *strString == '\0') {
        return 1; // Strings are equal
    }

    return 0;
}






