﻿Module MainModule
    'Declaring Public Variables for Accumulation
    Public dbldailygrosspay As Double
    Public dbldailynetpay As Double
    'Calculating Fica Tax
    Public Function Get_FICA_Tax(ByVal dblweeklyGrosspay As Double, ByVal dblYTDGrossPay As Double) As Double
        Dim dblSocialSecurity As Double
        Dim dblmedical As Double
        dblSocialSecurity = Get_Social_Security(dblweeklyGrosspay, dblYTDGrossPay)
        dblmedical = Get_Medical(dblweeklyGrosspay)
        Return dblSocialSecurity + dblmedical
    End Function
    'Calculating Social Security
    Public Function Get_Social_Security(ByVal dblweeklygrosspay As Double, ByVal dblYTDGrossPay As Double) As Double
        Dim dblsocialsecurity As Double
        If dblYTDGrossPay > 125000 Then
            dblsocialsecurity = 0
        Else
            If dblYTDGrossPay + dblweeklygrosspay > 125000 Then
                dblsocialsecurity = (125000 - dblYTDGrossPay) * 0.062
            Else
                dblsocialsecurity = 0.062 * dblweeklygrosspay
            End If
        End If
        Return dblsocialsecurity
    End Function
    'Calculating Medical
    Public Function Get_Medical(dblweeklyGrosspay) As Double
        Dim dblmedical As Double
        dblmedical = dblweeklyGrosspay * 0.0145
        Return dblmedical
    End Function
    'Calculating Federal Tax
    Public Function Get_Federal_Tax(ByVal dblweeklygrosspay As Double) As Double
        Dim dblfederalTaxes As Double
        If dblweeklygrosspay <= 50 Then
            dblfederalTaxes = 0
        Else
            If dblweeklygrosspay > 50 And dblweeklygrosspay < 500 Then
                dblfederalTaxes = (dblweeklygrosspay - 50) * 0.1
            Else
                If dblweeklygrosspay > 500 And dblweeklygrosspay < 2500 Then
                    dblfederalTaxes = (dblweeklygrosspay - 500) * 0.15 + 45
                Else
                    If dblweeklygrosspay > 2500 And dblweeklygrosspay < 5000 Then
                        dblfederalTaxes = (dblweeklygrosspay - 2500) * 0.2 + 45
                    Else
                        dblfederalTaxes = (dblweeklygrosspay - 5000) * 0.25 + 845
                    End If
                End If
            End If
        End If
        Return dblfederalTaxes
    End Function
    'Calculating Daily Subtotals
    Public Sub Calculate_Daily_Subtotals(ByRef dbldailygrosspay As Double, ByRef dbldailynetpay As Double, ByVal dblnetpay As Double, ByVal dblweeklygrosspay As Double)
        dbldailygrosspay = Calculate_Daily_GrossPay(dblweeklygrosspay)
        dbldailynetpay = Get_Daily_Net_Pay(dblnetpay)
    End Sub
    'Calculating Net Pay
    Public Function Get_Net_Pay(ByVal dblweeklygrosspay As Double, ByVal dblfica As Double, ByVal dblstatetaxes As Double, ByVal dblfederaltaxes As Double) As Double
        Dim dblnetpay As Double
        dblnetpay = dblweeklygrosspay - dblfica - dblstatetaxes - dblfederaltaxes
        Return dblnetpay
    End Function
    'Calculating GrossPay
    Public Function Calculate_Daily_GrossPay(ByVal dblweeklygrosspay As Double) As Double
        dbldailygrosspay = dbldailygrosspay + dblweeklygrosspay
        Return dbldailygrosspay
    End Function
    'Calculating Daily Net Pay
    Public Function Get_Daily_Net_Pay(ByVal dblnetpay As Double) As Double
        dbldailynetpay = dbldailynetpay + dblnetpay
        Return dbldailynetpay
    End Function
End Module