﻿Public Class frmEmployee
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'Declaring All Variables
        Dim dblWage As Double
        Dim dblYTDGrossPay As Double
        Dim intHours As Integer
        Dim dblWeeklyGrossPay As Double
        Dim dblFICA As Double
        Dim dblSocialSecurity As Double
        Dim dblMedical As Double
        Dim dblStateTaxes As Double
        Dim dblFederalTaxes As Double
        Dim dblnetpay As Double
        Dim strFirstName As String
        Dim strLastName As String
        Dim blnvalidated As Boolean = True
        'Calling for Validattion and Calculations
        Call Get_Validate_Input(intHours, dblWage, strFirstName, strLastName, dblYTDGrossPay, blnvalidated)
        If blnvalidated = True Then
            Call Calculate_Taxes(intHours, dblWage, dblWeeklyGrossPay, dblFICA, dblSocialSecurity, dblMedical, dblStateTaxes, dblFederalTaxes, dblnetpay, dblYTDGrossPay)
            Call Calculate_Daily_Subtotals(dbldailygrosspay, dbldailynetpay, dblnetpay, dblWeeklyGrossPay)
            Call Display_Total(dblWeeklyGrossPay, dblFICA, dblSocialSecurity, dblMedical, dblStateTaxes, dblFederalTaxes, dblnetpay)
        End If
    End Sub
    'get hours worked and hourly wage
    Private Sub Get_Validate_Input(ByRef inthours As Integer, ByRef dblwage As Double, ByRef strfirstname As String, strlastname As String, ByRef dblytdgrosspay As Double, ByRef blnvalidated As Boolean)
        Call Get_Validate_FirstName_and_LastName(strfirstname, strlastname, blnvalidated)
        If blnvalidated = True Then
            Call Get_Validate_Hours(inthours, blnvalidated)
        End If
        If blnvalidated = True Then
            Call Get_Validate_Wage(dblwage, blnvalidated)
        End If
        If blnvalidated = True Then
            Call Get_Validate_YTD(dblytdgrosspay, blnvalidated)
        End If
    End Sub
    'Validating Names
    Private Sub Get_Validate_FirstName_and_LastName(ByRef strfirstname As String, ByRef strlastname As String, blnvalidate As Boolean)
        If txtFirstName.Text = String.Empty Then
            MessageBox.Show("First Name is Required")
            txtFirstName.Focus()
            Exit Sub
        End If

        If txtLastName.Text = "" Then
            MessageBox.Show("Last Name is Required")
            txtLastName.Focus()
            Exit Sub
        End If
    End Sub
    'Validating Hours Worked
    Private Sub Get_Validate_Hours(ByRef inthours As Integer, ByRef blnvalidated As Boolean)
        If Short.TryParse(txtHoursWorked.Text, inthours) Then
            If inthours < 1 Then
                MessageBox.Show("Hours must be greater than 0")
                blnvalidated = False
                txtHoursWorked.Focus()
            End If
        Else
            MessageBox.Show("hours must be Exist and Numeric")
            blnvalidated = False
            txtHoursWorked.Focus()
        End If
    End Sub
    'Validating Wages
    Private Sub Get_Validate_Wage(ByRef dblwage As Double, ByRef blnvalidated As Boolean)
        If Double.TryParse(txtWage.Text, dblwage) Then
            If dblwage < 1 Then
                MessageBox.Show("Days must be greater than 0")
                blnvalidated = False
                txtWage.Focus()
            End If
        Else
            MessageBox.Show("Wage must be Exist and Numeric")
            blnvalidated = False
            txtWage.Focus()
        End If
    End Sub
    'Validating the year to date gross pay
    Private Sub Get_Validate_YTD(ByRef dblYTDGrossPay As Double, ByRef blnvalidated As Boolean)
        If Double.TryParse(txtYTDGrossPay.Text, dblYTDGrossPay) Then
            If dblYTDGrossPay < 1 Then
                MessageBox.Show("Salary must be greater than 0")
                blnvalidated = False
                txtYTDGrossPay.Focus()
            End If
        Else
            MessageBox.Show("Salary must be Exist and Numeric")
            blnvalidated = False
            txtYTDGrossPay.Focus()
        End If
    End Sub

    'Calculating WeeklyGross and All other Taxes
    Private Sub Calculate_Taxes(ByVal intHours As Integer, ByVal dblWage As Double, ByRef dblWeeklyGrossPay As Double, ByRef dblFICA As Double, ByRef dblSocialSecurity As Double, ByRef dblMedical As Double, ByRef dblStateTaxes As Double, ByRef dblFederalTaxes As Double, ByRef dblnetpay As Double, ByVal dblYTDGrossPay As Double)
        dblWeeklyGrossPay = Get_Weekly_Gross(intHours, dblWage)
        dblFICA = Get_FICA_Tax(dblWeeklyGrossPay, dblYTDGrossPay)
        dblStateTaxes = Get_State_Taxes(dblWeeklyGrossPay)
        dblFederalTaxes = Get_Federal_Tax(dblWeeklyGrossPay)
        dblnetpay = Get_Net_Pay(dblWeeklyGrossPay, dblFICA, dblStateTaxes, dblFederalTaxes)
    End Sub
    'Calculating Weekly Gross for Employee
    Private Function Get_Weekly_Gross(ByVal inthours As Double, ByVal dblwage As Double) As Double
        Dim dblweeklygrosspay As Double
        dblweeklygrosspay = inthours * dblwage

        If inthours > 40 Then
            dblweeklygrosspay = (40 * dblwage) + ((inthours - 40) * 1.5 * dblwage)
        End If
        Return dblweeklygrosspay
    End Function
    'Calculating State Taxes inside of Form
    Private Function Get_State_Taxes(ByVal dblweeklyGrosspay As Double) As Double
        Dim dblStateTaxes As Double

        If radOhio.Checked Then
            dblStateTaxes = dblweeklyGrosspay * 0.065
        Else
            If radKentucky.Checked Then
                dblStateTaxes = dblweeklyGrosspay * 0.06
            Else
                dblStateTaxes = 0.055 * dblweeklyGrosspay
            End If
        End If
        Return dblStateTaxes
    End Function
    'Displaying All Totals
    Private Sub Display_Total(ByVal dblWeeklyGrossPay As Double, ByVal dblFICA As Double, ByVal dblSocialSecurity As Double, ByVal dblMedical As Double, ByVal dblStateTaxes As Double, ByVal dblFederalTaxes As Double, ByVal dblnetpay As Double)
        lblGrossPay.Text = dblWeeklyGrossPay.ToString("C")
        lblFICA.Text = dblFICA.ToString("C")
        lblStateTax.Text = dblStateTaxes.ToString("C")
        lblFederalTax.Text = dblFederalTaxes.ToString("C")
        lblNetPay.Text = dblnetpay.ToString("C")
    End Sub
    'Clearing all labels and Focusing on First Name
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        lblFederalTax.ResetText()
        lblFICA.ResetText()
        lblStateTax.ResetText()
        lblGrossPay.ResetText()
        lblNetPay.ResetText()
        txtFirstName.Clear()
        txtHoursWorked.Clear()
        txtLastName.Clear()
        txtWage.Clear()
        txtFirstName.Focus()
        txtYTDGrossPay.Clear()
    End Sub
    'Closing Application
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class