﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnDailyNetPayTotal = New System.Windows.Forms.Button()
        Me.btnDailyGrossTotal = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.EmployeeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManagmentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DailyTotalsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DailyGrossTotalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DailyNetPayToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(114, 219)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(75, 23)
        Me.btnClose.TabIndex = 10
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnDailyNetPayTotal
        '
        Me.btnDailyNetPayTotal.Location = New System.Drawing.Point(157, 173)
        Me.btnDailyNetPayTotal.Name = "btnDailyNetPayTotal"
        Me.btnDailyNetPayTotal.Size = New System.Drawing.Size(107, 23)
        Me.btnDailyNetPayTotal.TabIndex = 9
        Me.btnDailyNetPayTotal.Text = "Daily Net Pay Total"
        Me.btnDailyNetPayTotal.UseVisualStyleBackColor = True
        '
        'btnDailyGrossTotal
        '
        Me.btnDailyGrossTotal.Location = New System.Drawing.Point(28, 173)
        Me.btnDailyGrossTotal.Name = "btnDailyGrossTotal"
        Me.btnDailyGrossTotal.Size = New System.Drawing.Size(107, 23)
        Me.btnDailyGrossTotal.TabIndex = 8
        Me.btnDailyGrossTotal.Text = "Daily Gross Total"
        Me.btnDailyGrossTotal.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(51, 112)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(196, 43)
        Me.Button2.TabIndex = 7
        Me.Button2.Text = "Managment"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(51, 51)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(196, 43)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "Employee"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EmployeeToolStripMenuItem, Me.ManagmentToolStripMenuItem, Me.DailyTotalsToolStripMenuItem, Me.CloseToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(294, 24)
        Me.MenuStrip1.TabIndex = 11
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'EmployeeToolStripMenuItem
        '
        Me.EmployeeToolStripMenuItem.Name = "EmployeeToolStripMenuItem"
        Me.EmployeeToolStripMenuItem.Size = New System.Drawing.Size(71, 20)
        Me.EmployeeToolStripMenuItem.Text = "Employee"
        '
        'ManagmentToolStripMenuItem
        '
        Me.ManagmentToolStripMenuItem.Name = "ManagmentToolStripMenuItem"
        Me.ManagmentToolStripMenuItem.Size = New System.Drawing.Size(84, 20)
        Me.ManagmentToolStripMenuItem.Text = "Managment"
        '
        'DailyTotalsToolStripMenuItem
        '
        Me.DailyTotalsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DailyGrossTotalToolStripMenuItem, Me.DailyNetPayToolStripMenuItem})
        Me.DailyTotalsToolStripMenuItem.Name = "DailyTotalsToolStripMenuItem"
        Me.DailyTotalsToolStripMenuItem.Size = New System.Drawing.Size(78, 20)
        Me.DailyTotalsToolStripMenuItem.Text = "Daily Totals"
        '
        'DailyGrossTotalToolStripMenuItem
        '
        Me.DailyGrossTotalToolStripMenuItem.Name = "DailyGrossTotalToolStripMenuItem"
        Me.DailyGrossTotalToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.DailyGrossTotalToolStripMenuItem.Text = "Daily Gross Total"
        '
        'DailyNetPayToolStripMenuItem
        '
        Me.DailyNetPayToolStripMenuItem.Name = "DailyNetPayToolStripMenuItem"
        Me.DailyNetPayToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.DailyNetPayToolStripMenuItem.Text = "Daily Net Pay"
        '
        'CloseToolStripMenuItem
        '
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        Me.CloseToolStripMenuItem.Size = New System.Drawing.Size(48, 20)
        Me.CloseToolStripMenuItem.Text = "Close"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(294, 252)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnDailyNetPayTotal)
        Me.Controls.Add(Me.btnDailyGrossTotal)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "frmMain"
        Me.Text = "Main"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnClose As Button
    Friend WithEvents btnDailyNetPayTotal As Button
    Friend WithEvents btnDailyGrossTotal As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents EmployeeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ManagmentToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DailyTotalsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DailyGrossTotalToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DailyNetPayToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CloseToolStripMenuItem As ToolStripMenuItem
End Class
