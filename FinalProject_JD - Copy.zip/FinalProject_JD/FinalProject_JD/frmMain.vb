﻿Public Class frmMain
    'Displaying Employee form when when user clicks the button
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim frmemployee As New frmEmployee
        frmemployee.ShowDialog()
    End Sub
    'Displaying Managment form when user clicks the button
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim frmmanagment As New frmManagment
        frmmanagment.ShowDialog()
    End Sub
    'Message Box Showing the Accumulated Daily Gross Total
    Private Sub btnDailyGrossTotal_Click(sender As Object, e As EventArgs) Handles btnDailyGrossTotal.Click

        MessageBox.Show("The Daily Gross Total is" & dbldailygrosspay.ToString("c"))
    End Sub
    'Message Box Showing The Accumulated Daily Net Total
    Private Sub btnDailyNetPayTotal_Click(sender As Object, e As EventArgs) Handles btnDailyNetPayTotal.Click
        MessageBox.Show("The Daily Net Total is" & dbldailynetpay.ToString("c"))
    End Sub
    'Closing the Application
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()
    End Sub
    'Show dialog for forms
    Private Sub EmployeeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EmployeeToolStripMenuItem.Click
        Dim Frmemployee As New frmEmployee
        Frmemployee.ShowDialog()
    End Sub
    'Show dialog for forms
    Private Sub ManagmentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ManagmentToolStripMenuItem.Click
        Dim frmmanagment As New frmManagment
        frmmanagment.ShowDialog()
    End Sub
    'Show dialog for forms
    Private Sub DailyGrossTotalToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DailyGrossTotalToolStripMenuItem.Click

        MessageBox.Show("The Daily Gross Total is" & dbldailygrosspay.ToString("c"))
    End Sub
    'Show dialog for forms
    Private Sub DailyNetPayToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DailyNetPayToolStripMenuItem.Click
        MessageBox.Show("The Daily Net Total is" & dbldailynetpay.ToString("c"))
    End Sub
    'Show dialog for forms
    Private Sub CloseToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CloseToolStripMenuItem.Click
        Close()
    End Sub

    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub
End Class