﻿Public Class frmManagment
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'Declaring Variables
        Dim dblGrossPay As Double
        Dim dblYTDGrossPay As Double
        Dim dblWeeklyGrossPay As Double
        Dim dblFICA As Double
        Dim dblSocialSecurity As Double
        Dim dblMedical As Double
        Dim dblStateTaxes As Double
        Dim dblFederalTaxes As Double
        Dim dblnetpay As Double
        Dim strFirstName As String
        Dim strLastName As String
        Dim blnvalidated As Boolean = True
        'Validating inputs and calling calculations
        Call Get_Validate_Input(dblGrossPay, strFirstName, strLastName, dblYTDGrossPay, blnvalidated)
        If blnvalidated = True Then
            Call Calculate_Taxes(dblGrossPay, dblWeeklyGrossPay, dblFICA, dblSocialSecurity, dblMedical, dblStateTaxes, dblFederalTaxes, dblnetpay, dblYTDGrossPay)
            Call Calculate_Daily_Subtotals(dbldailygrosspay, dbldailynetpay, dblnetpay, dblWeeklyGrossPay)
            Call Display_Total(dblWeeklyGrossPay, dblFICA, dblSocialSecurity, dblMedical, dblStateTaxes, dblFederalTaxes, dblnetpay)
        End If
    End Sub
    'get hours worked and hourly wage
    Private Sub Get_Validate_Input(ByRef dblgrosspay As Double, ByRef strfirstname As String, strlastname As String, ByRef dblYTDGrossPay As Double, ByRef blnvalidated As Boolean)
        Call Get_Validate_FirstName_and_LastName(strfirstname, strlastname, blnvalidated)
        If blnvalidated = True Then
            Call Get_Validate_GrossPay(dblgrosspay, blnvalidated)
            If blnvalidated = True Then
                Call Get_Validate_YTD(dblYTDGrossPay, blnvalidated)
            End If
        End If

    End Sub
    'Validating Names
    Private Sub Get_Validate_FirstName_and_LastName(ByRef strfirstname As String, ByRef strlastname As String, blnvalidate As Boolean)
        If txtFirstName.Text = String.Empty Then
            MessageBox.Show("First Name is Required")
            txtFirstName.Focus()
            Exit Sub
        End If

        If txtLastName.Text = "" Then
            MessageBox.Show("Last Name is Required")
            txtLastName.Focus()
            Exit Sub
        End If
    End Sub
    'vailidating gross pay
    Private Sub Get_Validate_GrossPay(ByRef dblgrosspay As Integer, ByRef blnvalidated As Boolean)
        If Double.TryParse(txtGrossPay.Text, dblgrosspay) Then
            If dblgrosspay < 1 Then
                MessageBox.Show("Salary must be greater than 0")
                blnvalidated = False
                txtGrossPay.Focus()
            End If
        Else
            MessageBox.Show("Salary must be Exist and Numeric")
            blnvalidated = False
            txtGrossPay.Focus()
        End If
    End Sub
    'validating YTD
    Private Sub Get_Validate_YTD(ByRef dblYTDGrossPay As Double, ByRef blnvalidated As Boolean)
        If Double.TryParse(txtYTDGrossPay.Text, dblYTDGrossPay) Then
            If dblYTDGrossPay < 0 Then
                MessageBox.Show("Salary must be greater than 0")
                blnvalidated = False
                txtYTDGrossPay.Focus()
            End If
        Else
            MessageBox.Show("Salary must be Exist and Numeric")
            blnvalidated = False
            txtYTDGrossPay.Focus()
        End If
    End Sub

    'Calculating Weekly Gross and Taxes
    Private Sub Calculate_Taxes(ByVal dblgrosspay As Double, ByRef dblWeeklyGrossPay As Double, ByRef dblFICA As Double, ByRef dblSocialSecurity As Double, ByRef dblMedical As Double, ByRef dblStateTaxes As Double, ByRef dblFederalTaxes As Double, ByRef dblnetpay As Double, ByVal dblYTDGrossPay As Double)
        dblWeeklyGrossPay = Get_Weekly_Gross(dblgrosspay)
        dblFICA = Get_FICA_Tax(dblWeeklyGrossPay, dblYTDGrossPay)
        dblStateTaxes = Get_State_Taxes(dblWeeklyGrossPay)
        dblFederalTaxes = Get_Federal_Tax(dblWeeklyGrossPay)
        dblnetpay = Get_Net_Pay(dblWeeklyGrossPay, dblFICA, dblStateTaxes, dblFederalTaxes)
    End Sub
    'Calculating Weekly Gross For Managment 
    Private Function Get_Weekly_Gross(ByVal dblgrosspay As Double) As Double
        Dim dblweeklyGrossPay As Double
        dblweeklyGrossPay = dblgrosspay / 52
        Return dblweeklyGrossPay
    End Function
    'Calculating State Taxes inside of Form
    Private Function Get_State_Taxes(ByVal dblweeklyGrosspay As Double) As Double
        Dim dblStateTaxes As Double

        If radOhio.Checked Then
            dblStateTaxes = dblweeklyGrosspay * 0.065
        Else
            If radKentucky.Checked Then
                dblStateTaxes = dblweeklyGrosspay * 0.06
            Else
                dblStateTaxes = 0.055 * dblweeklyGrosspay
            End If
        End If
        Return dblStateTaxes
    End Function
    'Displaying Totals
    Private Sub Display_Total(ByVal dblWeeklyGrossPay As Double, ByVal dblFICA As Double, ByVal dblSocialSecurity As Double, ByVal dblMedical As Double, ByVal dblStateTaxes As Double, ByVal dblFederalTaxes As Double, ByVal dblnetpay As Double)

        lblGrossPay.Text = dblWeeklyGrossPay.ToString("C")
        lblFICA.Text = dblFICA.ToString("C")
        lblStateTax.Text = dblStateTaxes.ToString("C")
        lblFederalTax.Text = dblFederalTaxes.ToString("C")
        lblNetPay.Text = dblnetpay.ToString("C")

    End Sub

    'Clearing all Text and Focusing on First Name
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        lblFederalTax.ResetText()
        lblFICA.ResetText()
        lblStateTax.ResetText()
        lblGrossPay.ResetText()
        lblNetPay.ResetText()
        txtFirstName.Clear()
        txtLastName.Clear()
        txtGrossPay.Clear()
        txtFirstName.Clear()
        txtYTDGrossPay.Clear()
    End Sub
    'Closing Application
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class
