import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/** 
 * @author Jaxson DeHaven
 * @version 1.0
 */

/** 
 *ModifyStudentsXML
 */
public class ModifyStudentsXML{
	/** 
	 *main
	 *@param String args
	 */
    public static void main(String[] args) {
    	//define your input file
        String filePath = "students_out.xml";
        File xmlFile = new File(filePath);
        //create the instance of the document builder factory
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder;
        //start a try-catch block
        try {
        	//create a new Document Builder
            dBuilder = dbFactory.newDocumentBuilder();
            //parse the xml and get the document elements
            Document doc = dBuilder.parse(xmlFile);
            doc.getDocumentElement().normalize();
            
            //update attribute value
            updateAttributeValue(doc);
            
            //update Element value
            updateElementValue(doc);
            
            //delete element
            deleteElement(doc);
            
            //add new element
            addElement(doc);
            
            //write the updated document to file or console
            doc.getDocumentElement().normalize();
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File("students_updated.xml"));
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.transform(source, result);
            System.out.println("XML file updated successfully");
            
        } catch (SAXException | ParserConfigurationException | IOException | TransformerException e1) {
            e1.printStackTrace();
        }
    }
    
    /** 
	 *addElement
	 *@param doc
	 */
    private static void addElement(Document doc) {
        NodeList students = doc.getElementsByTagName("Student");
        Element emp = null;
        
        //loop for each student
        
        // Added a GPA for the students because its a common requirment for data like this
        for(int i=0; i<students.getLength();i++){
            emp = (Element) students.item(i);
            Element salaryElement = doc.createElement("GPA");
            salaryElement.appendChild(doc.createTextNode("3.5"));
            emp.appendChild(salaryElement);
        }
    }
    
    /** 
	 *deleteElement
	 *@param doc
	 */
    private static void deleteElement(Document doc) {
        NodeList students = doc.getElementsByTagName("Student");
        Element emp = null;
        //loop for each employee
        for(int i=0; i<students.getLength();i++){
            emp = (Element) students.item(i);
            Node genderNode = emp.getElementsByTagName("gender").item(0);
            emp.removeChild(genderNode);
        }
        
    }
    
    /** 
	 *updateElementValue
	 *@param doc
	 */
    private static void updateElementValue(Document doc) {
        NodeList students = doc.getElementsByTagName("Student");
        Element emp = null;
        //loop for each employee
        for(int i=0; i<students.getLength();i++){
            emp = (Element) students.item(i);
            Node name = emp.getElementsByTagName("name").item(0).getFirstChild();
            name.setNodeValue(name.getNodeValue().toUpperCase());
        }
    }
    
    /** 
	 *updateAttributeValue
	 *@param doc
	 */
    private static void updateAttributeValue(Document doc) {
        NodeList students = doc.getElementsByTagName("Student");
        Element emp = null;
        //loop for each employee
        for(int i=0; i<students.getLength();i++){
            emp = (Element) students.item(i);
            String gender = emp.getElementsByTagName("gender").item(0).getFirstChild().getNodeValue();
            if(gender.equalsIgnoreCase("male")){
                //prefix id attribute with M
                emp.setAttribute("id", "M"+emp.getAttribute("id"));
            }else{
                //prefix id attribute with F
                emp.setAttribute("id", "F"+emp.getAttribute("id"));
            }
        }
    }

}
