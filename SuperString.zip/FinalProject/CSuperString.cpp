// --------------------------------------------------------------------------------
// Name: Jaxson DeHaven
// Class: SET-151-400 
// Abstract: Final Projcet
// --------------------------------------------------------------------------------

// --------------------------------------------------------------------------------
// Includes
// --------------------------------------------------------------------------------
#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#include "CSuperString.h";
#include <iostream>
#include <math.h>
using namespace std;
// --------------------------------------------------------------------------------
// Constants
// --------------------------------------------------------------------------------
const int intARRAY_SIZE = 100;

//---------------------------------------------------------------------------------
// User Defined Types (UDTs)
//---------------------------------------------------------------------------------


// --------------------------------------------------------------------------------
// Prototypes
// --------------------------------------------------------------------------------


// --------------------------------------------------------------------------------
// Name: Constructor 
// Abstract:  Default Constructor
// --------------------------------------------------------------------------------
CSuperString::CSuperString()
{
	Initialize("");
}



// --------------------------------------------------------------------------------
// Name: Parameterized Constructor #1
// Abstract:  const char*
// --------------------------------------------------------------------------------
CSuperString::CSuperString(const char* pstrStringToCopy)
{
	Initialize(pstrStringToCopy);
}



// --------------------------------------------------------------------------------
// Name: Parameterized Constructor #2
// Abstract:  boolean
// --------------------------------------------------------------------------------
CSuperString::CSuperString(const bool blnBooleanToCopy)
{
	Initialize("");

	if (blnBooleanToCopy == true)
	{
		*this = "true";
	}
	if (blnBooleanToCopy == false)
	{
		*this = "false";
	}
}



// --------------------------------------------------------------------------------
// Name: Parameterized Constructor #3
// Abstract:  char
// --------------------------------------------------------------------------------
CSuperString::CSuperString(const char chrLetterToCopy)
{
	
	Initialize("");

	*this = chrLetterToCopy;

}



// --------------------------------------------------------------------------------
// Name: Parameterized Constructor #4
// Abstract:  short
// --------------------------------------------------------------------------------
CSuperString::CSuperString(const short shtShortToCopy)
{
	char strSource[8] = "";  
	sprintf(strSource, "%hd", shtShortToCopy);
	Initialize(strSource);
}



// --------------------------------------------------------------------------------
// Name: Parameterized Constructor #5
// Abstract:  int
// --------------------------------------------------------------------------------
CSuperString::CSuperString(const int intIntegerToCopy)
{
	char strSource[12] = "";  
	sprintf(strSource, "%d", intIntegerToCopy);
	Initialize(strSource);
}



// --------------------------------------------------------------------------------
// Name: Parameterized Constructor #6
// Abstract:  long
// --------------------------------------------------------------------------------
CSuperString::CSuperString(const long lngLongToCopy)
{
	char strSource[21] = ""; 
	sprintf(strSource, "%ld", lngLongToCopy);
	Initialize(strSource);
}



// --------------------------------------------------------------------------------
// Name: Parameterized Constructor #7
// Abstract:  float
// --------------------------------------------------------------------------------
CSuperString::CSuperString(const float sngFloatToCopy)
{
	char strSource[32] = "";  

	sprintf(strSource, "%.2e", sngFloatToCopy);
	Initialize(strSource);
}



// --------------------------------------------------------------------------------
// Name: Parameterized Constructor #8
// Abstract:  double
// --------------------------------------------------------------------------------
CSuperString::CSuperString(const double dblDoubleToCopy)
{
	char strSource[32] = "";  
	sprintf(strSource, "%.2e", dblDoubleToCopy);
	Initialize(strSource);
}

// --------------------------------------------------------------------------------
// Name: Copy Constructor 
// Abstract:  Default Constructor
// --------------------------------------------------------------------------------
CSuperString::CSuperString(const CSuperString &ssOriginalToCopy)
{
	Initialize(ssOriginalToCopy.ToString());
}

	// --------------------------------------------------------------------------------
	// Name: Initialize 
	// Abstract: Set class pointers to zero and then call set methods
	// --------------------------------------------------------------------------------
void CSuperString::Initialize(const char* pstrSource)
{
	m_pstrSuperString = 0;

	*this = pstrSource;

}



// --------------------------------------------------------------------------------
// Name: Length 
// Abstract: how long
// --------------------------------------------------------------------------------
long CSuperString::Length() const
{
	long lngLength = 0;

	lngLength = (long) strlen(m_pstrSuperString);

	return lngLength;
}



// --------------------------------------------------------------------------------
// Name: Assignment operator
// Abstract: equaks char chrLetterToCopy
// --------------------------------------------------------------------------------
void CSuperString:: operator=(const char chrLetterToCopy)
{


	char strSource[2] = { chrLetterToCopy, 0 };
	*this = strSource;
}



// --------------------------------------------------------------------------------
// Name: Assignment operator
// Abstract: equaks char pstrSource
// --------------------------------------------------------------------------------
void CSuperString::operator = (const char* pstrSource)
{
	if (m_pstrSuperString != pstrSource)
	{
		CleanUp();

		DeepCopy(pstrSource);
	}
}



// --------------------------------------------------------------------------------
// Name: Assignment operator
// Abstract: assignment operator
// --------------------------------------------------------------------------------
void CSuperString::operator=(const CSuperString& ssStringToCopy)
{
	if (this != &ssStringToCopy) 
	{
		CleanUp();
		DeepCopy(ssStringToCopy.ToString());  
	}
}


// --------------------------------------------------------------------------------
// Name: Assignment operator
// Abstract: plus equals pstrStringToAppend
// --------------------------------------------------------------------------------
void CSuperString::operator += (const char* pstrStringToAppend)
{
	long lnglength = Length();
	long lngAppendLength = (long)strlen(pstrStringToAppend);
	long lngSize = 0;

	lngSize = lnglength + lngAppendLength + 1;

	char* chrBuffer = new char[lngSize];

	if (m_pstrSuperString != 0)
	{
		strcpy_s(chrBuffer, lngSize, m_pstrSuperString);
	}
	else
	{
		chrBuffer[0] = 0;

	}

	strcat_s(chrBuffer, lngSize, pstrStringToAppend);

	CleanUp();

	m_pstrSuperString = chrBuffer;
}



// --------------------------------------------------------------------------------
// Name: Assignment operator
// Abstract: plus equals chrCharacterToAppend
// --------------------------------------------------------------------------------
void CSuperString::operator += (const char chrCharacterToAppend)
{

	char strSource[2] = { chrCharacterToAppend, 0 };
	*this += strSource;  
}



void CSuperString::operator += (const CSuperString& ssStringToAppend)
{
	*this += ssStringToAppend.ToString();
}

// --------------------------------------------------------------------------------
// Name: Assignment operator
// Abstract: plus the left string and right string
// --------------------------------------------------------------------------------
CSuperString operator+(const CSuperString& ssLeft, const CSuperString& ssRight)
{

	CSuperString strSource(ssLeft);


	strSource += ssRight;


	return strSource;
}



// --------------------------------------------------------------------------------
// Name: Assignment operator
// Abstract: plus the left side  and right string
// --------------------------------------------------------------------------------
CSuperString operator+(const char* pstrLeftSide, const CSuperString& ssRightString)
{
	CSuperString strSource(pstrLeftSide);
	strSource += ssRightString;
	return strSource;
}



// --------------------------------------------------------------------------------
// Name: Assignment operator
// Abstract: plus the ssleftstring and the right side
// --------------------------------------------------------------------------------
CSuperString operator+(const CSuperString& ssLeftString, const char* pstrRightSide)
{
	CSuperString strSource(ssLeftString);
	strSource += pstrRightSide;
	return strSource;
}


// --------------------------------------------------------------------------------
// Name: FindFirstIndexOf
// Abstract: chrLetterToFind 
// --------------------------------------------------------------------------------
long CSuperString::FindFirstIndexOf(const char chrLetterToFind)
{
	int intIndex = 0;
	int intLettertoFindIndex = 0;

	while (*(m_pstrSuperString + intIndex) != 0)
	{
		if (*(m_pstrSuperString + intIndex) == chrLetterToFind)
		{
			intLettertoFindIndex = intIndex;
			break;
		}
		intIndex += 1;
	}
	
	
	return intLettertoFindIndex;
}



// --------------------------------------------------------------------------------
// Name: FindFirstIndexOf
// Abstract: finding the first index using chrLetterToFind, lngStartIndex
// --------------------------------------------------------------------------------
long CSuperString::FindFirstIndexOf(const char chrLetterToFind, long lngStartIndex)
{
	long lngIndex = 0;

	if (lngStartIndex < 0) 
	{
		lngStartIndex = 0;
	}

	
	for (lngIndex = lngStartIndex; *(m_pstrSuperString + lngIndex) != 0; lngIndex+=1)
	{
		if (*(m_pstrSuperString + lngIndex) == chrLetterToFind)
		{
			return lngIndex;
		}
	}
}

// --------------------------------------------------------------------------------
// Name: FindLastIndexOf
// Abstract: finding the last index using chrLetterToFind, lngStartIndex
// --------------------------------------------------------------------------------
long CSuperString::FindLastIndexOf(const char chrLetterToFind)
{
	int intIndex = 0;
	int intLastIndex = -1;


	while (*(m_pstrSuperString + intIndex) != 0)
	{

		if (*(m_pstrSuperString+intIndex) == chrLetterToFind)
		{
			intLastIndex = intIndex;
		}
		intIndex += 1;
	}


	return intLastIndex;
}



// --------------------------------------------------------------------------------
// Name: FindFirstIndexOf
// Abstract: getting the first index using pstrSubStringToFind
// --------------------------------------------------------------------------------
long CSuperString::FindFirstIndexOf(const char* pstrSubStringToFind)
{
	int intIndex = 0;


	while (m_pstrSuperString[intIndex] != 0)
	{
		if (m_pstrSuperString[intIndex] == pstrSubStringToFind[0])
		{	
			bool blnTrue = true;
			int intSubIndex = 0;
			while (pstrSubStringToFind[intSubIndex] != 0)
			{
				if (m_pstrSuperString[intIndex + intSubIndex] != pstrSubStringToFind[intSubIndex])
				{
					blnTrue = false;
					break;
				}
				intSubIndex +=1;
			}
			if (blnTrue) 
			{
				return intIndex;
			}
		}
		intIndex+=1;
	}
}



// --------------------------------------------------------------------------------
// Name: FindFirstIndexOf
// Abstract: finding the first index with pstrSubStringToFind lngStartIndex
// --------------------------------------------------------------------------------
long CSuperString::FindFirstIndexOf(const char* pstrSubStringToFind, long lngStartIndex)
{

	int intIndex = lngStartIndex;


	if (lngStartIndex < 0)
	{
		lngStartIndex = 0;
	}

	
	while (m_pstrSuperString[intIndex] != 0)
	{
		
		if (m_pstrSuperString[intIndex] == pstrSubStringToFind[0])
		{
			bool blnTrue = true;
			int intSubIndex = 0;
			while (pstrSubStringToFind[intSubIndex] != 0)
			{
				
				if (m_pstrSuperString[intIndex + intSubIndex] != pstrSubStringToFind[intSubIndex])
				{
					blnTrue = false;
					break;
				}
				intSubIndex += 1;
			}

			
			if (blnTrue)
			{
				return intIndex;
			}
		}
		intIndex+=1;
	}
}



// --------------------------------------------------------------------------------
// Name: FindFirstIndexOf
// Abstract: finding the last index with pstrSubStringToFind
// --------------------------------------------------------------------------------
long CSuperString::FindLastIndexOf(const char* pstrSubStringToFind)
{

	int intIndex = 0;

	int intlastIndex = -1;



	while (m_pstrSuperString[intIndex] != 0)
	{

		if (m_pstrSuperString[intIndex] == pstrSubStringToFind[0])
		{
			bool blnTrue = true;
			int intSubIndex = 0;
			while (pstrSubStringToFind[intSubIndex] != 0)
			{
				if (m_pstrSuperString[intIndex + intSubIndex] != pstrSubStringToFind[intSubIndex])
				{
					blnTrue = false;
					break;
				}
				intSubIndex+=1;
			}


			if (blnTrue)
			{
				intlastIndex = intIndex;
			}
		}
		intIndex += 1;
	}

	return intlastIndex;
}



// --------------------------------------------------------------------------------
// Name: ToUpperCase
// Abstract: converting to uppercase using pstrSubStringToFind
// --------------------------------------------------------------------------------
const char* CSuperString::ToUpperCase()
{

	int intLength = 0;
	char* pchrUpper;
	char chrSuperString;

	while (m_pstrSuperString[intLength] != 0) 
	{ 
		intLength+=1; 
	}

	pchrUpper = new char[intLength + 1];

	int intIndex = 0;
	while (m_pstrSuperString[intIndex] != 0)
	{
		chrSuperString = m_pstrSuperString[intIndex];
		
		if (chrSuperString >= 'a' && chrSuperString <= 'z')
		{
			*(pchrUpper + intIndex) = chrSuperString - 32;
		}
		else
		{
			*(pchrUpper + intIndex) = chrSuperString;
		}
		intIndex+=1;
	}
	*(pchrUpper + intIndex) = 0;

	return pchrUpper;
}



// --------------------------------------------------------------------------------
// Name: ToLowerCase
// Abstract: converting to lowercase using ascii characters
// --------------------------------------------------------------------------------
const char* CSuperString::ToLowerCase()
{
	int intLength = 0;
	char* pchrLower;
	char chrSuperString = ' ';

	while (*(m_pstrSuperString + intLength) != 0)
	{
		intLength += 1;
	}

	pchrLower = new char[intLength + 1];

	int intIndex = 0;
	while (*(m_pstrSuperString + intIndex) != 0)
	{
		 chrSuperString = *(m_pstrSuperString + intIndex);

		if (chrSuperString >= 'A' && chrSuperString <= 'Z')
		{
			*(pchrLower + intIndex) = chrSuperString + 32;
		}
		else
		{
			*(pchrLower + intIndex) = chrSuperString;
		}
		intIndex += 1;
	}
	*(pchrLower + intIndex) = 0;

	return pchrLower;
}



// --------------------------------------------------------------------------------
// Name: TrimLeft
// Abstract: triming the left side of m_pstrSuperString
// --------------------------------------------------------------------------------
const char* CSuperString::TrimLeft()
{
	int intLength = Length();
	int intFirst = 0;
	int intIndex = 0;
	int intNewLength = 0;
	char* chrTrimmed;

	while (intFirst < intLength && IsitWhiteSpace(m_pstrSuperString[intFirst]))
	{
		intFirst+=1;
	}

	

	intNewLength = intLength - intFirst;
	 chrTrimmed = new char[intNewLength + 1]; 


	for (intIndex = 0; intIndex < intNewLength; intIndex+=1)
	{
		*(chrTrimmed + intIndex) = m_pstrSuperString[intFirst + intIndex];
	}
	*(chrTrimmed + intNewLength) = 0;

	return chrTrimmed;
}



// --------------------------------------------------------------------------------
// Name: TrimRight
// Abstract: triming the right side of m_pstrSuperString
// --------------------------------------------------------------------------------
const char* CSuperString::TrimRight()
{
	int intLength = 0;
	int intLast = 0;
	int intIndex = 0;
	int intNewLength = 0;
	char* chrTrimmed;

	intLength = Length();
	 intLast = intLength - 1;
	while (intLast >= 0 && IsitWhiteSpace(m_pstrSuperString[intLast]))
	{
		intLast-=1;
	}

	intNewLength = intLast + 1;
	chrTrimmed = new char[intNewLength + 1]; 


	for  (intIndex = 0; intIndex < intNewLength; intIndex+=1)
	{
		*(chrTrimmed + intIndex) = *(m_pstrSuperString + intIndex);
	}
	*(chrTrimmed + intNewLength) = 0;

	return chrTrimmed;
}



// --------------------------------------------------------------------------------
// Name: Trim
// Abstract: Remove leading and trailing whitespace 
// --------------------------------------------------------------------------------
const char* CSuperString::Trim()
{

	int intFirst = 0;
	int intLength = Length();
	char* emptyStr = new char[1];
	int intLastWhiteSpace = 0;
	int intNewLength = 0;
	int intIndex = 0;
	char* chrTrimmed;


	while (intFirst < intLength && IsitWhiteSpace(m_pstrSuperString[intFirst])) 
	{
		intFirst+=1;
	}


	 intLastWhiteSpace = intLength - 1;
	while (intLastWhiteSpace >= intFirst && IsitWhiteSpace(m_pstrSuperString[intLastWhiteSpace])) 
	{
		intLastWhiteSpace-=1;
	}


	 intNewLength = intLastWhiteSpace - intFirst + 1;
	 chrTrimmed = new char[intNewLength + 1]; 

	for (intIndex = 0; intIndex < intNewLength; intIndex+=1)
	{
		*(chrTrimmed + intIndex) = m_pstrSuperString[intFirst + intIndex];
	}

	chrTrimmed[intNewLength] = 0;

	return chrTrimmed;
}



// --------------------------------------------------------------------------------
// Name: IsWhiteSpace
// Abstract: Return true if letter is a space, tab, newline or carriage return
// --------------------------------------------------------------------------------
int CSuperString::IsitWhiteSpace(char chrLetterToCheck)
{
	int blnIsWhiteSpace = 0;

	// Space
	if (chrLetterToCheck == ' ') blnIsWhiteSpace = 1;

	// Tab
	if (chrLetterToCheck == '\t') blnIsWhiteSpace = 1;

	// Carriarge return
	if (chrLetterToCheck == '\r') blnIsWhiteSpace = 1;

	// Line feed
	if (chrLetterToCheck == '\n') blnIsWhiteSpace = 1;

	return blnIsWhiteSpace;
}



// --------------------------------------------------------------------------------
// Name: Reverse 
// Abstract: compltely reversing the characters
// --------------------------------------------------------------------------------
const char* CSuperString::Reverse()
{
	int intlength = Length();
	char* pchrReversed;
	int intIndex = 0;


	pchrReversed = new char[intlength + 1];
	for (intIndex = 0; intIndex < intlength; intIndex+=1)
	{
		*(pchrReversed + intIndex) = m_pstrSuperString[intlength - 1 - intIndex];
	}

	*(pchrReversed + intlength) = 0;

	return pchrReversed;
}



// --------------------------------------------------------------------------------
// Name: Left 
// Abstract: Memory-allocated copy
// --------------------------------------------------------------------------------	
const char* CSuperString::Left(long lngCharactersToCopy)
{
	long lngLength = Length();
	long lngIndex = 0;
	char* pchrLeft;

	if (lngCharactersToCopy > lngLength)
	{
		lngCharactersToCopy = lngLength;
	}

	pchrLeft = new char[lngCharactersToCopy + 1];


	for (lngIndex = 0; lngIndex < lngCharactersToCopy; lngIndex+=1)
	{
		*(pchrLeft + lngIndex) = *(m_pstrSuperString + lngIndex);
	}


	pchrLeft[lngCharactersToCopy] = 0;

	return pchrLeft;
}



// --------------------------------------------------------------------------------
// Name: Right 
// Abstract: Memory-allocated copy
// --------------------------------------------------------------------------------	
const char* CSuperString::Right(long lngCharactersToCopy)
{
	long lngLength = Length();
	long lngIndex = 0;
	char* pchrRight;
	long lngStartIndex = 0;

	if (lngCharactersToCopy > lngLength)
	{
		lngCharactersToCopy = lngLength;
	}

	lngStartIndex = lngLength - lngCharactersToCopy;

	pchrRight = new char[lngCharactersToCopy + 1];


	for (lngIndex = 0; lngIndex < lngCharactersToCopy; lngIndex += 1)
	{
		*(pchrRight + lngIndex) = *(m_pstrSuperString + lngIndex);
	}


	*(pchrRight + lngCharactersToCopy) = 0;

	return pchrRight;
}



// --------------------------------------------------------------------------------
// Name: Substring 
// Abstract: Memory-allocated copy
// --------------------------------------------------------------------------------
const char* CSuperString::Substring(long lngStart, long lngSubStringLength)
{
	{
		long lngLength = 0; 
		char* pchrEmpty;
		char* pchrSubString;


		lngLength = Length();

		if (lngStart >= lngLength)
		{
			pchrEmpty = new char[1];
			pchrEmpty[0] = 0;
			return pchrEmpty;
		}


		pchrSubString = new char[lngSubStringLength + 1];

		for (lngLength = 0; lngLength < lngSubStringLength; lngLength+=1)
		{
			*(pchrSubString+lngLength) = m_pstrSuperString[lngStart + lngLength];
		}

		*(pchrSubString + lngSubStringLength) = 0;

		return pchrSubString;
	}
}



// --------------------------------------------------------------------------------
// Name: Replace 
// Abstract: replacing characters with chrLetterToFind, chrReplace
// --------------------------------------------------------------------------------
const char* CSuperString::Replace(char chrLetterToFind, char chrReplace)
{
	long lngIndex = 0;

	long lngLength = 0;
	char* pchrResult;

	lngLength = Length();

	pchrResult = new char[lngLength + 1];


	for (lngIndex = 0; lngIndex < lngLength; lngIndex+=1)
	{
		if (*(m_pstrSuperString + lngIndex) == chrLetterToFind)
			*(pchrResult + lngIndex) = chrReplace;
		else
			*(pchrResult+lngIndex) = *(m_pstrSuperString + lngIndex);
	}


	*(pchrResult + lngLength) = 0;

	return pchrResult;
}



// --------------------------------------------------------------------------------
// Name: Replace 
// Abstract: replacing characters pstrFind, pstrReplace
// --------------------------------------------------------------------------------
const char* CSuperString::Replace(const char* pstrFind, const char* pstrReplace)
{
	long lngOriginalLength = Length();
	long lngFindLength = strlen(pstrFind);
	long lngReplaceLength = strlen(pstrReplace);
	int  intCount = 0;
	long lngIndex1 = 0;
	long lngNewLength = 0;

	while (lngIndex1 <= lngOriginalLength - lngFindLength) 
	{
		if (strncmp(&m_pstrSuperString[lngIndex1], pstrFind, lngFindLength) == 0) 
		{
			intCount+=1;
			lngIndex1 += lngFindLength;
		}
		else {
			lngIndex1+=1;
		}
	}


	 lngNewLength = lngOriginalLength + intCount * (lngReplaceLength - lngFindLength);
	char* pchrResult = new char[lngNewLength + 1];

	long lngIndex2 = 0;  
	long lngNewIndex = 0;  
	long lngIndex3;        

	while (lngIndex2 < lngOriginalLength) 
	{
	
		if (lngIndex2 <= lngOriginalLength - lngFindLength && strncmp(&m_pstrSuperString[lngIndex2], pstrFind, lngFindLength) == 0)
		{
			
			for (lngIndex3 = 0; lngIndex3 < lngReplaceLength; lngIndex3+=1) {
				pchrResult[lngNewIndex] = pstrReplace[lngIndex3];
				lngNewIndex += 1;
			}
			lngIndex2 += lngFindLength;
		}
		else {
			
			pchrResult[lngNewIndex] = m_pstrSuperString[lngIndex2];

			lngNewIndex += 1;
			lngIndex2 += 1;
		}
	}


	pchrResult[lngNewLength] = 0;


	return pchrResult;
}



// --------------------------------------------------------------------------------
// Name: Insert 
// Abstract: inserting a character with chrLetterToInsert, lngIndex
// --------------------------------------------------------------------------------
const char* CSuperString::Insert(const char chrLetterToInsert, long lngIndex)
{
	long lngIndex2 = 0;
	long lngOriginalLength = Length();
	char* pResult;


	pResult = new char[lngOriginalLength + 2];


	for (lngIndex2 = 0; lngIndex2 < lngIndex; lngIndex2+=1)
	{
		*(pResult+lngIndex2) = *(m_pstrSuperString+lngIndex2);
	}

	*(pResult + lngIndex) = chrLetterToInsert;


	for (lngIndex2 = lngIndex; lngIndex2 < lngOriginalLength; lngIndex2+=1)
	{
		pResult[lngIndex2 + 1] = *(m_pstrSuperString + lngIndex2);
	}

	pResult[lngOriginalLength + 1] = 0;

	return pResult;
}



// --------------------------------------------------------------------------------
// Name: Insert 
// Abstract: inserting a charcter with pstrSubString, lngIndex
// --------------------------------------------------------------------------------
const char* CSuperString::Insert(const char* pstrSubString, long lngIndex)
{
	long lngOriginalLength = 0; 
	long lngSubStringLength = 0; 
	char* pResult;
	long lngIndex2 = 0;
	long lngIndex3 = 0;

	lngOriginalLength = Length();

	lngSubStringLength = strlen(pstrSubString);


	pResult = new char[lngOriginalLength + lngSubStringLength + 1];

	for (lngIndex2 = 0; lngIndex2 < lngIndex; lngIndex2+=1)
	{
		pResult[lngIndex2] = m_pstrSuperString[lngIndex2];
	}


	for (lngIndex3 = 0; lngIndex3 < lngSubStringLength; lngIndex3+=1)
	{
		pResult[lngIndex + lngIndex3] = pstrSubString[lngIndex3];
	}


	for (lngIndex2 = lngIndex; lngIndex2 < lngOriginalLength; lngIndex2+=1)
	{
		pResult[lngSubStringLength + lngIndex2] = m_pstrSuperString[lngIndex2];
	}


	pResult[lngOriginalLength + lngSubStringLength] = 0;
	return pResult;
}



// --------------------------------------------------------------------------------
// Name: char& operator [ ] 
// Abstract: lngIndex
// --------------------------------------------------------------------------------
char& CSuperString::operator [ ] (long lngIndex)
{
	if (lngIndex < 0 || lngIndex >= Length()) {
		cout << "Index out of bounds" << endl;
	}
	return m_pstrSuperString[lngIndex];
}



// --------------------------------------------------------------------------------
// Name: const char& operator [ ] 
// Abstract: lngIndex 
// --------------------------------------------------------------------------------
const char& CSuperString::operator [ ] (long lngIndex) const
{
	if (lngIndex < 0 || lngIndex >= Length()) {
		cout << "Index out of bounds" << endl;
	}
	return m_pstrSuperString[lngIndex];
}

// --------------------------------------------------------------------------------
// Name: DeepCopy 
// Abstract: Memory-allocated copy
// --------------------------------------------------------------------------------
void CSuperString::DeepCopy(const char* pstrSource)
{
	m_pstrSuperString = CloneString(pstrSource);


}



	// --------------------------------------------------------------------------------
	// Name: CloneString 
	// Abstract: Memory-allocated copy
	// --------------------------------------------------------------------------------
	char* CSuperString::CloneString(const char* pstrSource)
	{
		char* pstrClone = 0;
		long lngLength = 0;

		if (pstrSource != 0)
		{
			lngLength = strlen(pstrSource);
			pstrClone = new char[lngLength + 1];
			strcpy_s(pstrClone, lngLength + 1, pstrSource);

		}
		else
		{
			pstrClone = new char[1];
			*(pstrClone + 0) = 0;

		}
		return pstrClone;
	}



// --------------------------------------------------------------------------------
// Name: Destructor 
// Abstract: goodbye
// --------------------------------------------------------------------------------
CSuperString::~CSuperString()
{
		CleanUp();
}



// --------------------------------------------------------------------------------
// Name: Destructor 
// Abstract: goodbye
// --------------------------------------------------------------------------------
void CSuperString::CleanUp()
{
	DeleteString(m_pstrSuperString);
}



	// --------------------------------------------------------------------------------
	// Name: DeleteString 
	// Abstract: goodbye
	// --------------------------------------------------------------------------------
	void CSuperString::DeleteString(char* &pstrSource)
	{
		if (pstrSource != 0)
		{
			delete[] pstrSource;
			pstrSource = 0;

		}
	}



// --------------------------------------------------------------------------------
// Name: ToString 
// Abstract: goodbye
// --------------------------------------------------------------------------------
const char* CSuperString::ToString() const
{
	return m_pstrSuperString;
}


// --------------------------------------------------------------------------------
// Name: ToBoolean 
// Abstract: goodbye
// --------------------------------------------------------------------------------
bool CSuperString::ToBoolean()
{
	const char* pchrlowerString;
		
	bool blnresult = false;

	pchrlowerString = ToLowerCase();

	

	blnresult = (strcmp(pchrlowerString, "true") == 0);


	delete[] pchrlowerString;


	return blnresult;
}



// --------------------------------------------------------------------------------
// Name: ToShort 
// Abstract: goodbye
// --------------------------------------------------------------------------------
short CSuperString::ToShort()
{
	int intvalue = 0;
		
	intvalue = atoi(m_pstrSuperString);


	return static_cast<short>(intvalue);
}



// --------------------------------------------------------------------------------
// Name: ToInteger 
// Abstract: converting to integer using atoi
// --------------------------------------------------------------------------------
int CSuperString::ToInteger()
{
	return atoi(m_pstrSuperString);
}



// --------------------------------------------------------------------------------
// Name: ToLong 
// Abstract: converting to long using atol 
// --------------------------------------------------------------------------------
long CSuperString::ToLong()
{
	return atol(m_pstrSuperString);
}



// --------------------------------------------------------------------------------
// Name: ToFloat 
// Abstract: converting to float using atof 
// --------------------------------------------------------------------------------
float CSuperString::ToFloat()
{

	return static_cast<float>(atof(m_pstrSuperString));
}



// --------------------------------------------------------------------------------
// Name: ToDouble 
// Abstract: using to double using atof
// --------------------------------------------------------------------------------
double CSuperString::ToDouble()
{

	return atof(m_pstrSuperString);
}


// --------------------------------------------------------------------------------
// Name: operator<<
// Abstract: ostream& osOut, const CSuperString& ssOutput
// --------------------------------------------------------------------------------
ostream& operator<<(ostream& osOut, const CSuperString& ssOutput)
{

	if (ssOutput.m_pstrSuperString)
	{
		osOut << ssOutput.m_pstrSuperString;
	}
	return osOut;
}



// --------------------------------------------------------------------------------
// Name: operator>>
// Abstract: istream& isIn, CSuperString& ssInput
// --------------------------------------------------------------------------------
istream& operator>>(istream& isIn, CSuperString& ssInput)
{

	char chrBuffer[1024];
	isIn >> chrBuffer;
	ssInput = chrBuffer;  
	return isIn;
}

// --------------------------------------------------------------------------------
// Name: operator<
// Abstract:  blnLeftHandSide, blnRightHandSide
// --------------------------------------------------------------------------------
bool operator<(const CSuperString& blnLeftHandSide, const CSuperString& blnRightHandSide)
{

	return strcmp(blnLeftHandSide.ToString(), blnRightHandSide.ToString()) < 0;
}



// --------------------------------------------------------------------------------
// Name: operator>>
// Abstract: blnLeftHandSide, blnRightHandSide
// --------------------------------------------------------------------------------
bool operator>(const CSuperString& blnLeftHandSide, const CSuperString& blnRightHandSide)
{
	return strcmp(blnLeftHandSide.ToString(), blnRightHandSide.ToString()) > 0;
}



// --------------------------------------------------------------------------------
// Name: operator<=
// Abstract: blnLeftHandSide, blnRightHandSide
// --------------------------------------------------------------------------------
bool operator<=(const CSuperString& blnLeftHandSide, const CSuperString& blnRightHandSide)
{
	return (blnLeftHandSide < blnRightHandSide) || (blnLeftHandSide == blnRightHandSide);
}



// --------------------------------------------------------------------------------
// Name: operator>=
// Abstract:  blnLeftHandSide, blnRightHandSide
// --------------------------------------------------------------------------------
bool operator>=(const CSuperString& blnLeftHandSide, const CSuperString& blnRightHandSide)
{
	return (blnLeftHandSide > blnRightHandSide) || (blnLeftHandSide == blnRightHandSide);
}



// --------------------------------------------------------------------------------
// Name: operator==
// Abstract:  blnLeftHandSide, blnRightHandSide
// --------------------------------------------------------------------------------
bool operator==(const CSuperString& blnLeftHandSide, const CSuperString& blnRightHandSide)
{
	return strcmp(blnLeftHandSide.ToString(), blnRightHandSide.ToString()) == 0;
}



// --------------------------------------------------------------------------------
// Name: operator!=
// Abstract: blnLeftHandSide, blnRightHandSide
// --------------------------------------------------------------------------------
bool operator!=(const CSuperString& blnLeftHandSide, const CSuperString& blnRightHandSide)
{
	return !(blnLeftHandSide == blnRightHandSide);
}



// --------------------------------------------------------------------------------
// Name: Print 
// Abstract: goodbye
// --------------------------------------------------------------------------------
void CSuperString::Print(const char* pstrCaption) const 
{
	cout << endl;

	cout << pstrCaption << endl;

	cout << "---------------------------------------" << endl;

	if (Length() > 0)
	{
		cout << m_pstrSuperString << endl;
	}
	else
	{
		printf("-Empty String\n");
	}

	cout << endl;
}
