// --------------------------------------------------------------------------------
// Name: Jaxson DeHaven
// Class: SET-151-400 
// Abstract: Homework 11
// --------------------------------------------------------------------------------

// --------------------------------------------------------------------------------
// Includes
// --------------------------------------------------------------------------------
#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#include <math.h>
#include "CSuperString.h"
#include <iostream>


using namespace std;
// --------------------------------------------------------------------------------
// Constants
// --------------------------------------------------------------------------------
const int intARRAY_SIZE = 100;

//---------------------------------------------------------------------------------
// User Defined Types (UDTs)
//---------------------------------------------------------------------------------


// --------------------------------------------------------------------------------
// Prototypes
// --------------------------------------------------------------------------------
void ConstructorTests();
void  AssignmentOperators();
void FindFirstandLastIndexOf();
void FindFirstandLastIndexOfSubString();
void StringManipulation();
void ToDataTypes();
void ComparisonOperators();
// --------------------------------------------------------------------------------
// Name: main
// Abstract: This is where the program starts.
// --------------------------------------------------------------------------------
void main()
{



    cout << "---------------------------------------------------" << endl;
    cout << "CSuperString Tests" << endl;
    cout << "----------------------------------------------------" << endl;
    cout << endl;

    ConstructorTests();
    AssignmentOperators();
    FindFirstandLastIndexOf();
    FindFirstandLastIndexOfSubString();
    StringManipulation();
    ToDataTypes();
    ComparisonOperators();
    system("pause");
}



// --------------------------------------------------------------------------------
// Name: ConstructorTests 
// Abstract: Testing the Consturctors
// --------------------------------------------------------------------------------
void ConstructorTests()
{


    CSuperString ssSource1;
    CSuperString ssSource2("I Love Star Trek!");
    CSuperString ssSource3a(true);
    CSuperString ssSource3b(false);
    CSuperString ssSource4('I');
    CSuperString ssSource5a((short)SHRT_MIN);
    CSuperString ssSource5b((short)SHRT_MAX);
    CSuperString ssSource6a((int)INT_MIN);
    CSuperString ssSource6b((int)INT_MAX);
    CSuperString ssSource7a((long)LONG_MIN);
    CSuperString ssSource7b((long)LONG_MAX);
    CSuperString ssSource8a((float)FLT_MIN);
    CSuperString ssSource8b((float)FLT_MAX);
    CSuperString ssSource9a((double)DBL_MIN);
    CSuperString ssSource9b((double)DBL_MAX);
    CSuperString ssSource10(ssSource2);
    CSuperString ssSource11;

    // --------------------------------------------------------------------------------
    // Construcotrs
    // --------------------------------------------------------------------------------
    cout << "Constructors\n" << endl;
    cout << "-----------------------------------------" << endl;
    cout << "1) - Default              " << ssSource1.ToString() << endl;
    cout << "2) - char*                 " << ssSource2.ToString() << endl;
    cout << "3a) - boolean             " << ssSource3a.ToString() << endl;
    cout << "3b) - booelan             " << ssSource3b.ToString() << endl;
    cout << "4) - char                 " << ssSource4.ToString() << endl;
    cout << "5a) - short               " << ssSource5a.ToString() << endl;
    cout << "5b) - short               " << ssSource5b.ToString() << endl;
    cout << "6a) - int                 " << ssSource6a.ToString() << endl;
    cout << "6b) - int                 " << ssSource6b.ToString() << endl;
    cout << "7a) - long                " << ssSource7a.ToString() << endl;
    cout << "7b) - long                " << ssSource7b.ToString() << endl;
    cout << "8a) - float               " << ssSource8a.ToString() << endl;
    cout << "8b) - float               " << ssSource8b.ToString() << endl;
    cout << "9a) - double              " << ssSource9a.ToString() << endl;
    cout << "9b) - double              " << ssSource9b.ToString() << endl;
    cout << "10) - SuperString         " << ssSource10.ToString() << endl;


    cout << endl;
    cout << endl;
}


// --------------------------------------------------------------------------------
// Assignment Operators
// --------------------------------------------------------------------------------
void AssignmentOperators()
{
    cout << "Assignment Operators\n" << endl;
    cout << "-----------------------------------------" << endl;
    CSuperString strSource("I Love Star Trek");
    CSuperString strSource2(" The Best Show Ever");
    cout << "1) - Default              " << strSource.ToString() << endl;

    strSource += "!";

    cout << "2) - After  +=            " << strSource.ToString() << endl;


    strSource = strSource + strSource2;


    cout << "2) - After  + operator    " << strSource.ToString() << endl;

    cout << endl;
    cout << endl;

}


// --------------------------------------------------------------------------------
// FindFirstIndexOf and FindLastIndexOf char
// --------------------------------------------------------------------------------
void FindFirstandLastIndexOf()
{
    CSuperString strSource("I Love Star Trek");

    cout << "Find First and Last Index" << endl;
    cout << "-----------------------------------------" << endl;
    cout << "2) I                               " << strSource.FindFirstIndexOf('I') << endl;
    cout << "3) S                               " << strSource.FindFirstIndexOf('S') << endl;
    cout << "4) plus Start Index t              " << strSource.FindFirstIndexOf('t',0) << endl;
    cout << "5) Last Index: k                   " << strSource.FindLastIndexOf('k') << endl; // Should output 15.
    cout << endl;
    cout << endl;
}

// --------------------------------------------------------------------------------
// FindFirstIndexOf and FindLastIndexOf Substring
// --------------------------------------------------------------------------------
void FindFirstandLastIndexOfSubString()
{
    CSuperString strSource("I Love Star Trek");

    cout << "Substring First and Last Index\n" << endl;
    cout << "-----------------------------------------" << endl;

    cout << "1) First Index: love                " << strSource.FindFirstIndexOf("Love") << endl;
    cout << "2) First Index: Love, 0             " << strSource.FindFirstIndexOf("Love", 0) << endl;
    cout << "3) Last Index: Trek :               " << strSource.FindLastIndexOf("Trek") << endl;

    cout << endl;
    cout << endl;
}




// --------------------------------------------------------------------------------
// String Manipulation
// --------------------------------------------------------------------------------
void StringManipulation()
{
    CSuperString ssBuffer("   I Love Star Trek   ");

    cout << "String Manipulation\n" << endl;
    cout << "-----------------------------------------" << endl;

    cout << "1) Origninal:                " << ssBuffer.ToString() << endl;		// I Love Star Trek
    cout << "2) Upper:                    " << ssBuffer.ToUpperCase() << endl;	// I LOVE STAR TREK
    cout << "3) Origninal:                " << ssBuffer.ToString() << endl;		// I Love Star Trek
    cout << endl;
   
    cout << "1a) Origninal:               " << ssBuffer.ToString() << endl;		// I Love Star Trek
    cout << "2a) LowerCase:               " << ssBuffer.ToLowerCase() << endl;	// i love star trek
    cout << "3a) Origninal:               " << ssBuffer.ToString() << endl;		// I Love Star Trek
    cout << endl;

    cout << "1b) Origninal:               " << ssBuffer.ToString() << endl;
    cout << "2b) TrimLeft:                " << ssBuffer.TrimLeft() << endl;
    cout << "3b) TrimRight:               " << ssBuffer.TrimRight() << endl;
    cout << "4b) Trim:                    " << ssBuffer.Trim()  << endl;
    cout << "5b) Origninal:               " << ssBuffer.ToString()  << endl;
    cout << endl;

    cout << "1c) Origninal:               " << ssBuffer.ToString() << endl;
    cout << "2c) Reverse:                 " << ssBuffer.Reverse()  << endl;
    cout << "1d) Origninal:               " << ssBuffer.ToString() << endl;
    cout << "2d) Substring:                 " << ssBuffer.Substring(1, 10) << endl;
    cout << "3d) Origninal:               " << ssBuffer.ToString()  << endl;
    cout << endl;
    cout << endl;


    cout << "Replace\n" << endl;
    cout << "-----------------------------------------" << endl;

    CSuperString ssTest = "I Love Star Wars and I Love Star Trek";

    ssTest = ssTest.Replace("Love", "Really Love Love");

    cout << "Test #2:" << ssTest << endl;

    cout << endl;
    cout << endl;

    cout << "double call\n" << endl;
    cout << "-----------------------------------------" << endl;

    printf("Left( 2 ): %s, Left( 4 ): %s\n", ssBuffer.Left(2), ssBuffer.Left(4));

    printf("Right( 2 ): %s, Right( 4 ): %s\n", ssBuffer.Right(8), ssBuffer.Right(10));

    cout << endl;
    cout << endl;
   
}
         
// --------------------------------------------------------------------------------
//To Data Types
// --------------------------------------------------------------------------------
void ToDataTypes()
{

    cout << "To Data Types\n" << endl;
    cout << "-----------------------------------------" << endl;

    CSuperString ssShtString("242");

    cout << "1a) ToShort: 242                       " << ssShtString.ToShort() << endl;

    CSuperString ssIntString("242424");
    cout << "2a) ToInteger: 242424                  " << ssIntString.ToInteger() << endl;

    CSuperString ssLngString("12345672");
    cout << "3a) ToLong: 24423434                   " << ssLngString.ToLong() << endl;
    cout << endl;

    CSuperString ssFloatString("2.313");

    cout << "3d) ToFloat:  2.31                    " << ssFloatString.ToFloat() << endl;

    CSuperString ssDblString("2.313233");
    cout << "3d) ToDouble: 2.31323                 " << ssDblString.ToDouble() << endl;
    cout << endl;

    CSuperString ssBoolTrue("true");
    CSuperString ssBoolFalse("false");

    cout << "1d) ToBoolean True:                    " << ssBoolTrue.ToBoolean() << endl;
    cout << "2d) ToBoolean False:                   " << ssBoolFalse.ToBoolean() << endl;
    cout << endl;
    cout << endl;
}


// --------------------------------------------------------------------------------
//Comparison Operators
// --------------------------------------------------------------------------------
void ComparisonOperators()
{


    cout << "Comparison Operators\n" << endl;
    cout << "-----------------------------------------" << endl;

    CSuperString ssComparison1("I Love Star Trek");
    CSuperString ssComparison2("Banana");
    CSuperString ssComparison3("I Love Star Trek");

    cout << "Comparison1: I Love Star Trek" << endl;
    cout << "Comparison2: Banana" << endl;
    cout << "Comparison1: I Love Star Trek" << endl;

    cout << endl;

   
    if (ssComparison1 == ssComparison3)
        cout << "ssComparison1 and ssComparison3 are equal." << endl;
    else
        cout << "ssComparison1 and ssComparison3 are not equal." << endl;

    if (ssComparison1 != ssComparison2)
        cout << "ssComparison1 and ssComparison2 are not equal." << endl;

    if (ssComparison1 < ssComparison2)
        cout << "ssComparison1 is less than ssComparison2." << endl;
    if (ssComparison2 > ssComparison1)
        cout << "ssComparison2 is greater than ssComparison1." << endl;
    if (ssComparison1 <= ssComparison3)
        cout << "ssComparison1 is less than or equal to ssComparison3." << endl;
    if (ssComparison2 >= ssComparison1)
        cout << "ssComparison2 is greater than or equal to ssComparison1." << endl;

}
#pragma endregion
