/**
 * CCar
 * @author Jaxson DeHaven
 */
public class CCar extends CVehicle 
{
    public CCar() 
    {
        super(4, 25); // 4 wheels, 25 MPG
    }

   
    public  void HowToDrive() 
    {
        System.out.println("The car uses a steering wheel to drive.");
    }
 

    public void Print() 
	{
	    System.out.println("There are  " + GetWheels() + " wheels" + " and the miles per gallon is " + GetNumOfMPG());
	    HowToDrive();
	    System.out.println();
	}
}