/**
 * CMotorBike
 * @author Jaxson DeHaven
 */
public class CMotorBike extends CVehicle 
{
    public CMotorBike() 
    {
        super(2, 40); // 2 wheels, 40 MPG
    }

    public void HowToDrive() {
        System.out.println("The Motorbike uses handlebars to drive.");
    }
    public void Print() 
	{
	    System.out.println("There are  " + GetWheels() + " wheels" + " and the Miles Per Gallon is " + GetNumOfMPG());
	    HowToDrive();
	    System.out.println();
	}
}