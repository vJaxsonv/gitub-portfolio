/**
 * CTrailer
 * @author Jaxson DeHaven
 */
public class CTrailer extends CVehicle 
{
    public CTrailer() {
        super(4, 0); // 4 wheels, 0 MPG
    }

 
    public void HowToDrive() 
    {
        System.out.println("The Trailer attaches to a vehicle for towing.");
    }

    public void Print() 
	{
	    System.out.println("There are  " + GetWheels() + " wheels" + " and the Miles Per Gallon is " + GetNumOfMPG());
	    HowToDrive();
	    System.out.println();
	}
}