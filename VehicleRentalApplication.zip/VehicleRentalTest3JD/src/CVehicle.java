
/**
 * CVehicle
 * @author Jaxson DeHaven
 */
public  class CVehicle {
    private  int m_intWheels;      
    private int m_intNumOfMPG;  
    
    public  CVehicle(int intWheels, int intNumOfMPG) 
    {
        Initialize(intWheels, intNumOfMPG);
    }
    /**
     * Default constructor for CVehicle.
     * Initializes wheels and MPG to 0.
     */
    public CVehicle() 
    {
        m_intWheels = 0;
        m_intNumOfMPG = 0;
    }


    /**
	 * Initialize
	 * Abstract: Initializing intWheels, and intNumOfMPG
	 */
    public void Initialize(int intWheels, int intNumOfMPG) 
    {
        SetWheels(intWheels);
        SetNumOfMPG(intNumOfMPG);
    }

    /**
	 * GetWheels
	 * @return m_intWheels
	 */
    public int GetWheels() {
        return m_intWheels;
    }

    /**
	 * SetWheels
	 * @param intWheels
	 */
    public void SetWheels(int intWheels) {
        if (intWheels < 0) {
            intWheels = 0; // Prevent negative wheels
        }
        m_intWheels = intWheels;
    }

    /**
	 * GetNumOfMPG
	 * @return m_intNumOfMPG
	 */
    public int GetNumOfMPG() {
        return m_intNumOfMPG;
    }

    /**
   	 * SetNumOfMPG
   	 * @return m_intNumOfMPG
   	 */
    public void SetNumOfMPG(int intNumOfMPG) {
        if (intNumOfMPG < 0) {
            intNumOfMPG = 0; // Prevent negative MPG
        }
        m_intNumOfMPG = intNumOfMPG;
    }
    
	
    /**
   	 * HowToDrive
   	 *Abstract: Prints How To Drive
   	 */
    public void HowToDrive() 
    {
        System.out.println("Dont Know How to Drive.");
    }
    /**
   	 * getWheels
   	 * Abstract: Prints Wheels
   	 */
    public  void getWheels() 
    {
        System.out.println(" Wheels: " + m_intWheels);
    }
    /**
   	 * getWheels
   	 *Abstract: Prints Wheels
   	 */
    public void getMPG() 
    {
        System.out.println(" Wheels: " + m_intNumOfMPG);
    }
	
}
		 

	