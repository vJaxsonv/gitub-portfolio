import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import com.microsoft.sqlserver.jdbc.*;	// For connecting to SQL Server

/**
 * CVehicleFinal  class
 * @author Jaxson DeHaven
 */
public class CVehicleFinal
{
		//define the Connection
		private static Connection m_conAdministrator;
		//define the table, primary key, and column
		/**
		 * main method: intro to database processing
		 * This will connect to the db and display records on the console
		 */
		public static void main(String[] args) {
		    try {
		        // Can we connect to the database?
		        if (OpenDatabaseConnectionSQLServer()) {
		            // Yes, load the teams list
		            LoadListFromDatabase("TLocations", "intLocationID", "strLocationName", "strAddress", "strCity", "strZip");
		        } else {
		            // No, warn the user ...
		            System.out.println("Error loading the table");
		        }

		        // Process user inputs
		        processUserInputs();

		        // Indicate process completion
		        System.out.println("Process Complete");
		    } catch (Exception e) {
		        System.out.println("An I/O error occurred: " + e.getMessage());
		    }
		}

        private static void processUserInputs()
        {
        	
			// Declare variables
			String strResponse = "";
			String strPhoneNumber = "";
			String strEmail = "";
			String strFirstName = "";
			String strLastName = "";
			String strVehicleType ="";
			int intNumberOfDays = 0;
			int intNumberofVehicles = 0;
			int intVehicleType = 0;
			double dblRentalTotal = 0;
			double dblDailySubtotal = 0;
			
			// Print header
			System.out.println( );
			System.out.println( "Welcome to The CState's Vehical Rental!" );
			System.out.println( "-----------------------------------------------" );
			System.out.println( "Enter QUIT at anytime to exit." );
			System.out.println( );
			
		
		while(true)
		{
			
			System.out.println("" );
			
			System.out.print( "First Name: " );
			strResponse = ReadStringFromUser();
			// Check for quit
			if( strResponse.toUpperCase().matches( "QUIT" ) )
			{
				ProgramEnded();
				return;
			}
			// Quit not entered
			strFirstName = strResponse;
			
			// Ask user for last name
			System.out.print( "Last Name: " );
			strResponse = ReadStringFromUser();
			// Check for quit
			if( strResponse.toUpperCase().matches( "QUIT" ) )
			{
				ProgramEnded();
				return;
			}
			// Quit not entered
			strLastName = strResponse;
			
			// Ask user for phone number and loop until correct format is entered
			do
			{
				System.out.print( "Phone number in the format '###-###-####' or '##########': " );
				strResponse = ReadStringFromUser();
				// Check for quit
				if( strResponse.toUpperCase().matches("QUIT") )
				{
					ProgramEnded();
					return;
				}
			}while( IsValidPhoneNumber( strResponse ) == false );
			
			// Phone number is in correct format
			strPhoneNumber = strResponse;
			
			// Ask user for email and loop until correct format is entered
			do
			{
				System.out.print( "Email: " );
				strResponse = ReadStringFromUser();
				// Check for quit
				if( strResponse.toUpperCase().matches("QUIT") )
				{
					ProgramEnded();
					return;
				}
			}while( IsValidEmailAddress( strResponse ) == false );
			
			// Email is in correct format
			strEmail = strResponse;
	
			// Ask user for number of days to rent
			do
			{
				System.out.print( "Number of days you are renting: " );
				strResponse = ReadStringFromUser();
				// Check for quit
				if( strResponse.toUpperCase().matches("QUIT") )
				{
					ProgramEnded();
					return;
				}
			}while( IsInteger( strResponse ) == false );
			
			intNumberOfDays = Integer.parseInt(strResponse);
			
			//ask Type of Vehicle
			do
			{	do
				{
					System.out.print( "Number of Vehicles you are renting: " );
					strResponse = ReadStringFromUser();
					// Check for quit
					if( strResponse.toUpperCase().matches("QUIT") )
					{
						ProgramEnded();
						return;
					}
				}while( IsInteger( strResponse ) == false );
				intNumberofVehicles = Integer.parseInt(strResponse);
			}while(intNumberofVehicles > 3);
			
			do
			{	do
				{
					System.out.print( "What Vehicle Type? \n 1 = Car\n 2 = MotorCycle\n 3 = Trailer\n Please Enter 1, 2, or 3: " );
					strResponse = ReadStringFromUser();
					// Check for quit
					if( strResponse.toUpperCase().matches("QUIT") )
					{
						ProgramEnded();
						return;
					}
				}while( IsInteger( strResponse ) == false );
			intVehicleType = Integer.parseInt(strResponse);
			}while(intVehicleType != 1 && intVehicleType != 2 && intVehicleType != 3);
			
			//Printing Information
			System.out.println( "" );
			System.out.println( "-----------------------------------------------" );
			System.out.println( "Name: " +  strFirstName +" "+  strLastName );
			System.out.println( "Phone Number: "+  strPhoneNumber );
			System.out.println( "Email: " +  strEmail);
			
			//checking which Vehicle Type it is
			if (intVehicleType == 1)
			{
				strVehicleType = "Car";
				System.out.println( "Type of Vehicle: "+  strVehicleType );
				
				CCar cCar = new CCar();
				cCar.Print();
				
			}
			if (intVehicleType ==  2)
			{
				strVehicleType = "MotorBike";
				System.out.println( "Type of Vehicle: "+  strVehicleType );
				
				CMotorBike clsMotorBike = new CMotorBike();
				clsMotorBike.Print();
				
			}
			if (intVehicleType == 3)
			{
				strVehicleType = "Trailer";
				System.out.println( "Type of Vehicle: "+  strVehicleType );
				CTrailer clsTrailer = new CTrailer();
				clsTrailer.Print();
				
			}
			
			
			dblRentalTotal = CalculateTotals( intVehicleType, intNumberofVehicles, intNumberOfDays );
		
			dblDailySubtotal += dblRentalTotal;
			System.out.println( "-----------------------------------------------" );
			System.out.println( "Total Rental: " + dblRentalTotal );
			System.out.println( "Total Rental for All Vehicles: " +  dblDailySubtotal );
			System.out.print("Would you like to process another rental? (YES/QUIT): ");
		    strResponse = ReadStringFromUser();
		    if (strResponse.toUpperCase().matches("QUIT")) 
		    {
		        ProgramEnded();
		        break; // Exit the loop
	        }
		    System.out.println( );
		} 
	}
        
    
	
	
    /**
	 * Method: Print Totals - Get input from user
	 * @return dblRentalTotal
	 */
    public static double CalculateTotals (int intVehicleType, int intNumberofVehicles, int intNumberOfDays )
	{
    	double dblCarRentalTotal = 0;
    	double dblMotorBikeRentalTotal = 0;
    	double dblTrailerRentalTotal = 0;
    	double dblRentalTotal = 0;
    	
    	if (intVehicleType == 1)
    	{
    		dblCarRentalTotal = CalculateRentCar(intVehicleType,  intNumberofVehicles, intNumberOfDays);
    		
    		dblRentalTotal += dblCarRentalTotal;
    	
    	}
    	if (intVehicleType == 2)
    	{
    		dblMotorBikeRentalTotal = CalculateRentMotorBike( intVehicleType,  intNumberofVehicles, intNumberOfDays);
    		dblRentalTotal += dblMotorBikeRentalTotal;
    	}
    	if (intVehicleType == 3)
    	{
    		dblTrailerRentalTotal = CalculateRentTrailer( intVehicleType,  intNumberofVehicles, intNumberOfDays);
    		dblRentalTotal += dblTrailerRentalTotal;
    	}
		
    	return dblRentalTotal;
    	
	
    	
	}
    /**
	 * Method: CalculateRentCar 
	 * @return dblCarRentalTotal
	 */
    public static double CalculateRentCar(int intVehicleType, int intNumberofVehicles, int intNumberOfDays )
	{
    	
    	double dblCarRentalTotal = 0;
    	double dblCarPrice = 30;
    	
    	dblCarRentalTotal =  (intNumberofVehicles * dblCarPrice) * intNumberOfDays ;
    	
		return  dblCarRentalTotal;
    	
	}
    
    
    
    /**
   	 * Method: CalculateRentMotorBike 
   	 * @return dblMotorbikeRentalTotal
   	 */
       public static double CalculateRentMotorBike(int intVehicleType, int intNumberofVehicles, int intNumbeOfDays )
   	{
       	
       	double dblMotorbikeRentalTotal = 0;
       	double dblMotorbikePrice = 20;
       	
       	dblMotorbikeRentalTotal =  (intNumberofVehicles * dblMotorbikePrice) * intNumbeOfDays ;
       	
   		return  dblMotorbikeRentalTotal;
       	
   	}
       
    
   /**
  	 * Method: CalculateRentTrailer 
  	 * @return dblTrailerRentalTotal
  	 */
      public static double CalculateRentTrailer( int intVehicleType, int intNumberofVehicles, int intNumbeOfDays )
  	{
      	
      	double dblTrailerRentalTotal = 0;
      	double dblTrailerPrice = 40;
      	
      	dblTrailerRentalTotal =  (intNumberofVehicles * dblTrailerPrice) * intNumbeOfDays ;
      	
  		return  dblTrailerRentalTotal;
      	
  	}
	/**
	 * Method: ReadStringFromUser - Get input from user
	 * @return strBuffer
	 */
	public static String ReadStringFromUser( )
	{

		String strBuffer = "";

		try
		{
			// Input stream
			BufferedReader burInput = new BufferedReader( new InputStreamReader( System.in ) ) ;

			// Read a line from the user
			strBuffer = burInput.readLine( );
		}
		catch( Exception excError )
		{
			System.out.println( excError.toString( ) );
		}

		// Return string
		return strBuffer;
	}
	
	
	/**
	 * Method: ProgramEnded - When user enters "QUIT"
	 */
	private static void ProgramEnded() {
		System.out.println( "-----------------------------------------------" );
		System.out.println( "Program ended by user." );
		System.out.println( "Thank you for using CState's Vehicle Rental!" );
		System.out.println( "Please come again." );
	}
	
	
	/**
	 * Method: IsValidPhoneNumber - Check if phone number entered is in correct format
	 * @param strPhoneNumber
	 * Phone number entered by user
	 * @return blnIsValidPhoneNumber
	 */
	public static boolean IsValidPhoneNumber(String strPhoneNumber) {
		boolean blnIsValidPhoneNumber = false;
		
		try
		{
			// Declare variables
			String strStart = "^";
			String strStop = "$";
			String strDash = "\\-";
			String strPattern1 = "";
			String strPattern2 = "";
			
			// String patterns
			// ###-###-####
			strPattern1 = strStart + "\\d{3}" + strDash + "\\d{3}" + strDash + "\\d{4}" + strStop;
			// ##########
			strPattern2 = strStart + "\\d{10}" + strStop;
			
			// Does it match any of the formats?
			if( strPhoneNumber.matches( strPattern1 ) == true || 
				strPhoneNumber.matches( strPattern2 ) == true )
			{
				// Yes
				blnIsValidPhoneNumber = true;
			}
		}
		catch( Exception excError )
		{
			// Display Error Message
			System.out.println( excError );
		}
		// Return result
		return blnIsValidPhoneNumber;
	}
	
	
	/**
	 * Method: IsValidEmailAddress - Check if email entered is valid
	 * @param strResponse
	 * Email entered by user
	 * @return blnIsValidEmailAddress
	 */
	private static boolean IsValidEmailAddress(String strEmailAddress) {
		boolean blnIsValidEmailAddress = false;
		
		try
		{
			// Declare variables
			String strStart = "^";
			String strStop = "$";
			String strPattern = "";
			
			// Set string pattern
			strPattern = strStart + "[a-zA-Z][a-zA-Z0-9\\.\\-]*" + "@" + "[a-zA-Z][a-zA-Z0-9\\.\\-]*\\.[a-zA-Z]{2,6}" + strStop;
			
			// Does it match?
			if( strEmailAddress.matches( strPattern ) == true )
			{
				// Yes
				blnIsValidEmailAddress = true;
			}
			
		}
		catch( Exception excError )
		{
			// Display Error Message
			System.out.println( excError );
		}
		
		return blnIsValidEmailAddress;
	}
	
	
	
	
	/**
	 * Method ReadIntegerFromUser - Get user input
	 * @return intValue
	 */
	public static int ReadIntegerFromUser( )
	{

		int intValue = 0;

		try
		{
			String strBuffer = "";	

			// Input stream
			BufferedReader burInput = new BufferedReader( new InputStreamReader( System.in ) ) ;

			// Read a line from the user
			strBuffer = burInput.readLine( );
			
			// Convert from string to integer
			intValue = Integer.parseInt( strBuffer );
		}
		catch( Exception excError )
		{
			System.out.println( excError.toString( ) );
		}
		

		// Return integer value
		return intValue;
	}
	
	
	/**
	 * Method: IsInteger- checks if string is an integer
	 * @param strResponse
	 * String to check
	 * @return blnNumeric
	 */
	public static boolean IsInteger(String strResponse) {
		boolean blnNumeric = true;
		
		try
		{
			Integer.parseInt(strResponse);
		}
		catch( NumberFormatException e )
		{
			blnNumeric = false;
		}
		
		return blnNumeric;
	}
	
	
	/**
	 * Method: IsValidVehicleNumber- checks if string is an integer
	 * @param strResponse
	 * String to check
	 * @return blnNumeric
	 */
	public static boolean IsValidVehicleNumber(String strResponse) {
		boolean blnNumeric = true;
		
		try
		{
			Integer.parseInt(strResponse);
		}
		catch( NumberFormatException e )
		{
			blnNumeric = false;
		}
		
		return blnNumeric;
	}
	

	/** 
	 * 	method name: This will load the list from the table.	
	 */
	public static boolean LoadListFromDatabase( String strTable, String strPrimaryKeyColumn, String strNameColumn, String strAddressColumn, String strCityColumn, String strZipColumn ) {
		
		//set flag to false
		boolean blnResult = false;
		
		try
		{
			String strSelect = "";
			Statement sqlCommand = null;
			ResultSet rstTSource = null;
			int intID = 0;
			String strLocationName = "";
			String strAddress = "";
			String strCity = "";
			String strZip = "";
		
			// Build the SQL string
			strSelect = "SELECT " + strPrimaryKeyColumn + ", " + strNameColumn + ", " + strAddressColumn + ", " + strCityColumn + ", " + strZipColumn 
						+ " FROM " + strTable
						+ " ORDER BY " + strNameColumn; 
					
			// Retrieve the all the records	
			sqlCommand = m_conAdministrator.createStatement( );
			rstTSource = sqlCommand.executeQuery( strSelect );
			// Loop through all the records
			while( rstTSource.next( ) == true )
			{
				// Get ID and Name from current row
				intID = rstTSource.getInt( 1 );
				strLocationName = rstTSource.getString( 2 );
				strAddress = rstTSource.getString( 3 );
				strCity = rstTSource.getString( 4 );
				strZip = rstTSource.getString( 5 );
				
				// Print the list
				System.out.printf("ID: %-3d Name: %-15s Address: %-15s City: %-10s Zip: %-5s%n", 
					    intID, strLocationName, strAddress, strCity, strZip);
			}
			// Clean up
			rstTSource.close( );
			sqlCommand.close( );
			// Success
			blnResult = true;
		}
		catch 	(Exception e) {
			System.out.println( "Error loading table" );
			System.out.println( "Error is " + e );
		}
		
		return blnResult;
		}
	
	/** 
	 * method name: OpenDatabaseConnectionMSAccess
	 * The opens the database connection	
	 * This requires the following drivers: Use UCanAccess, an open-source JDBC driver.
	 * Include the following jar files in your code:
	 *		ucanaccess-2.0.7.jar
	 *		jackcess-2.0.4.jar
	 *		commons-lang-2.6.jar
	 *		commons-logging-1.1.3.jar
	 *		hsqldb.jar
	 *	To include those files select "Project / Properties / Java Build Path"
	 *	from the menu.  Click on the "Libraries" tab.  Click "Add External JARs".
	 *	Browse to the above jar files, which should be in a directory in your
	 * 	project (e.g. JDBC-to-MSAccess).  Select all five files and click "Open".  Click "OK".
	 *	
	 * Be sure to add the drivers to your program by selecting Project >> Properties >> Java Build Path
	 */
	public static boolean OpenDatabaseConnectionMSAccess( )
	{
		boolean blnResult = false;
		
		try {
			String strConnectionString = "";
			
			// Server name/port, IP address/port or path for file based DB like MS Access
			// System.getProperty( "user.dir" ) => Current working directory from where
			// application was started
			strConnectionString = "jdbc:ucanaccess://" + System.getProperty( "user.dir" )
								+ "\\Database\\dbHCM.accdb";
			// Open a connection to the database
			m_conAdministrator = DriverManager.getConnection( strConnectionString );
			// Success
			blnResult = true;
		}
		catch 	(Exception e) {
			System.out.println( "Try again - error in OpenDB ");
			System.out.println( "Error is " + e );
		}
		return blnResult;
	}
	/**
	 * OpenDatabaseConnectionSQLServer - get SQL db connection
	 * @return blnResult
	 */
	public static boolean OpenDatabaseConnectionSQLServer( )
	{
		boolean blnResult = false;
		
		try
		{
			SQLServerDataSource sdsTeamsAndPlayers = new SQLServerDataSource( );
			//tg-comment out --sdsTeamsAndPlayers.setServerName( "localhost" ); // localhost or IP or server name
			sdsTeamsAndPlayers.setServerName( "localhost\\SQLExpress" ); // SQL Express version
			sdsTeamsAndPlayers.setPortNumber( 1433 );
			sdsTeamsAndPlayers.setDatabaseName( "dbHCM" );
			
			// Login Type:
			
				// Windows Integrated
				//tg-comment out --sdsTeamsAndPlayers.setIntegratedSecurity( true );
				
				// OR
				
				// SQL Server
			     sdsTeamsAndPlayers.setUser( "sa" );
				 sdsTeamsAndPlayers.setPassword( "BINGBONGMODZ#1234567" );	// Empty string "" for blank password
			
			// Open a connection to the database
			m_conAdministrator = sdsTeamsAndPlayers.getConnection(  );
			
			// Success
			blnResult = true;
		}
		catch( Exception excError )
		{
			// Display Error Message
			System.out.println( "Cannot connect - error: " + excError );
	
			// Warn about SQL Server JDBC Drivers
			System.out.println( "Make sure download MS SQL Server JDBC Drivers");
		}
		
		return blnResult;
	}
	
	
	/**
	* Name: CloseDatabaseConnection
	* Abstract: Close the connection to the database
	*/ 
	public static boolean CloseDatabaseConnection( )
	{
		boolean blnResult = false;
		
		try
		{
			// Is there a connection object?
			if( m_conAdministrator != null )
			{
				// Yes, close the connection if not closed already
				if( m_conAdministrator.isClosed( ) == false ) 
				{
					m_conAdministrator.close( );
					
					// Prevent JVM from crashing
					m_conAdministrator = null;
				}
			}
			// Success
			blnResult = true;
		}
		catch( Exception excError )
		{
			// Display Error Message
			System.out.println( excError );
		}
		
		return blnResult;
	}

}
